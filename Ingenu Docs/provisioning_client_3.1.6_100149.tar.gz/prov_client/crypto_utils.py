#!/usr/bin/env python
#
# Copyright (c) 2010. OnRamp Wireless, Inc.
# All rights reserved.
#
# OnRamp Wireless, Inc makes no representations about the suitability of
# this source code for any purpose. This source code is provided "AS IS"
# and without any express or implied warranties, including, without
# limitation, implied warranties of merchantability and fitness for any
# particular purpose.

""" Module containing RSA public key encryption, decryption, signature, and
    signature verification/authentication utilities."""

import threading
import getpass
import select
import string
import base64
import time
import sys
import os
import logging
import key_utils
import traceback

from Crypto.Cipher import PKCS1_OAEP
from Crypto.Hash import SHA256
from Crypto.Cipher import AES
from Crypto.PublicKey import RSA
from Crypto import __version__ as pycrypto_version

# Check the PyCrypto version and implement work arounds as required.
(pycrypto_version_major, remainder) = string.split(pycrypto_version, '.', 1)
try:
    (pycrypto_version_minor, remainder) = string.split(remainder, '.', 1)
except:
    # Version string only had 2 digits.
    pycrypto_version_minor = remainder

pycrypto_version_error = """Unsupported PyCrypto version '%s'.
Must use 2.5 or 2.6"""

if pycrypto_version_major != '2':
    raise ImportError, pycrypto_version_error % pycrypto_version
if pycrypto_version_minor < '5' or pycrypto_version_minor > '6':
    raise ImportError, pycrypto_version_error % pycrypto_version
try:
    # Check if the PyCrypto RSA module has the importKey method.
    _x = RSA.importKey
    _use_legacy_crypto = False
    del(_x)
except:
    # Older version of PyCrypto. Import legacy support module.
    import crypto_legacy
    _use_legacy_crypto = True

from key_utils import *


# AES key size is 32 bytes (256 bits).
AES_KEY_SIZE_256 =             32      # Bytes.
AES_BLOCK_SIZE_256 =           AES_KEY_SIZE_256
AES_BLOCK_SIZE_256_SHIFT =     5

AES_KEY_SIZE_192 =             24      # Bytes.
AES_BLOCK_SIZE_192 =           AES_KEY_SIZE_192
AES_BLOCK_SIZE_192_SHIFT =     None    # Not a power of two.

AES_KEY_SIZE_128 =             16      # Bytes.
AES_BLOCK_SIZE_128 =           AES_KEY_SIZE_128
AES_BLOCK_SIZE_128_SHIFT =     4

_AES_PADDING =                  chr(0)


# Read timeout for /dev/random.
_DEV_RANDOM_TIMEOUT_SEC =       3.0


# Constants for generating passphrase hash.
_PASSPHRASE_GEN_KEY  = '\xf0\xaf\xba\x23\x3d\x05\xb0\x34\x85\x43\x42\xf2\x63\x48\xbd\x8c'
_PASSPHRASE_GEN_SALT = '\xbd\x50\xec\xf7\xfc\xb5\x52\x49\x00\x7a\xb6\x14\xde\xe9\xe4\xbc'

# If logging is enabled, use the root logger.
_crypto_logging_enabled = False


###############################################################################
def rsa_import_key(key_data):
    try:
        # Do not use the fast math library since it produces different
        # RSA signatures than slow math.
        rsa = RSA.RSAImplementation(use_fast_math = False)
        key = rsa.importKey(key_data)
    except:
        # Could be pre-2.2 PyCrypto.
        key = crypto_legacy.importKey(RSA, key_data)
    
    return key
    
###############################################################################
def rsa_import_public_key(key_file):
    """Imports an RSA public key from a file."""
    if not key_file:
        raise ValueError, 'Missing file for public key import.'
    try:
        k = file(key_file)
    except:
        raise ValueError, "Invalid public key file '%s'" % key_file

    key_data = k.read()
    k.close()
    pubkey = rsa_import_key(key_data)

    return pubkey


###############################################################################
def rsa_import_private_key(key_file):
    """Imports an RSA private key from a file."""
    if not key_file:
        raise ValueError, 'Missing file for private key import.'
    try:
        k = file(key_file)
    except:
        raise ValueError, "Invalid private key file '%s'" % key_file

    key_data = k.read()
    k.close()
    privkey = rsa_import_key(key_data)

    if not privkey.has_private():
        raise ValueError, "Missing private key in file '%s'" % key_file
    return privkey


###############################################################################
def _rsa_sign(privkey, data, signature_file = None):
    """Signs/authenticates data using a private key. Writes the signature data
       to the specified output file, if any. Returns the signature data."""
    # Note: this is for PyCrypto 2.2.
    if not privkey.has_private():
        raise ValueError, 'Attempted to sign with public key.'
    if not data:
        raise ValueError, 'No data to sign.'
    sha = SHA256.new(data)
    signature = privkey.sign(sha.digest(), '')
    if signature_file:
        s = open(signature_file, 'w')
        s.write(repr(signature[0]))
        s.flush()
        os.fsync(s.fileno())
        s.close()
    return signature[0]


###############################################################################
def _rsa_sign_legacy(privkey, data, signature_file = None):
    """Signs/authenticates data using a private key. Writes the signature data
       to the specified output file, if any. Returns the signature data."""
    # Note: this is for pre-v2.2 PyCrypto.
    if not privkey.has_private():
        raise ValueError, 'Attempted to sign with public key.'
    if not data:
        raise ValueError, 'No data to sign.'
    sha = SHA256.new(data)
    # Be sure to reverse the byte order when converting to integer.
    M = convert_byte_string_to_int(sha.digest(), 1)
    signature = pow(M, privkey.d, privkey.n)
    if signature_file:
        s = open(signature_file, 'w')
        s.write(repr(signature))
        s.flush()
        os.fsync(s.fileno())
        s.close()
    return signature


###############################################################################
if _use_legacy_crypto:
    # Use the legacy PyCrypto signature work-around.
    rsa_sign = _rsa_sign_legacy
else:
    # Use the built-in PyCrypto signature method.
    rsa_sign = _rsa_sign


###############################################################################
def rsa_verify_signature(pubkey, data, signature_file):
    """Verifies the signature for a given piece of data (e.g. ciphertext)
       using the sender's public key. Returns false if the signature is not
       valid, otherwise returns true."""
    if not pubkey:
        raise ValueError, 'No public key specified.'
    if not signature_file:
        raise ValueError, 'No signature file specified.'
    if not data:
        raise ValueError, 'No data for signature verification specified.'
    try:
        s = file(signature_file)
    except:
        raise ValueError, "Invalid signature file '%s'" % signature_file
    # pyCrypto RSA expects the signature to be a one element tuple.
    sig = (eval(s.read()), '')
    s.close()

    # Compute the SHA256 hash of the data and compare it with
    # the signature.
    sha = SHA256.new(data)
    if not pubkey.verify(sha.digest(), sig):
        return False
    return True


###############################################################################
def rsa_decrypt(privkey, ciphertext, useOAEP = True):
    """Decrypts the beginning portion of the ciphertext using the private RSA
       key to extract the AES symmetric key used to encrypt the original
       plaintext. The size of the beginning portion used for the encrypted AES
       key is based on the size of the RSA key length (in this case, usually
       256 bytes). Immediately following the AES256 key is a 32 bit length
       field indicating the actual bytes of ciphertext to be decrypted (to
       determine how much padding is in the last AES block). Returns the
       plaintext data. Note OAEP should be used in any new applications to
       correctly pad the RSA encryption portion."""
    if not privkey.has_private():
        raise ValueError, 'Attempted to decrypt with public key.'
    if not ciphertext:
        raise ValueError, 'No ciphertext to decrypt.'

    # Extract the first 256 bytes of the ciphertext corresponding to the RSA
    # key length (or whatever RSA key length is reported) which will contain
    # the encrypted 256 bit AES key.
    rsa_key_length = (privkey.size() + 1) >> 3
    aes_key_crypt = ciphertext[0:rsa_key_length]

    if (useOAEP):
        cipher = PKCS1_OAEP.new(privkey)
        aes_key = cipher.decrypt(aes_key_crypt)
    else:
        aes_key = privkey.decrypt(aes_key_crypt)
    
    if (len(aes_key) < AES_KEY_SIZE_256):
        print 'short key - %d' % len(aes_key)
        aes_key = '\0'*(AES_KEY_SIZE_256 - len(aes_key)) + aes_key
    
    # Decrypt the remaining cipher text using the extracted AES key.
    plaintext = aes_decrypt(aes_key, ciphertext[rsa_key_length:])

    return plaintext


###############################################################################
def rsa_encrypt(pubkey, plaintext, useOAEP = True):
    """Generates a random AES256 symmetric key and uses it to encrypt the
       plaintext. The AES key is then encrypted using the public RSA key. The
       encrypted AES key is prefixed to ciphertext and the combined encrypted
       blob is returned. Note OAEP should be used in any new applications to
       correctly pad the RSA encryption portion."""

    if not pubkey:
        raise ValueError, 'No public key for encryption.'
    if not plaintext:
        raise ValueError, 'No plaintext to encrypt.'

    # Generate our random AES256 key.
    aes_key = aes_key_gen()

    # Encrypt the AES key using our recipient's RSA public key.

    if (useOAEP):
        cipher = PKCS1_OAEP.new(pubkey)
        aes_key_crypt = cipher.encrypt(aes_key)
    else:
        # Note that this encryption function returns a tuple. We're only 
        # interested in the first element.
        crypt_tuple = pubkey.encrypt(aes_key, '')
        aes_key_crypt = crypt_tuple[0]

    aes_ciphertext = aes_encrypt(aes_key, plaintext)
    rsa_ciphertext = aes_key_crypt + aes_ciphertext

    return rsa_ciphertext


###############################################################################
def aes_pad(plaintext):
    """Adds padding characters (NUL) to the end of plaintext to fill out an
       AES-256 encryption block (32 bytes). Returns the padded plaintext."""

    pt_trailing_bytes = len(plaintext) & (AES_BLOCK_SIZE_256 - 1)
    pad_size = (AES_BLOCK_SIZE_256 - pt_trailing_bytes)%AES_BLOCK_SIZE_256
    padding  = pad_size * _AES_PADDING

    return plaintext + padding

###############################################################################
def aes_strip_pad(plaintext):
    """Removes padding characters (NUL) from the end of plaintext. Note that
       we have no way to determine if a NUL is padding or real data, so this
       should not be used if the plaintext is binary vs text - in this case,
       a length must be encoded in the plaintext."""
    return plaintext.rstrip(_AES_PADDING)
    
###############################################################################
def aes_key_gen(key_len = AES_KEY_SIZE_256):
    """Generates a random AES key. Default length is 32 bytes (256 bits).
       Other acceptable key length values are 16 bytes (128 bits) or
       24 bytes (192 bits)."""

    if key_len in (AES_KEY_SIZE_256, AES_KEY_SIZE_256 * 8):
        key_len = AES_KEY_SIZE_256
    elif key_len in (AES_KEY_SIZE_192, AES_KEY_SIZE_192 * 8):
        key_len = AES_KEY_SIZE_192
    elif key_len in (AES_KEY_SIZE_128, AES_KEY_SIZE_128 * 8):
        key_len = AES_KEY_SIZE_128
    else:
        raise RuntimeError, "Invalid AES key length %d." % key_len

    aes_seed = os.urandom(64)
    sha = SHA256.new(aes_seed)
    aes_key = sha.digest()

    return aes_key[0:key_len]


###############################################################################
def aes_encrypt(aes_key, plaintext):
    """Encrypts the given plaintext using the symmetric AES256 key provided.
       Prior to encryption, the plaintext is padded with sufficient NUL chars
       to the next AES block size boundary. The resulting plaintext + pad
       is encrypted and then base64 encoded and returned."""

    if not aes_key:
        raise RuntimeError, "Missing AES key."
    if len(aes_key) != AES_KEY_SIZE_256:
        raise ValueError, "Invalid AES256 key length %d." % len(aes_key)

    # Add padding to the plaintext.
    plaintext = aes_pad(plaintext)
    aes = AES.new(aes_key)
    ciphertext = base64.b64encode(aes.encrypt(plaintext))

    return ciphertext


###############################################################################
def aes_decrypt(aes_key, ciphertext):
    """Decrypts the given ciphertext using the symmetric AES256 key provided.
       Prior to decryption, the ciphertext is base64 decoded. After decryption,
       the plaintext is then stripped of the padding characters (NUL). The
       decrypted plaintext is returned."""

    if not aes_key:
        raise RuntimeError, "Missing AES key."
    if len(aes_key) != AES_KEY_SIZE_256:
        raise ValueError, "Invalid AES256 key length %d." % len(aes_key)

    # Add padding to the plaintext.
    ciphertext = base64.b64decode(ciphertext)
    aes = AES.new(aes_key)
    plaintext = aes.decrypt(ciphertext)

    return plaintext


###############################################################################
def get_urandom(n):
    """Performs a non-blocking read of n pseudo-random bytes (byte string)
       the native OS urandom implementation."""
    if n <= 0:
        raise ValueError, "Invalid length request %d" % n
    random_value = os.urandom(n)
    return random_value


###############################################################################
def enable_logging_crypto_utils():
    global _crypto_logging_enabled
    _crypto_logging_enabled = True


###############################################################################
def disable_logging_crypto_utils():
    global _crypto_logging_enabled
    _crypto_logging_enabled = False


###############################################################################
def _print_msg_crypto_utils(msg, level = logging.INFO):
    if _crypto_logging_enabled:
        logging.getLogger().log(level, msg)
    else:
        print msg


###############################################################################
class EntropySource(threading.Thread):
    def __init__(self, key = None, seed = None, blocking = False):
        self.blocking = blocking        # Blocking read enabled for random bytes.
        self.random_bytes = ''          # Random byte buffer.
        self.random_byte_count = 0      # Total random bytes received.
        self._stop = None
        self.aes_cmac = None            # AES cipher CMAC object.
        if seed == None:
            self.random_seed = '\x00' * AES_BLOCK_SIZE_128
        else:
            if isinstance(seed, str):
                self.random_seed = seed[:AES_BLOCK_SIZE_128]
            else:
                raise ValueError, "Seed value must be a byte string."

        if os.name == 'posix':
            self.dev_random  = open('/dev/random', 'r')
            self.dev_urandom = open('/dev/urandom', 'r')
        elif os.name == 'nt':
            pass
        else:
            raise EnvironmentError, "Unsupported OS '%s'." % os.name
        if not blocking:
            if key == None:
                # No key specified. Create a pseudo-random key.
                key = get_urandom(AES_BLOCK_SIZE_128)
            self.aes_cmac = AesCmac(key)
            threading.Thread.__init__(self)
            self._stop = threading.Event()
            self.start()
        else:
            # If blocking is acceptable, then no need to spawn an entropy
            # gathering background thread.
            pass

    def kill(self):
        if self._stop != None:
            self._stop.set()

    def stopped(self):
        if self._stop != None:
            return self._stop.isSet()
        return True

    def run(self):
        if self.blocking:
            # Caller is willing to block, so no need to gather entropy
            # in a background thread.
            return
        if os.name != 'posix':
            # Only posix systems have the blocking /dev/random.
            return
        while 1:
            # Read from /dev/random and put the bytes into a buffer
            rlist = [self.dev_random]
            (r, w, x) = select.select(rlist, [], [], _DEV_RANDOM_TIMEOUT_SEC)
            if self.stopped():
                sys.exit(10)
            if len(r) == 0:
                time.sleep(0.025)
                continue
            if len(self.random_bytes) > 1024:
                time.sleep(0.1)
                continue
            self.random_bytes += self.dev_random.read(1)
            self.random_byte_count += 1

    def get_random(self, n, blocking = None):
        """Get n random bytes. If a blocking read is requested, then this function will read
           directly from /dev/random on posix systems, possibly blocking for extended periods
           of time. If blocking is not specified, then the value specified when this object
           was instantiated will be used (blocking disabled by default)."""
        if n <= 0:
            _print_msg_crypto_utils("Non-positive length %d" % n)
            return None
        if blocking == None:
            blocking = self.blocking
        if blocking and os.name == 'posix':
            # OK to block. So wait until we have the desired number
            # of random bytes (Posix only).
            random_data = self.dev_random.read(n)
            return random_data

        # Non-blockin or non-posix.
        n_rand = len(self.random_bytes)
        if n_rand:
            # At least one random byte in the buffer.
            if n_rand > AES_BLOCK_SIZE_128:
                n_rand = AES_BLOCK_SIZE_128
            if n_rand > n:
                n_rand = n
            self.random_seed = xor_byte_strings(self.random_seed, self.random_bytes[:n_rand])
            self.random_bytes = self.random_bytes[n_rand:]
        random_data = ''
        n_remaining = n
        while n_remaining > 0:
            # Get pseudo-random bytes.
            input_data = self.get_urandom(AES_BLOCK_SIZE_128)
            # Mangle with AES-CMAC algorithm, using seed as initialization vector.
            self.random_seed = self.aes_cmac.compute_cmac(input_data, self.random_seed)
            random_data += self.random_seed
            n_remaining -= AES_BLOCK_SIZE_128
        return random_data[:n]

    def get_urandom(self, n):
        """Get n pseudorandom bytes."""
        try:
            prn_value = get_urandom(n)
        except:
            self.kill()
            raise
        return prn_value


###############################################################################
class AesCmac():
    def __init__(self, key = None, verbosity = 0):
        self.aes = None                 # AES cipher object.
        self._key = key                 # AES key.
        self._subkey1 = None            # AES subkey 1.
        self._subkey2 = None            # AES subkey 2.
        self.random_seed = '\x00' * AES_BLOCK_SIZE_128
        self.verbosity = verbosity
        self.debug_enabled = 0

        if self._key == None:
            # No key specified.
            raise ValueError, "AES CMAC key not specified."
        if not isinstance(self._key, str):
            raise ValueError, "AES CMAC key must be a byte string."
        if len(self._key) != AES_BLOCK_SIZE_128:
            raise ValueError, "AES CMAC key invalid length."
        (self._subkey1, self._subkey2) = self.gen_subkeys(self._key)


    def gen_subkeys(self, key):
        """Generate 128 bit AES CMAC subkeys based on root key per NIST SP800-38B."""
        # Note: byte strings are assumed to be big-endian.
        b128 = '\x00' * AES_BLOCK_SIZE_128
        r128 = [0] * AES_BLOCK_SIZE_128
        key1 = [0] * AES_BLOCK_SIZE_128
        key2 = [0] * AES_BLOCK_SIZE_128
        r128[AES_BLOCK_SIZE_128 - 1] = 0x87
        use_r128 = False
        self.aes = AES.new(key, AES.MODE_ECB)
        L = self.aes.encrypt(b128)
        if self.debug_enabled and self.verbosity > 2:
            _print_msg_crypto_utils("L: " + convert_byte_string_to_hex_string(L))
        L = convert_byte_string_to_byte_array(L)
        # MSB is at array index 0 (big endian).
        if (L[0] & 0x80) != 0:
            # Most significant bit is set, so subkey will need a non-zero r128.
            use_r128 = True

        # Left shift L.
        L_shift = left_shift_byte_array(L, 1)
        if use_r128:
            for i in range(0, AES_BLOCK_SIZE_128):
                key1[i] = L_shift[i] ^ r128[i]
        else:
            for i in range(0, AES_BLOCK_SIZE_128):
                key1[i] = L_shift[i]

        # Be sure not to use key1[] as the first argument since the left
        # shift function will change the values of key1. Use key1[:] to
        # pass the values of key1, not key1 itself.
        key1_shift = left_shift_byte_array(key1[:], 1)
        if (key1[0] & 0x80) != 0:
            # MSB of subkey 1 is set, so use non-zero r128.
            for i in range(0, AES_BLOCK_SIZE_128):
                key2[i] = key1_shift[i] ^ r128[i]
        else:
            for i in range(0, AES_BLOCK_SIZE_128):
                key2[i] = key1_shift[i]

        # Convert numeric array keys to byte strings.
        k1 = ''.join(map(chr, key1))
        k2 = ''.join(map(chr, key2))
        if self.debug_enabled and self.verbosity > 2:
            _print_msg_crypto_utils("AES-CMAC Subkey1: " + convert_byte_string_to_hex_string(k1))
            _print_msg_crypto_utils("AES-CMAC Subkey2: " + convert_byte_string_to_hex_string(k2))
        return (k1, k2)


    def compute_cmac(self, plaintext = None, init_vector = None):
        """Computes the CMAC using AES128 cipher per NIST SP800-38B on the given plaintext."""
        if plaintext == None:
            # No plaintext to mangle.
            return None
        if self._key == None:
            raise ValueError, "No key specified."
        if init_vector != None:
            if not isinstance(init_vector, str):
                raise ValueError, "Initialization vector must be a numeric byte string."

        if self.debug_enabled and self.verbosity > 2:
            print "AES-CMAC Init Vector:",
            if init_vector:
                print ''.join(map(chr, init_vector))
            else:
                print ''

        # Number of complete AES blocks and leftover bytes.
        aes_blocks = len(plaintext) >> AES_BLOCK_SIZE_128_SHIFT
        aes_bytes  = len(plaintext) & (AES_BLOCK_SIZE_128 - 1)
        aes_blocks_total = aes_blocks
        if aes_bytes > 0:
            # Last block is partially filled.
            pad_bytes  = AES_BLOCK_SIZE_128 - aes_bytes
            aes_blocks_total += 1
        elif aes_blocks == 0:
            # No plaintext, so the entire block must be pad bytes.
            pad_bytes  = AES_BLOCK_SIZE_128
            aes_blocks_total = 1
        else:
            # All blocks are full.
            pad_bytes = 0

        # Break the plaintext into 128 bit (16 byte) chunks for AES.
        pt_blocks = [''] * aes_blocks_total
        idx = 0
        # Handle all the whole AES blocks.
        for i in range(0, aes_blocks):
            pt_blocks[i] = plaintext[idx:idx + AES_BLOCK_SIZE_128]
            idx += AES_BLOCK_SIZE_128
        # Handle the last/partial block, if any.
        if pad_bytes > 0:
            pt_blocks[aes_blocks] = plaintext[idx:idx + aes_bytes]
            pt_blocks[aes_blocks] += '\x80'
            for i in range(1, pad_bytes):
                pt_blocks[aes_blocks] += '\x00'

        # Mask the last block with one of the subkeys.
        if pad_bytes == 0:
            # XOR with first subkey.
            xor_key = self._subkey1
        else:
            # XOR with second subkey.
            xor_key = self._subkey2
        pt_blocks[aes_blocks_total - 1] = \
            xor_byte_strings(pt_blocks[aes_blocks_total - 1], xor_key)

        # Start hashing the plaintext.
        if init_vector:
            hash_block = init_vector[:AES_BLOCK_SIZE_128]
            if len(hash_block) < AES_BLOCK_SIZE_128:
                hash_block += '\x00' * len(hash_block)
        else:
            # No initialization vector was specified.
            hash_block = '\x00' * AES_BLOCK_SIZE_128
        for i in range(0, aes_blocks_total):
            hash_block = xor_byte_strings(hash_block, pt_blocks[i])
            hash_block = self.aes.encrypt(hash_block)

        return hash_block


    def verify(self, input_file, signature_file = None):
        """Verifies the AES-CMAC signature of the input file by computing the
           CMAC for the contents of the input file and comparing it to the
           value in the signature file. Unless explicitly specified otherwise,
           the signature file is assumed to have the same name as the input
           file suffixed with '.sig'. Returns True if the signature is valid,
           otherwise False."""

        i = open(input_file, 'rb')
        input_data = i.read()
        i.close()

        if signature_file == None:
            signature_file = input_file + '.sig'
        s = open(signature_file, 'rb')
        signature = s.read()
        s.close()
        if len(signature) != AES_KEY_SIZE_128:
            raise ValueError, "Invalid signature length %d." % len(signature)

        cmac = self.compute_cmac(input_data)
        if cmac != signature:
            return False
        else:
            return True


    def sign(self, input_file, signature_file = None):
        """Signs the input_file by computing the AES-CMAC. The resulting CMAC
           is saved to a file with the same name as the input file, except
           suffixed with '.sig', unless a different filename is explicitly
           specified."""
        i = open(input_file, 'rb')
        input_data = i.read()
        i.close()

        cmac = self.compute_cmac(input_data)

        if self.debug_enabled and self.verbosity > 1:
            _print_msg_crypto_utils("Signature: " + convert_byte_string_to_hex_string(cmac))

        if signature_file == None:
            signature_file = input_file + '.sig'
        s = open(signature_file, 'wb')
        s.write(cmac)
        s.flush()
        os.fsync(s.fileno())
        s.close()


###############################################################################
def validate_passphrase(passphrase = None):
    """Checks if the passphrase is valid. For example, verify if the length
       is reasonable (non-zero), verify that the characters in the string are
       printable but not whitespaces."""
    if passphrase == None:
        raise ValueError, "Null passphrase."
    if len(passphrase) == 0:
        raise ValueError, "Passphrase must not be zero length."

    # TODO: ideally, passphrase will have some reasonable minimum length,
    # like 12 characters.
    for c in passphrase:
        if c in string.whitespace:
            # Don't accept whitespaces.
            raise ValueError, "Passphrase contains whitespace."
        if c not in string.printable:
            raise ValueError, "Passphrase contains non-printable characters."

    return


###############################################################################
def prompt_for_passphrase(passwd = None, prompt_message = None):
    """Generates an AES-CMAC hash for a passphrase. If the password argument
       is not provided, then this routine prompts the user for a passphrase,
       validates the entered passphrase, and then re-prompts to verify the
       original passphrase. Returns the AES-CMAC hash value of the passphrase."""
    if passwd == None:
        if prompt_message != None:
            print prompt_message
        passphrase0 = getpass.getpass('Enter new passphrase: ')
        validate_passphrase(passphrase0)
        # Double check the passphrase.
        passphrase1 = getpass.getpass('Verify new passphrase: ')
        if passphrase0 != passphrase1:
            raise ValueError, "Passphrases do not match."
    else:
        passphrase0 = passwd

    # Generate the passphrase hash.
    aes_hash = AesCmac(_PASSPHRASE_GEN_KEY)
    passphrase_hash = aes_hash.compute_cmac(passphrase0, _PASSPHRASE_GEN_SALT)

    return passphrase_hash


###############################################################################
# Main program body.
###############################################################################
if __name__ == '__main__':
    print 'The Crypto utilities module is not a stand alone program.'
    sys.exit(-1)

