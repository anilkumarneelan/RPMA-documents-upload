#!/usr/bin/env python
#
# Copyright (c) 2011. OnRamp Wireless, Inc.
# All rights reserved.
#
# OnRamp Wireless, Inc makes no representations about the suitability of
# this source code for any purpose. This source code is provided "AS IS"
# and without any express or implied warranties, including, without
# limitation, implied warranties of merchantability and fitness for any
# particular purpose.

"""Logging utilities for provisioning tools."""

import logging
import sys
import re


###############################################################################
class ErrorFilter(logging.Filter):
    """Messages only printed on stdout if debug flag enabled or ERROR encountered."""

    def __init__(self, debug_flag):
        self.debug_flag = debug_flag

    def filter(self, record):
        if self.debug_flag or record.levelno == logging.ERROR:
            return True
        else:
            return False


###############################################################################
def setup_log(log_file, debug_flag = False):
    """Setups logger object, handler and formatter."""

    handler = None
    logging.getLogger().setLevel(logging.INFO)
    if log_file:
        if re.search('@', log_file):
            [name, remote_address] = re.split('@', log_file)
            handler = logging.handlers.SysLogHandler\
                      (address = (remote_address, logging.handlers.SYSLOG_UDP_PORT))
        else:
            handler = logging.FileHandler(log_file, mode = 'a')
        formatter = logging.Formatter('%(asctime)s: %(filename)s(%(module)s:' + \
                                      'line %(lineno)d): %(levelname)s: %(message)s')
        handler.setFormatter(formatter)
        logger = logging.getLogger()
        logger.addHandler(handler)

    # This should behave like print statements. No need for module name
    # or time. Just message should be fine.
    debug_handler = logging.StreamHandler()
    error_filter = ErrorFilter(debug_flag)

    debug_handler.addFilter(error_filter)
    logger = logging.getLogger()

    formatter = logging.Formatter('%(message)s')
    debug_handler.setFormatter(formatter)
    logger.addHandler(debug_handler)

    return logger


###############################################################################
# Main program body.
###############################################################################
if __name__ == '__main__':
    print 'The Log utilities module is not a stand alone program.'
    sys.exit(-1)
