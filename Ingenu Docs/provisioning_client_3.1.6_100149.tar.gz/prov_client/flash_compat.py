""" Determines firmware version to flash part compatibility """

import struct

_flashParts = {
    struct.pack('5B', 0x20, 0x80, 0x14, 0x00, 0x00) : 'Numonyx M25PE80',         
    struct.pack('5B', 0xBF, 0x25, 0x8E, 0x00, 0x00) : 'Microchip SST25VF080B',   
    struct.pack('5B', 0x1F, 0x45, 0x01, 0x01, 0x00) : 'Atmel AT25DF081A',        
    struct.pack('5B', 0x9D, 0x13, 0x44, 0x00, 0x00) : 'ISSI IS25LQ080',          
    struct.pack('5B', 0xC2, 0x20, 0x14, 0x00, 0x00) : 'Macronix MX25L8006EZNI',  
    struct.pack('5B', 0xEF, 0x40, 0x14, 0x00, 0x00) : 'Winbond W25Q80DVZPIG',    
    struct.pack('5B', 0xC2, 0x28, 0x14, 0x00, 0x00) : 'Macronix MX25R8035F',  
}    

# original supported parts
_flashSet1 = ['Numonyx M25PE80', 'Microchip SST25VF080B', 'Atmel AT25DF081A']    

# alternates added jan 2015
_flashSet2 = ['ISSI IS25LQ080', 'Macronix MX25L8006EZNI', 'Winbond W25Q80DVZPIG']

# alternate added jan 2016
_flashSet3 = ['Macronix MX25R8035F', ]

def flashNameFromIdent(flashIdent):
    # ctypes to binary string
    flashIdent = struct.pack('5B', *flashIdent)
    
    return _flashParts[flashIdent]

def isVersionCompatible(flashIdent, major, minor, point):
    # convert to integer if necessary
    major = int(major)
    minor = int(minor)
    point = int(point)

    flashType = flashNameFromIdent(flashIdent)
    
    if flashType in _flashSet1:
        # all micronode firmware supports set 1 - original parts
        return True

    # sanity check - micronode support started in 5.x.x
    if major < 5:
        return False

    if flashType in _flashSet2:
        # supported by:
        # - 1.4: node >= 5.5.0
        # - 2.1 >= 2.1.4.13 == node >= 6.5.0
        # - all (GA) 2.2
        if major == 5:
            return (minor >= 5)
        elif major == 6:
            return (minor >= 5)
        else:
            return True

    if flashType in _flashSet3:
        # supported by 2.2 >= 7.1.32
        if major < 7:
            return False
        if major == 7:
            if minor == 1:
                return (point >= 32)
            else:
                return True
        else:
            return True
            
