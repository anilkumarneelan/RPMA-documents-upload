# Transport Wrapper
# Generic: class TransportWrapper with following methods:
#        egressWrapper that takes message string input and function to call
#            with converted message string
#        ingressWrapper that takes string input and function to call with
#            converted message string.  Note that readFxn does not need to
#            be called with every call to ingressWrapper.  readFxn is
#            allowed to be called only when ingressWrapper has been called
#            a sufficient number of times with a sufficient amount of str
#            data in order to form a complete message.
# TIQ specific:
#        egressWrapper puts @01ORW string (6 bytes) at front of input string,
#          appends two byte ASCII representation of one byte checksum at end,
#          followed by two byte *\r string after checksum.
#        ingressWrapper removes @01ORW header and removes checksum and trailing
#          *\r.  It accomplishes this by maintaining a state machine.  The first
#          two bytes of the data are length of data (including the two bytes
#          of the length field).  So these two bytes are extracted and used
#          in order to determine where the checksum should be.


class TransportWrapper():
    def __init__(self, writeFxn, readFxn, logger, exceptionHandler):
        self._writeFxn = writeFxn
        self._readFxn = readFxn
        self.ingressState = ""
        self.calcCheckSum = 0

    def reInit(self):
        pass
    
    # egressWrapper is responsible for wrapping a message that is destined for the host.
    # The string passed in is one complete message.
    def egressWrapper(self, str, endpoint = 0):
        resStr = "@01ORW" + str
        csum = 0
        for x in resStr:
            csum ^= ord(x)
        if (csum/16) <= 9:
            resStr += chr(csum/16+ord("0"))
        else:
            resStr += chr(csum/16-10+ord("A"))
        if (csum%16) <= 9:
            resStr += chr(csum%16+ord("0"))
        else:
            resStr += chr(csum%16-10+ord("A"))
        resStr += "*\r"

        # send the final altered message out for tx
        self._writeFxn(resStr)

    # ingressWrapper is responsible for unwrapping a message that is received from the host.
    # Each call of this function passes the next bytes in the message.  This function may be
    # called multiple times before a complete message is formed (each call to ingressWrapper
    # is not necessarily a complete message).  It is the responsibility of ingressWrapper to
    # keep track of how much of the message is received.
    #
    # Upon reception of a complete message, ingressWrapper must call readFxn with the
    # unwrapped message.  In the event that no complete message has been received,
    # ingressWrapper does not need to call readFxn.  In the event that one call to
    # ingressWrapper contains two or more complete messages, ingressWrapper must either call
    # readFxn with the concatenated string or must call readFxn multiple times with each part
    # of the data.
    def ingressWrapper(self, str):
        retStr = ""
        for c in str:
            if self.ingressState == "":
                if c == "@":
                    self.ingressState = "@"
                    self.calcCheckSum = ord(c)
            elif self.ingressState == "@":
                if c == "0":
                    self.ingressState = "@0"
                    self.calcCheckSum ^= ord(c)
                elif c == "@":
                    self.ingressState = "@"
                else:
                    self.ingressState = ""
            elif self.ingressState == "@0":
                if c == "1":
                    self.ingressState = "@01"
                    self.calcCheckSum ^= ord(c)
                elif c == "@":
                    self.ingressState = "@"
                else:
                    self.ingressState = ""
            elif self.ingressState == "@01":
                if c == "O":
                    self.ingressState = "@01O"
                    self.calcCheckSum ^= ord(c)
                elif c == "@":
                    self.ingressState = "@"
                else:
                    self.ingressState = ""
            elif self.ingressState == "@01O":
                if c == "R":
                    self.ingressState = "@01OR"
                    self.calcCheckSum ^= ord(c)
                elif c == "@":
                    self.ingressState = "@"
                else:
                    self.ingressState = ""
            elif self.ingressState == "@01OR":
                if c == "W":
                    self.ingressState = "@01ORW"
                    self.calcCheckSum ^= ord(c)
                elif c == "@":
                    self.ingressState = "@"
                else:
                    self.ingressState = ""
            elif self.ingressState == "@01ORW":
                self.dataLen = ord(c)
                self.calcCheckSum ^= ord(c)
                self.data = c
                self.ingressState = "Length1"
            elif self.ingressState == "Length1":
                self.dataLen += 0x100*ord(c)
                self.dataLen -= 2     # account for 2 bytes in length field that was just read
                self.data += c
                self.calcCheckSum ^= ord(c)
                if self.dataLen > 0 and self.dataLen <= 510:
                    self.ingressState = "Data"
                else:
                    self.ingressState = ""
            elif self.ingressState == "Data":
                self.data += c
                self.dataLen -= 1
                self.calcCheckSum ^= ord(c)
                if self.dataLen == 0:
                    self.ingressState = "DataComplete"
            elif self.ingressState == "DataComplete":
                try:
                    self.checksum = int(c,16) * 0x10
                    self.ingressState = "Checksum1"
                except ValueError:
                    self.ingressState = ""
            elif self.ingressState == "Checksum1":
                try:
                    self.checksum += int(c,16)
                    self.ingressState = "Checksum2"
                except ValueError:
                    self.ingressState = ""
            elif self.ingressState == "Checksum2":
                if c == "*":
                    if self.checksum == self.calcCheckSum:
                        self.ingressState = "*"
                    else:
                        self.ingressState = ""
                elif c == "@":
                    self.ingressState = "@"
                else:
                    self.ingressState = ""
            elif self.ingressState == "*":
                if c == "\r":
                    retStr += self.data
                    self.data = ""
                    self.ingressState = ""
                elif c == "@":
                    self.ingressState = "@"
                else:
                    self.ingressState = ""
            else:
                # bad error: shouldn't happen and is an indication that this state machine is flawed
                self.ingressState = ""

        # notify transport that a message was completed and translated through the wrapper
        if retStr!='':
            self._readFxn(retStr)

