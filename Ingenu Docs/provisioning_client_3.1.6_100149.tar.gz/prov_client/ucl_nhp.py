"""Node-host protocol connection management."""

import warnings
import time
import traceback

import transport

class MsgLibraryWarning(UserWarning):
    '''This warning is raised if message library imports do not seem sane.'''
    pass

try:
    import node_msg_1_2
except ImportError:
    node_msg_1_2 = None

try:
    import node_msg_1_3
except ImportError:
    node_msg_1_3 = None

try:
    import node_msg_1_4
except ImportError:
    node_msg_1_4 = None
    
try:
    import node_msg_2_0
except ImportError:
    node_msg_2_0 = None

try:
    import node_msg_2_1
except ImportError:
    node_msg_2_1 = None

try:
    import node_msg_2_2
except ImportError:
    node_msg_2_2 = None

try:
    import node_msg_2_3
except ImportError:
    node_msg_2_3 = None

if node_msg_1_2 is None and node_msg_1_3 is None and node_msg_1_4 is None and \
        node_msg_2_0 is None and node_msg_2_1 is None and node_msg_2_2 is None \
        and node_msg_2_3 is None:
    warnings.warn('There are zero node message libraries. Node message operations will fail!', MsgLibraryWarning)

try:
    import host_cmn_msg
except ImportError:
    host_cmn_msg = None

if host_cmn_msg is None:
    warnings.warn('The host common message library could not be imported. Host operations will fail!', MsgLibraryWarning)

import ucl_nhp_msg

class Node(object):
    def __init__(self, idx):
        self.idx = idx
        self.present = idx == 0
        self.ver = None
        self._node_msg = None
        
        # assume earliest available until we can autodiscover
        if node_msg_1_3:
            self.node_msg = node_msg_1_3
        elif node_msg_1_4:
            self.node_msg = node_msg_1_4
        elif node_msg_2_0:
            self.node_msg = node_msg_2_0
        elif node_msg_2_1:
            self.node_msg = node_msg_2_1
        elif node_msg_2_2:
            self.node_msg = node_msg_2_2
        elif node_msg_2_3:
            self.node_msg = node_msg_2_3
        #adding 1.2 as a last resort
        elif node_msg_1_2:
            self.node_msg = node_msg_1_2
        else:
            self.node_msg = None
    
    @property
    def node_msg(self):
        return self._node_msg

    @node_msg.setter
    def node_msg(self, nodeMsgLib):
        if nodeMsgLib is None:
            warnings.warn('The msg library being set for the node at idx %s has not been imported and will not work correctly' % self.idx, MsgLibraryWarning)
        self._node_msg = nodeMsgLib
            
class Connection(transport.Connection):
    def __init__(self, commArgs, logger=None, port = 7, **kwargs):
        """Accepts standard commArgs from orwCmdLineParams."""
        self.outlog = None
        self.nodes = [Node(x) for x in range(16)]
        if "host_msg" in commArgs:
            try:
                self.host_msg = __import__(commArgs["host_msg"][-1],globals(), locals(), [], -1)
            except ImportError:
                raise ValueError("Can't import specified host specific msg lib.")
        else:
            self.host_msg = None

        # apologies for a constructor from hell, the underlying transport constructor is bogus

        def initSerial(ser_device, useMax48ByteChunks = False, baudRate = 115200, rtrctsFlowControl=False,
                       rtsToggle = False, transportWrapper="", logger=None, **kwargs):
            """Create UART type connection object"""

            import serial

            # 5 sec response timeout
            port = serial.Serial(ser_device, baudRate, timeout=5, xonxoff=0, rtscts=rtrctsFlowControl)
            port.flushInput()
            port.flushOutput()
            if rtsToggle:
                port.rtsToggle = True
            
            transport.Connection.__init__(self, 'UART', port, useMax48ByteChunks, transportWrapper,
                                          logger=logger, **kwargs)
            #connection = Connection('UART', port, useMax48ByteChunks, transportWrapper, logger=logger)

            #return connection


        def initTCPSingleNode(ip_addr, port = 7, logger=None, **kwargs):
            """Create TCP without node ID in protocol type connection object"""

            import socket

            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            #sock.setsockopt(SOL_TCP, TCP_NODELAY, 1)
            sock.connect((ip_addr, port))

            transport.Connection.__init__(self, 'TCP_SINGLE_NODE', sock, logger=logger, **kwargs)
            #connection = Connection('TCP_SINGLE_NODE', sock, logger=logger)

            #return connection


        def initTCPMultiNode(ip_addr, port = 7, logger=None, **kwargs):
            """Create TCP with node ID in protocol type connection object (superhost)"""

            import socket

            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect((ip_addr, port))

            transport.Connection.__init__(self, 'TCP_MULTI_NODE', sock, logger=logger, **kwargs)
            #connection = Connection('TCP_MULTI_NODE', sock, logger=logger)

            #return connection


        # set up a serial comm port
        if ("ip" not in commArgs) and ("serial" in commArgs):
            if "chunking" not in commArgs:
                commArgs["chunking"] = [False]
            if "flowControl" not in commArgs:
                commArgs["flowControl"] = [False]
            transportWrapper = ""
            if "wrapper" in commArgs:
                transportWrapper = commArgs["wrapper"][-1]
            rtsToggle = False
            if "rtsToggle" in commArgs:
                rtsToggle = True
            if "baud" in commArgs:
                connection = initSerial(commArgs["serial"][-1],
                                        useMax48ByteChunks=commArgs["chunking"][-1],
                                        baudRate=commArgs["baud"][-1],
                                        rtrctsFlowControl=commArgs["flowControl"][-1],
                                        transportWrapper=transportWrapper,
                                        logger=logger,
                                        rtsToggle = rtsToggle,
                                        **kwargs)
            else:
                connection = initSerial(commArgs["serial"][-1],
                                        useMax48ByteChunks=commArgs["chunking"][-1],
                                        rtrctsFlowControl=commArgs["flowControl"][-1],
                                        transportWrapper=transportWrapper,
                                        rtsToggle = rtsToggle,
                                        logger=logger,
                                        **kwargs)

        # set up TCP IP socket
        elif ("ip" in commArgs) and ("serial" not in commArgs):
            if ("portNumber" in commArgs):
                connection = initTCPSingleNode(commArgs["ip"][-1],
                                               port=commArgs["portNumber"][-1],
                                               logger=logger,
                                               **kwargs)
            else:
                connection = initTCPMultiNode(commArgs["ip"][-1],
                                              logger=logger,
                                              port=port,
                                              **kwargs)

        else:
            raise ValueError("Either serial comm or IP address must be specified.")

        return connection


    def createMsgByName(self, msgName, node_idx = 0):
        """create message class from name.

        Note that if there are overlapping names between message defs, this implies a
        decision order. User scripts can create messages from a particular source if
        desired. Should be rare, though.
        """
        msg = None

        if self.nodes[node_idx].node_msg and hasattr(self.nodes[node_idx].node_msg, msgName):
            msg = eval('self.nodes[node_idx].node_msg.' + msgName)()
        elif host_cmn_msg and hasattr(host_cmn_msg, msgName):
            msg = eval('host_cmn_msg.' + msgName)()
        elif self.host_msg and hasattr(self.host_msg, msgName):
            msg = eval('self.host_msg.' + msgName)()

        return msg
            
    def createMsgById(self, msgId, node_idx = 0):
        """create message object from ID."""

        if self.nodes[node_idx].node_msg:
            for msg in self.nodes[node_idx].node_msg.messages:
                obj = msg()
                if obj.header.msgType == msgId:
                    return obj
        if host_cmn_msg:
            for msg in host_cmn_msg.messages:
                obj = msg()
                if obj.header.msgType == msgId:
                    return obj
        if self.host_msg:
            for msg in self.host_msg.messages:
                obj = msg()
                if obj.header.msgType == msgId:
                    return obj
        return None
    
    def sendMsg(self, msg, timeout = 20.0, node_idx = 0, retries=0):
        """Sends host_msg.Message objects.

        Messages will be retried if retries is non-zero (-1 for infinitely)"""

        acked = False

        if hasattr(msg, "RHT_ENDPOINT"):
            endpoint = msg.RHT_ENDPOINT
        else:
            endpoint = 0
            
        while not acked:
            if hasattr(msg, "_msgType"):
                acked = self.sendPackedMsg(msg._msgType, msg.get_string(), timeout=timeout, \
                                       node_idx=node_idx, endpoint = endpoint)
            elif hasattr(msg, "header" ) and hasattr( msg.header, "msgType" ):
                acked = self.sendPackedMsg(msg.header.msgType, msg.get_string(), timeout=timeout, \
                                       node_idx=node_idx, endpoint = endpoint)

            if not retries:
                break
            else:
                retries -= 1

        return acked

    def getMsg(self, timeout = 20.0, node_idx = 0):
        """Gets a message as a msg.Message (from a specified node if on shost)"""

        # get binary msg ...
        (rsp_len, rsp_type, rsp_body) = self.getPackedMsg(timeout=timeout, node_idx=node_idx)

        msg = self.get_msg_for_three_tuple(node_idx, rsp_len, rsp_type, rsp_body)

        return msg
        
    def getMsgAnyNode(self, timeout = 20.0):
        """Gets a message as a msg.Message (from a specified node if on shost)"""
        
        # get binary msg ...
        (node, rsp_len, rsp_type, rsp_body) = self.getPackedMsgAnyNode(timeout=timeout)

        msg = self.get_msg_for_three_tuple(node, rsp_len, rsp_type, rsp_body)

        return (node, msg)

    def get_msg_for_three_tuple(self, node_idx, rsp_len, rsp_type, rsp_body):
        msg = None
        if rsp_len == -1:
            return None
        else:
            if rsp_type & ucl_nhp_msg.ROUTING_FLAG_HOST_COMMON:
                if host_cmn_msg:
                    msg = host_cmn_msg.get_msg_for_three_tuple(rsp_len, rsp_type, rsp_body)
            elif rsp_type & ucl_nhp_msg.ROUTING_FLAG_HOST_SPECIFIC:
                if self.host_msg:
                    msg = self.host_msg.get_msg_for_three_tuple(rsp_len, rsp_type, rsp_body)
            else:
                if self.nodes[node_idx].node_msg:
                    msg = self.nodes[node_idx].node_msg.get_msg_for_three_tuple(rsp_len, rsp_type, rsp_body)
        if msg:
            return msg
        else:
            # import host_msg
            # import unil_log_3_0_31 as unil_log

            # if rsp_type == host_msg.types["HOST_LOG_ENTRY_IND"]:
            #     try:
            #         logEntry = unil_log.LogEntryStruct(rsp_body[0:8])
            #         print "[%11.1f s] %-45s %s" % (logEntry._timestamp, logEntry._eventStr, logEntry._descStr)
            #     except:
            #         print "exception creating log entry"
            # else:
            #     print 'non-parseable msg: len %d type 0x%x %s' \
            #           % (rsp_len, \
            #              rsp_type, \
            #              "[" + " ".join(["%02X" % ord(char) for char in rsp_body]) + "]")
            pass
        
    def sendMsgGetRsp(self, req, rsp, timeout=0.1, node_idx=0):
        """Combines sendMsg with getMsgById."""

        # bit of a hack - allow the user to increase timeout above
        # defaults, but allow minimal ID timeout ... should really be
        # two params.
        if timeout > 20:
            ack = self.sendMsg(req, timeout=timeout, node_idx=node_idx)
        else:
            ack = self.sendMsg(req, node_idx=node_idx)
        if not ack:
            return None
        return self.getMsgById(rsp, timeout=timeout, node_idx=node_idx)

    def getMsgById(self, rsp, timeout=0.1, node_idx=0, idMatchTimeout = 20):
        """Reads any messages coming from the connection and returns the first
        message with a type that matches rsp.

        Non-matching messages are dropped."""

        # can be called with a rsp arg that is a message class, a message
        # class instance, or a numeric msg ID. This bit of kludgy code
        # finds a numeric msg ID given any of these ...
        try:
            if isinstance(rsp, ucl_nhp_msg.Message):
                _type = rsp._msgType
            elif issubclass(rsp, ucl_nhp_msg.Message):
                _type = rsp()._msgType
        except TypeError:
            _type = int(rsp)
        
        rsp_type = None
        msg = None
        
        idMatchStartTick = time.time()
        while rsp_type != _type and idMatchTimeout + idMatchStartTick > time.time():
            (rsp_len, rsp_type, rsp_body) = self.getPackedMsg(timeout=timeout, node_idx=node_idx)

        if rsp_type != _type:
            # timeout
            return None
        
        msg = self.get_msg_for_three_tuple(node_idx, rsp_len, rsp_type, rsp_body)

        return msg

    def interrogate_nodes(self, nodes=set([0])):
        """Communicates with some or all nodes to determine their message interfaces."""

        for n in nodes:
            node_msg = self.nodes[n].node_msg
            if not node_msg:
                return
            
            rsp = self.sendMsgGetRsp(node_msg.GET_VERSION_REQ(), node_msg.GET_VERSION_RSP, node_idx=n)
            if rsp == None:
                raise IOError, "Invalid response while interrogating node %d." % n

            if rsp.major == 8 and rsp.minor >= 0:
                self.nodes[n].node_msg = node_msg_2_3
            elif rsp.major == 7 and rsp.minor >= 0:
                self.nodes[n].node_msg = node_msg_2_2
            elif rsp.major == 6 and rsp.minor >= 3:
                self.nodes[n].node_msg = node_msg_2_1
            elif rsp.major == 6 and rsp.minor in (0, 1, 2):
                self.nodes[n].node_msg = node_msg_2_0
            elif rsp.major == 5 and rsp.minor >= 2:
                self.nodes[n].node_msg = node_msg_1_4
            elif rsp.major == 5 and rsp.minor == 1:
                self.nodes[n].node_msg = node_msg_1_3
            elif rsp.major == 4 and rsp.minor == 5:
                self.nodes[n].node_msg = node_msg_1_2
            else:
                raise IOError, "Message library unknown for node version %d.%d.%d" % (rsp.major, rsp.minor, rsp.point)
            self.nodes[n].ver = rsp
        
    def set_node_msg_intf(self, n=0, intf='1.3'):
        """Explicitly sets a node's message interface."""

        if intf == '1.2':
            self.nodes[n].node_msg = node_msg_1_2
        elif intf == '1.3':
            self.nodes[n].node_msg = node_msg_1_3
        elif intf == '1.4':
            self.nodes[n].node_msg = node_msg_1_4
        elif intf == '2.0':
            self.nodes[n].node_msg = node_msg_2_0
        elif intf == '2.1':
            self.nodes[n].node_msg = node_msg_2_1
        elif intf == '2.2':
            self.nodes[n].node_msg = node_msg_2_2
        elif intf == '2.3':
            self.nodes[n].node_msg = node_msg_2_3
        else:
            raise IOError, "Message library unknown for node version %s" % intf

    def set_host_msg_intf(self, msg_intf):
        """Explicitly sets a host's host-specificmessage interface."""

        self.host_msg = msg_intf


    def node(self, n=0):
        """Returns an object describing what is known about a node."""
        return self.nodes[n]
