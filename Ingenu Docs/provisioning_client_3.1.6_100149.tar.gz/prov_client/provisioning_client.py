#!/usr/bin/env python

# Copyright (c) 2012. OnRamp Wireless, Inc.
# All rights reserved.
#
# OnRamp Wireless, Inc makes no representations about the suitability of
# this source code for any purpose. This source code is provided "AS IS"
# and without any express or implied warranties, including, without
# limitation, implied warranties of merchantability and fitness for any
# particular purpose.

"""
Provisioning client top level script. Used to update FW, config, and
security keys of a node.
"""

# These are standard python libraries
import sys
import time
import logging
import traceback

import ucl_nhp
import provisioning_error as p_err
import sw_upgrade
import config_node
import provision_node_keys
import orwCmdLineParams
import npt_comm
import node_utils
import provisioning_version

def provision(conn, logger, debug, config_id, server_ip_addr, server_port, 
              node_idx = 0, server_batch=0, config = None, firmware = None,
              provisionKeys = True, path_in = '', path_out = '', configAlias = None,
              useSSL=True, server_keyfile='key.pem', client_keyfile='key.pem',
              client_key_password='onramp'):

    if debug:
        verbosity = 2
    else:
        verbosity = 0
    
    node_intf = node_utils.NodeInterface(conn, logger, node_idx = node_idx, verbosity = verbosity)
    node_id = node_intf.get_node_id()
    logger.info('Node ID: 0x%x' % node_id)

    (major, minor, point, stamp) = node_intf.get_node_version()
    curr_node_version = '%d.%d.%d' % (major, minor, point)
    logger.info('Node version: %s (%s)' % (curr_node_version, stamp))

    node_type = node_intf.get_node_type()
    logger.info('Node type %s' % node_type)

    # Force node to idle state
    node_intf.set_node_idle()
    
    # allow local overrides
    if not server_ip_addr:
        logger.warning('No server specified - can\'t provision keys, only local config and fw supported.')
        provisionKeys = False
        node_config = config
        node_version = '255.255.255'
        node_firmware = firmware
    else:
        server = npt_comm.ProvisioningServerInterface(
            logger, server_ip_addr, server_port, debug,
            useSSL=useSSL, server_keyfile=server_keyfile,
            client_keyfile=client_keyfile, client_key_password=client_key_password)
        
        cfg = server.getConfig(node_id, node_type, config_id, path_in, path_out, configAlias)
        if not cfg.node_files:
            err_s = 'No node info in cfg response!'
            logger.critical(err_s)
            raise p_err.ULPProvisioningError(p_err.ErrorCodes.UPGRADE_BAD_IMAGE, err_s)

        if config:
            node_config = config
        else:
            node_config = cfg.node_files.field_config_path
        
        if firmware:
            node_version = '255.255.255'
            node_firmware = firmware
        else:
            node_version = cfg.node_version
            node_firmware = cfg.node_files.firmware_path
            
    if node_version == curr_node_version:
        logger.info('Already running target version')
    elif node_firmware:
        logger.info('Upgrading node from %s to %s' % (curr_node_version, node_version))

        try:
            img_f = file(node_firmware, 'rb')
        except IOError:
            err_s = 'Unable to open supplied image filename'
            logger.critical(err_s)
            raise p_err.ULPProvisioningError(p_err.ErrorCodes.UPGRADE_BAD_IMAGE, err_s)
            
        img = img_f.read()
        img_f.close()

        upgrader = sw_upgrade.nodeFwUpgrade( \
            conn, node_idx, interactive = False, quietMode = False)
        upgrader.do_upgrade(img, node_firmware)

        time.sleep(10)
        
        conn.interrogate_nodes([node_idx,])
        
        (major, minor, point, stamp) = node_intf.get_node_version()
        curr_node_version = '%d.%d.%d' % (major, minor, point)
        if node_version == curr_node_version:
            logger.info('Upgrade successful')
        elif node_version != '255.255.255':
            err_s = 'Upgrade resulted in version %s instead of %s!' % \
                (curr_node_version, node_version)
            logger.error(err_s)
            raise p_err.ULPProvisioningError(p_err.ErrorCodes.VERIFICATION_FAILED, err_s)
        
        # Force node back to idle state
        node_intf.set_node_idle()        
    # end of node FW upgrade
    
    if node_config:
        logger.info('Configuring node from %s' % node_config)

        try:
            img_f = file(node_config, 'r')
        except IOError:
            err_s = 'Unable to open supplied node config filename'
            logger.critical(err_s)
            raise p_err.ULPProvisioningError(p_err.ErrorCodes.CONF_FILE_INVALID, err_s)
        img_f.close()
        
        configurator = config_node.nodeConfigurator(conn, node_idx = node_idx, logger=logger)
        configurator.doConfig(node_config, True)

        logger.info('Node configuration successful')

    if provisionKeys:
        (timestamp, encryptedNodeKey) = \
            provision_node_keys.provisionNode(node_intf, cfg.gw_wide_key, cfg.gw_cdld_key,
                                              cfg.kms_pub_key, node_id, config_id)

        # tell server about results
        server.setDutParams(timestamp, config_id, server_batch, node_id,
                         nodeKey = encryptedNodeKey, configAlias = configAlias)
        if verbosity > 0:
            logger.info("params sent to server for node 0x%08x." % node_id)

def usage(err_s = None):
    """Prints the help/usage text."""
    if err_s:
        print "Error: %s\n" % err_s
    print "Usage:  %s [OPTION]" % sys.argv[0]
    print """
Node provisioning client. Performs node firmware updates, configuration, and
key provisioning. Can (and for key provisioning must) fetch required data
from a provisioning server, or config and firmware files can be specified on
the command line.

OPTIONS:
    -i <IP:INDEX>, --ip=<IP:INDEX>
        IP address and node index 0-15 (eg 192.168.0.1:9).
    -i <IP:PORT>, --ip=<IP:PORT>
        IP address and port 16-65535 (eg -i 192.168.0.1:5001).
    -d <serial_port>, --device=<serial_port>
        Comm port to use for communication with node.
    -s <ip_addr>[:<port>], --server=<ip_addr>[:<port>]
        The IP address or hostname of the provisioning server.
        The TCP port number of the provisioning server.
    -B <provisioning_batch>, --batch=<provisioning_batch>
        The batch number for the current provisioning run. The batch number is
        an arbitrary integer number that can be assigned to each provisioning
        run of one or more nodes for tracking purposes. The batch number is
        saved in the server key database and can be used to select keys for key
        export.
    --skip-keys
        Skip key provisioning
    -p <prov_config_id>, --config-id=<prov_config_id>
        Unique ID for the provisioning configuration - 64 bit integer defining
        the target network, application, and configuration.
    --config-alias=<alias>
        Use a string alias for config ID rather than a numeric ID
    --disable-ssl
        Turn off SSL for the provisioning server connection (requires equivalent
        configuration of the server)
    --ssl-set-server-cert=<pem_file>
        Specify server certificate openssl PEM file (default key.pem)
    --ssl-set-client-cert=<pem_file>
        Specify client certificate openssl PEM file (default key.pem)
    --ssl-set-client-cert-passwd=<password>
        Private key access password for the client certificate
    --local-firmware-file=<node_firmware>
        Specify a local file containing node firmware.
    --local-config-file=<node_config>
        Specify a local file containing node config.
    --verbosity=<0-2>
        0 prints critical errors only to stdout
        1 prints warning and above to stdout (default)
        2 prints debug and above to stdout
    --path_trans_from=<string>, --path_trans_to=<string>
        Allow re-writing of base path in files referenced in xml from server.
        For example, "--path_trans_from=/workspace --path_trans_to=z:" might
        allow sharing a single server between windows and linux clients.
    --logfile=<logname>
        Write diagnostics to specified logfile
    --version
        Print provisioning version and exit
    -h, --help
        Prints this help message.
EXAMPLE:
    %s -d COM1 -s server_ip -B 1000 --config-id=0x12345678abc
    """ % sys.argv[0]

def setupLogger(verbosity, logfile):
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    # set up console handler
    ch = logging.StreamHandler()
    ch.setFormatter(logging.Formatter('%(levelname)s: %(message)s'))
    if verbosity == 1:
        ch.setLevel(logging.WARNING)
    elif verbosity >= 2:
        ch.setLevel(logging.DEBUG)
    else:
        ch.setLevel(logging.CRITICAL)
    logger.addHandler(ch)

    # set up file handler if file specified
    if logfile:
        file_handler = logging.FileHandler(logfile, mode='w')  
        file_handler.setLevel(logging.DEBUG)  
        formatter = logging.Formatter( \
            "%(asctime)s %(levelname)-8s %(filename)-20s %(lineno)-5d: %(message)s")  
        file_handler.setFormatter(formatter)  
        logger.addHandler(file_handler)  
        
    return logger

def cmdLineMain():
    short_opts = "s:B:p:h"
    long_opts = ["server=", "batch=", "skip-keys", "config-alias=",
                 "help", "verbosity=", "logfile=", "version",
                 "config-id=", "path_trans_from=", "path_trans_to=",
                 "local-firmware-file=", "local-config-file=",
                 "disable-ssl", "ssl-set-server-cert=",
                 "ssl-set-client-cert=", "ssl-set-client-cert-passwd="]

    pargs = dict()
    pargs['server_ip_addr'] = None                  # server IP address or hostname.
    pargs['server_port'] = 8085                     # server port number.
    pargs['server_batch'] = 0                       # Provisioning batch number.
    pargs['config_id'] = None
    pargs['provisionKeys'] = True
    pargs['config'] = None
    pargs['firmware'] = None
    pargs['path_in'] = ''
    pargs['path_out'] = ''
    pargs['config_alias'] = None
    pargs['config_id'] = 0
    
    logfile = None
    verbosity = 1

    useSSL = True
    server_cert = 'key.pem'
    client_cert = 'key.pem'
    client_cert_passwd = 'onramp'
    
    try:
        (commArgs, extraOptions, args) = \
            orwCmdLineParams.parseParams(sys.argv[1:], short_opts, long_opts)
    except:
        traceback.print_exc()
        sys.exit(-1)
                 
    for (opt, val) in extraOptions.items():
        if opt in ("-s", "--server"):
            ipVals = val[-1].split(":")
            pargs['server_ip_addr'] = ipVals[0]
            if len(ipVals)==2:
                pargs['server_port'] = int(ipVals[1], 0)
        elif opt in ("-B", "--batch"):
            pargs['server_batch'] = int(val[-1], 0)
        elif opt == "--verbosity":
            verbosity = int(val[0])
        elif opt == "--logfile":
            logfile = val[0]
        elif opt == "--skip-keys":
            pargs['provisionKeys'] = False
        elif opt in ("-p", "--config-id"):
            pargs['config_id'] = int(val[0], 0)
        elif opt == "--local-config-file":
            pargs['config'] = val[0]
        elif opt == "--disable-ssl":
            useSSL = False
        elif opt == "--ssl-set-server-cert":
            server_cert = val[0]
        elif opt == "--ssl-set-client-cert":
            client_cert = val[0]
        elif opt == "--ssl-set-client-cert-passwd":
            client_cert_passwd = val[0]
        elif opt == "--local-firmware-file":
            pargs['firmware'] = val[0]
        elif opt == "--path_trans_from":
            pargs['path_in'] = val[0]
        elif opt == "--path_trans_to":
            pargs['path_out'] = val[0]
        elif opt == "--config-alias":
            pargs['config_alias'] = val[0]
        elif opt == "--version":
            print 'provisioning version %u.%u.%u' % (
                provisioning_version.VERSION_MAJOR, provisioning_version.VERSION_MINOR, provisioning_version.VERSION_BUILD)
            sys.exit(0)
        elif opt in ("-h", "-?", "--help"):
            usage()
            sys.exit(0)
        else:
            usage("Invalid option '%s'." % opt)
            sys.exit(-1)

    conn = None
    res = -1
    debug = (verbosity >= 2)
    
    try:
        logger = setupLogger(verbosity, logfile)

        try:
            conn = ucl_nhp.Connection(commArgs)
        except:
            if debug:
                traceback.print_exc()
            raise p_err.ULPProvisioningError(p_err.ErrorCodes.COMM_OPEN_FAILURE, 
                                             target=p_err.CommType.LOCAL_ERROR)
        
        conn.interrogate_nodes(commArgs['nodeIndex'])
        provision(conn, logger, debug,
                  pargs['config_id'], pargs['server_ip_addr'], pargs['server_port'],
                  node_idx = commArgs['nodeIndex'][-1],
                  server_batch = pargs['server_batch'],
                  config = pargs['config'],
                  firmware = pargs['firmware'],
                  provisionKeys = pargs['provisionKeys'],
                  path_in = pargs['path_in'],
                  path_out = pargs['path_out'],
                  configAlias = pargs['config_alias'],
                  useSSL = useSSL,
                  server_keyfile = server_cert,
                  client_keyfile = client_cert,
                  client_key_password = client_cert_passwd)
        res = 0
        
    except p_err.ULPProvisioningError as e:
        if debug:
            traceback.print_exc()
        logger.critical(str(e))
        res = (e.target << 5) | (e.errorCode & 0x1F)
    except IOError:
        if debug:
            traceback.print_exc()
        logger.critical('I/O error')
        res = p_err.ErrorCodes.COMM_FAILURE
    except:
        if debug:
            traceback.print_exc()
        logger.critical('Unknown error: %s' % traceback.format_exc())
        res = p_err.ErrorCodes.UNKNOWN_PROVISIONING_ERROR
    finally:
        if conn:
            conn.close()
    sys.exit(res)

if __name__ == "__main__":
    cmdLineMain()
    
