'''
FILE NAME: orwCmdLineParams.py

DESCRIPTION: parses command line parameters common to tools that communicate with node
             pass back dictionary of parsed params and string of unparsed params

(c) Copyright 2011
'''

import os
import getopt

# valid range of node index: 0-15
MAX_NODE_INDEX = 15


def _addToDict(dictVar,key,value):
    if key not in dictVar:
        dictVar[key]=[]
    dictVar[key].append(value)

# returns a tuple of:
#     - dictionary of standard args
#     - dictionary of extra args
#     - list of arguments after command line params
def parseParams(cmdLine, extraShortArgs=None, extraLongArgs=None, useGnuGetopt=False):
    options = dict()
    extraOptions = dict()

    # -d: serial comm port
    # -b: baud rate (serial only)
    # -i: ip address, followed by ':', followed by either node index (0-15) or port number (16+)
    # -c: chunking (serial only)
    # -l: logdict
    # -f: flow control (serial only)
    shortArgs = "d:b:i:l:fc"
    longArgs = ["device=", "baud=", "ip=", "flow-control", "chunking", "logdict=", "wrapper=", "host-msg=", "rts-toggle"]

    if extraShortArgs is not None:
        # verify that extra args are not same as standard shared args
        for index in range(len(extraShortArgs)):
            arg = extraShortArgs[index]
            if arg != ":":
                if arg in shortArgs:
                    errorMsg = "option %s already a standard shared short argument" % arg
                    raise ValueError(errorMsg)
        shortArgs += extraShortArgs
    if extraLongArgs is not None:
        # verify that extra args are not same as standard shared args
        for arg in extraLongArgs:
            if arg[-1]=='=':
                arg = arg[:-1]
            if arg in longArgs:
                errorMsg = "option %s already a standard shared long argument" % arg
                raise ValueError(errorMsg)
        longArgs += extraLongArgs
    try:
        if useGnuGetopt:
            (opts, remains) = getopt.gnu_getopt(cmdLine, shortArgs, longArgs)
        else:
            (opts, remains) = getopt.getopt(cmdLine, shortArgs, longArgs)
    except getopt.GetoptError, detail:
        raise ValueError(detail)

    for(opt, val) in opts:
        if opt in ("-d", "--device"):
            #options['serial'] = val
            _addToDict(options,'serial',val)
        elif opt in ("-b", "--baud"):
            #options['baud'] = int(val)
            _addToDict(options,'baud',int(val))
        elif opt in ("-i", "--ip"):
            ipParams = val.split(":")
            #options['ip'] = ipParams[0]
            _addToDict(options,'ip',ipParams[0])
            if len(ipParams)>=2:
                ipVal = int(ipParams[1])
                if ipVal <= MAX_NODE_INDEX:
                    #options['nodeIndex'] = ipVal
                    _addToDict(options,'nodeIndex',ipVal)
                else:
                    #options['portNumber'] = ipVal
                    _addToDict(options,'portNumber',ipVal)
        elif opt in ("-f", "--flow-control"):
            #options['flowControl'] = True
            _addToDict(options,'flowControl',True)
        elif opt in ("-c", "--chunking"):
            #options['chunking'] = True
            _addToDict(options,'chunking',True)
        elif opt in ("-l", "--logdict"):
            _addToDict(options,'logdict',val)
        elif opt in ("--wrapper",):
            #options['wrapper'] = val
            _addToDict(options,'wrapper',val)
        elif opt in ("--rts-toggle",):
            _addToDict(options,'rtsToggle',True)
        elif opt in ("--host-msg",):
            #options['wrapper'] = val
            _addToDict(options,'host_msg',val)
        else:
            #extraOptions[opt] = val
            _addToDict(extraOptions,opt,val)
            
    if 'nodeIndex' not in options:
        #options['nodeIndex'] = 0
        _addToDict(options,'nodeIndex',0)

    # add default serial port if not serial port or IP address was defined
    if ("serial" not in options) and ("ip" not in options):
        if os.name == 'nt':
            defaultSerialDev = 'COM1'
        elif os.name == 'posix':
            defaultSerialDev = '/dev/ttyS0'
        else:
            #print "Unknown OS '%s'" % os.name
            defaultSerialDev = '/dev/ttyS0'
        #options['serial'] = defaultSerialDev
        _addToDict(options,'serial',defaultSerialDev)

    if "logdict" in options:
        import parsePackedDbg
        parsePackedDbg.initFromArgDict(options)
        
    return (options, extraOptions, remains)

# returns an array of text strings that describe the usage of the common cmd line params
def usageLong():
    return ['-d <SERDEV>, --device=<SERDEV>\n\tSerial device name (eg COM1, /dev/ttyUSB0).',
            '-b <BAUD>, --baud=<BAUD>\n\tSerial baud rate (default 115200).',
            '-c, --chunking\n\tRestrict max serial data chunk size to 48 bytes.',
            '-f, --flow-control\n\tEnables serial flow control.',
            '-l, --logdict\n\tProvide a mapping dict from binary packed log messages to strings.',
            '--wrapper=<FILE>\n\tApply wrapper transport_wrapper/wrapper_FILE.py to serial in/out.',
            '--host-msg=<FILE>\n\tProvide host specific UCL message library.',
            '-i <IP:INDEX>, --ip=<IP:INDEX>\n\tIP address and node index 0-15 (eg 192.168.0.1:9).',
            '-i <IP:PORT>, --ip=<IP:PORT>\n\tIP address and port 16-65535 (eg -i 192.168.0.1:5001).',
            '--rts-toggle\n\tWindows only - enable RTS toggle function',]

def usageShort():
    return '[-d <SERDEV> | -i <IP:INDEX|PORT>] [-c] [-f] [-l <logdict>] [--wrapper=<FILE>] [--host-msg=<FILE>]'

