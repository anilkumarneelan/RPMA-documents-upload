#!/usr/bin/env python
#
# Copyright (c) 2010. OnRamp Wireless, Inc.
# All rights reserved.
#
# OnRamp Wireless, Inc makes no representations about the suitability of
# this source code for any purpose. This source code is provided "AS IS"
# and without any express or implied warranties, including, without
# limitation, implied warranties of merchantability and fitness for any
# particular purpose.

"""ULP eNode Configuration Flash Read Utility. Reads the flash configuration
   sector in the node and prints the configuration data to a text file."""

import sys

import orwCmdLineParams
    
global _verbosity
global _ignore_ack_errors
_verbosity = 0
_ignore_ack_errors = False

# Maximum number of APs in the AP list.
_MAX_AP_LIST_SIZE = 24

# Text for config file.
_preamble = \
"""\
# Node Configuration Template.
#
# This template is provided as a reference only. Use the node configuration
# file provided by the On-Ramp Wireless Deployment Group for configuring
# nodes. The configuration file should not be modified. Modification of the
# configuration file will result in device malfunction.
"""

_hdr_country_code = \
"""
# Country code where the node will be deployed.
# See http://en.wikipedia.org/wiki/ISO_3166-1_numeric
"""

_hdr_max_tx_power = \
"""
# Maximum transmit power in dBm (valid range is 0 to 25)
"""

_hdr_operating_mode = \
"""
# Configures node to expect a host interface (0) or hostless (4).  Most
# products contain a host which communicates with the node and should set
# this to 0.
"""

_hdr_autorun = \
"""
# Configures whether the node attempts to join the network autonomously (1)
# or waits for host instruction to do so (0).  Must be set to 1 if the
# operating mode is set to hostless.
"""

_hdr_sys_sel_sleep_timer_min = \
"""
# Minimum system selection sleep timer.  This controls the lower bound for
# the exponential backoff between system selection failures.  Units are
# in seconds.
"""

_hdr_sys_sel_sleep_timer_max = \
"""
# Maximum system selection sleep timer.  This controls the upper bound for
# the exponential backoff between system selection failures.  Units are
# in seconds.
"""

_hdr_system_id = \
"""
# System ID.  Must match the system ID configured in the gateway.  Valid
# range is 0 to 255.
"""

_hdr_ap_list = \
"""
# AP list.  There are 24 pairs of channnels and reuse codes that must match
# the configuration of AP's deployed in the network (or that will be in the
# future).
#
#   channel - A number from 1 to 50.
#   reuse - A number from 0 to 255.
#
# For unused AP's in the list leave the channel set to 255.
"""

_hdr_flash_config_version = \
"""
# Keep this hard-coded.
"""

_hdr_join_type = \
"""
# The default join type. Set to 15 for CMAC-28 (recommended), 0 for
# CMAC-32.
"""

_hdr_join_backoff_type = \
"""
# The join backoff type.  Set to 1 for random join backoffs
# (recommended) or 0 for non-random (may make sense in some
# latency-sensitive mobility cases).
"""

_hdr_tcxo_freq = \
"""
# The initial TXCO frequency correction value. Set this to 0.
"""

_hdr_field_test_num_pdus_per_frame = \
"""
# The number of PDU's to send per frame in field test mode. Set to 0.
"""

_hdr_field_test_num_frame_period = \
"""
# The number frames between TXing in field test mode. Set to 0.
"""

_hdr_field_test_ul_rssi_margin = \
"""
# The hard-coded UL RSSI margin for field test mode. Set to 0.
"""

_hdr_dl_bcast_spreading = \
"""
# The DL broadcast spreading factor. Must be set to 11 for 2K broadcast
# spreading factor.
"""

_hdr_ota_dwnld_node_type_init_seq = \
"""
# CDLD sequence/type encoding. Set this field to 0 for 1.2 deployments.
#
# Encoding:
#
# bits 7:4 - CDLD node type
# bits 3:2 - CDLD broadcast OTA sequence number
# bits 1:0 - CDLD OTA sequence number
"""

_hdr_sys_sel_immediate_join_threshold = \
"""
# System selection immediate join threshold in <12.4s> format. Consult
# system selection documentation for correct value. Set this field to 0
# for single frequency network and -112*16 for multi frequency networks.
"""

_hdr_high_abs_ap_proper_join_threshold_db = \
"""
# dB above sensitivity to join an AP proper over an uncongested repeater
"""
_hdr_low_abs_ap_proper_join_threshold_db = \
"""
# dB above sensitivity to join an AP proper over a congested repeater
"""

_hdr_sys_sel_max_freq_optimized_passes = \
"""
# System selection max number of frequency optimized passes. Consult
# system selection documentation. Set this field to 15.
"""

_hdr_antenna_diversity_enabled = \
"""
# Antenna Diversity Enabled
"""

_hdr_tx_duty_cycle_percent = \
"""
# Max tx duty cycle [1:100]
"""

_hdr_max_delay_during_outage = \
"""
# max number of frames to randomly back off in power fail mode
"""
                             
_hdr_battery_rescan_ui_count = \
"""
# Battery Rescan UI Count
"""

def usage(s=''):
    """Prints the help/usage text."""
    if s:
        print "Error: %s\n" % s

    print "Usage:  %s [OPTION]" % sys.argv[0]
    print """
Node configuration flash sector programming utility. Imports the user settable
node configuration parameters and programs the configuration sector in flash.

OPTIONS:
"""
    for usageStr in orwCmdLineParams.usageLong():
        print "    %s" % usageStr

    print """    -E <output_file>, --extract=<output_file>
        Extract existing configuration data from node and save to the specified
        text output file.
    -v, --verbose:
        Increase verbosity level.
    -a, --ignore:
        Ignore ACK failures.
    -h, --help:
        Prints this help message.

EXAMPLE:
    %s -d COM1 -E node_config_output.txt
    """ % sys.argv[0]


def connect(connection):
    """Sends a connect message."""
    # Note: no need to connect to the node just to write its flash config.
    # 'Connect' means to receive any asynchronous data the node may have
    # for the host, which we don't want.
    connect = node_msg.CONNECT(connected=1)
    ack = connection.sendMsg(connect)
    if not ack:
        if not _ignore_ack_errors:
            raise IOError, "Failed to get ACK for CONNECT request."
        else:
            if _verbosity > 0:
                print "Failed to get ACK for CONNECT request."
    if _verbosity > 0:
        print "Connected to host."


def disconnect(connection):
    """Sends a disconnect message."""
    connect = node_msg.CONNECT(connected=0)
    ack = connection.sendMsg(connect)
    if not ack:
        if not _ignore_ack_errors:
            raise IOError, "Failed to get ACK for DISCONNECT request."
        else:
            if _verbosity > 0:
                print "Failed to get ACK for DISCONNECT request."
    if _verbosity > 0:
        print "Disconnected from host."


def read_node_config_flash(connection, node_idx = 0):
    """Reads and returns the node's configuration flash sector."""
    msg = connection.sendMsgGetRsp(node_msg.READ_FLASH_CONF(), node_msg.READ_FLASH_CONF_RSP, node_idx = node_idx )
    if msg is None:
        raise IOError, "Response message never received for reading node config flash."
  
    cfg_version = msg.configData.v3.version
    if hasattr(msg.configData, "v%d" % cfg_version):
        # Return the flash configuration union, not one of the union elements.
        return eval("msg.configData.v%d" % cfg_version)
  
    if _verbosity > 0:
        print "Unknown flash configuration version %d" % cfg_version
        if _verbosity > 2:
            print str(msg.configData)
    raise ValueError, "Unknown flash configuration version %d" % cfg_version


def read_ap_list_flash(connection, node_idx = 0):
    """Reads and returns the node's AP List flash sector."""
    msg = connection.sendMsgGetRsp(node_msg.READ_FLASH_AP_LIST_REQ(), node_msg.READ_FLASH_AP_LIST_RSP, node_idx = node_idx )
    if msg is None:
        raise IOError, "Response message never received for reading node ap list."
    
    return msg.apList

def dump_config_to_file(e, cfg):
    # Start writing the config data to the output file.
    e.write(_preamble)

    e.write(_hdr_country_code)
    e.write("country_code = %d\n" % cfg.countryCode)

    e.write(_hdr_max_tx_power)
    e.write("max_tx_power = %d\n" % cfg.maxTxPwrLimit)

    e.write(_hdr_operating_mode)
    e.write("operating_mode = %d\n" % cfg.operatingMode)

    e.write(_hdr_autorun)
    e.write("autorun = %d\n" % cfg.autorun)

    sleep_timer_min = cfg.sysSelMinSleepTimer
    if sleep_timer_min%60 == 0:
        # Show as a product of minutes times 60 seconds per minute.
        sleep_timer_min = cfg.sysSelMinSleepTimer / 60
        e.write(_hdr_sys_sel_sleep_timer_min)
        e.write("sys_sel_sleep_timer_min = %d*60\n" % sleep_timer_min)
    else:
        e.write(_hdr_sys_sel_sleep_timer_min)
        e.write("sys_sel_sleep_timer_min = %d\n" % sleep_timer_min)
    
    sleep_timer_max = cfg.sysSelMaxSleepTimer
    if(sleep_timer_max % (60*60) == 0):
        # Show as a product of hours times 60 minutes per hour times 60 seconds per minutes.
        sleep_timer_max = cfg.sysSelMaxSleepTimer / 60 / 60
        e.write(_hdr_sys_sel_sleep_timer_max)
        e.write("sys_sel_sleep_timer_max = %d*60*60\n" % sleep_timer_max)
    else:
        e.write(_hdr_sys_sel_sleep_timer_max)
        e.write("sys_sel_sleep_timer_max = %d\n" % sleep_timer_max)

    if cfg.version < 4:
        # Extract the system ID from the first gold code.
        goldcode = cfg.bcastGoldCode[0]
        system_id = (goldcode >> 16) & 0xFF

        e.write(_hdr_system_id)
        e.write("system_id = %d\n" % system_id)

        e.write(_hdr_ap_list)
        for i in range(0,_MAX_AP_LIST_SIZE):
            goldcode = cfg.bcastGoldCode[i]
            channel  = cfg.channel[i]
            if goldcode == 0xFF:
                reuse = 0
                if _verbosity > 1:
                    print "AP %d in the list is unused.\n" % i
            else:
                reuse = goldcode & 0xFF
            e.write("ap_%02d_channel = %d\n" % (i, channel))
            e.write("ap_%02d_reuse   = %d\n" % (i, reuse))

    e.write(_hdr_flash_config_version)
    e.write("flash_config_version = %d\n" % cfg.version)

    e.write(_hdr_join_type)
    e.write("join_type = %d\n" % cfg.joinType)

    e.write(_hdr_join_backoff_type)
    e.write("join_backoff_type = %d\n" % cfg.joinBackoffType)

    if cfg.version < 4:
        e.write(_hdr_tcxo_freq)
        e.write("tcxo_freq = %d\n" % cfg.tcxoFreq)

    e.write(_hdr_field_test_num_pdus_per_frame)
    e.write("field_test_num_pdus_per_frame = %d\n" % cfg.fieldTestNumPdusPerFrame)

    e.write(_hdr_field_test_num_frame_period)
    e.write("field_test_num_frame_period = %d\n" % cfg.fieldTestNumFramePeriod)

    e.write(_hdr_field_test_ul_rssi_margin)
    e.write("field_test_ul_rssi_margin = %d\n" % cfg.fieldTestUlRssiMargin)

    e.write(_hdr_dl_bcast_spreading)
    e.write("dl_bcast_spreading = %d\n" % cfg.dlBcastSpreading)

    e.write(_hdr_ota_dwnld_node_type_init_seq)
    e.write("ota_dwnld_node_type_init_seq = %d\n" % cfg.otaDwnldNodeType_InitSeq)

    if cfg.version < 4:
        sys_sel_immediate_join_threshold = cfg.sysSelImmediateJoinThreshold / 16
        e.write(_hdr_sys_sel_immediate_join_threshold)
        e.write("sys_sel_immediate_join_threshold = %d*16\n" % sys_sel_immediate_join_threshold)

    e.write(_hdr_sys_sel_max_freq_optimized_passes)
    e.write("sys_sel_max_freq_optimized_passes = %d\n" % cfg.sysSelMaxFreqOptimizedPasses)

    e.write(_hdr_antenna_diversity_enabled)
    e.write("antennaDiversityEnabled = %d\n" % cfg.antennaDiversityEnabled)

    if cfg.version >= 4:

        e.write(_hdr_high_abs_ap_proper_join_threshold_db)
        e.write("highAbsAPProperJoinThresholdDb = %d\n" % cfg.highAbsAPProperJoinThresholdDb)
        e.write(_hdr_low_abs_ap_proper_join_threshold_db)
        e.write("lowAbsAPProperJoinThresholdDb = %d\n" % cfg.lowAbsAPProperJoinThresholdDb)
        e.write(_hdr_battery_rescan_ui_count)
        e.write("battery_rescan_ui_count = %d\n" % cfg.batteryNodeRescanUIs)

        e.write(_hdr_tx_duty_cycle_percent)
        e.write("txDutyCyclePercent = %d\n" % cfg.txDutyCyclePercent)

        e.write(_hdr_max_delay_during_outage)
        e.write("maxDelayDuringOutage = %d\n" % cfg.maxDelayDuringOutage)

def dump_ap_list_to_file(e, cfg):

    e.write(_hdr_system_id)
    e.write("system_id = %d\n" % (((cfg.apList[0]>>16)&0xff)&0x00ff))

    e.write(_hdr_ap_list)
    for i in range(63):
        e.write("ap_%02d_channel = %d\n" % (i, (cfg.apList[i]>>24)))
        e.write("ap_%02d_reuse   = %d\n" % (i, (cfg.apList[i]&0xff)))
        #if version <= 3:
        #    e.write("ap_%02d_channel = %d\n" % (i, (((cfg.apList[i]>>8)&0xff)/2-48) & 0x00ff))
        #    e.write("ap_%02d_reuse   = %d\n" % (i, (cfg.apList[i]&0xff) & 0x00ff))
        #else:
        #    e.write("ap_%02d_channel = %d\n" % (i, (cfg.apList[i]>>24)))
        #    e.write("ap_%02d_reuse   = %d\n" % (i, (cfg.apList[i]&0xff)))

def main(extract_handle, connection, node_idx = 0):
    # Extract the existing configuration data to a file.
    try:
        cfg = read_node_config_flash(connection, node_idx)
    except:
        if _verbosity > 0:
            print "Error reading existing flash configuration data."
        return 10

    # ret 11 reserved for output open failure

    # Check flash config version.
    if cfg.version != 3 and cfg.version != 4:
        if _verbosity > 0:
            print "Unsupported flash configuration version %d." % cfg.version
        return 12

    dump_config_to_file(extract_handle, cfg)
    
    if cfg.version == 4:
        apList = read_ap_list_flash(connection, node_idx)
        dump_ap_list_to_file(extract_handle, apList)
        pass

    return 0


if __name__ == '__main__':
    retVal = 0

    short_opts = "E:avh"
    long_opts  = ["extract=", "ignore", "verbose", "help"]

    (commArgs, extraOptions, args) = orwCmdLineParams.parseParams(sys.argv[1:], short_opts, long_opts)

    extract_file = None

    for (opt,val) in extraOptions.items():
        if opt in ("-E", "--extract"):
            extract_file = val[-1]
        elif opt in ("-a", "--ignore"):
            _ignore_ack_errors = True
        elif opt in ("-v", "--verbose"):
            _verbosity += len(val)
        elif opt in ("-h", "--help"):
            usage()
            sys.exit(0)
        else:
            usage("Invalid option '%s'" % opt)
            sys.exit(3)

    if not extract_file or extract_file == "-":
        extract_handle = sys.stdout
    else:
        try:
            extract_handle = open(extract_file, 'w')
        except:
            if _verbosity > 0:
                print "Error opening output file '%s'." % extract_file
            sys.exit(11)

    # Open the connection to an eHost or superHost.
    global node_msg
            
    import ucl_nhp
        
    connection = ucl_nhp.Connection(commArgs)
    connection.interrogate_nodes(nodes=commArgs["nodeIndex"])
    node_msg = connection.node(n=commArgs["nodeIndex"][-1]).node_msg

    try:
        retVal = main(extract_handle, connection, commArgs["nodeIndex"][-1])
    except:
        connection.close()
        sys.exit(1)

    if retVal == 0 and _verbosity > 2 and extract_handle is not sys.stdout:
        print "Successfully saved node flash configuration to", extract_file

    if extract_handle is not sys.stdout:
        extract_handle.close();

    connection.close()
    sys.exit(retVal)

