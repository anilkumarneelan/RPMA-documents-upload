#!/usr/bin/env python
#
# Utility routines for Gateway and Node keys.
#
# Copyright (c) 2010. OnRamp Wireless, Inc.
# All rights reserved.
#
# OnRamp Wireless, Inc makes no representations about the suitability of
# this source code for any purpose. This source code is provided "AS IS"
# and without any express or implied warranties, including, without
# limitation, implied warranties of merchantability and fitness for any
# particular purpose.

import string
import ctypes
import sys

ROOT_KEY_SIZE = 16      # Node root key.
CDLD_KEY_SIZE = 16
GW_KEY_SIZE   = 24      # 3DES.
EMCM_ID_SIZE  = 16      # EMCM ID.

###############################################################################
def count_set_bits(int_value):
    """Counts and returns the number of set bits in the specified integer."""
    if not int_value:
        raise ValueError, "Missing integer argument."
    set_bit_count = 0
    while int_value:
        int_value &= int_value - 1;
        set_bit_count += 1
    return set_bit_count


###############################################################################
def hex_lstrip(hex_string):
    """Strips the leading '0x' from a hex string, if present. Returns the
       remaining hex string characters."""
    if not isinstance(hex_string, str):
        raise ValueError, "Input argument is not a string."
    hex_string = string.lower(hex_string)
    x_index = string.find(hex_string, '0x')
    if x_index < 0:
        # No '0x' found. Return string as is.
        return hex_string
    else:
        return hex_string[x_index + len('0x'):]


###############################################################################
def is_hex_string(in_str):
    """Checks if the input string is a human readable hex string (e.g. '0x123').
       Returns True if it is, otherwise False."""
    if not isinstance(in_str, str):
        raise ValueError, "Input argument is not a string."
    # Strip out the leading "0x", if any.
    hs = hex_lstrip(str(in_str))

    # Now check if the remaining characters are human readable hex chars.
    for i in hs:
        if i not in string.hexdigits:
            return False
    return True


###############################################################################
def convert_hex_string_to_byte_string(hex_string, reverse = 0):
    """Converts a human readable hex string (e.g. '0x31ab34') to a byte
       string. If the reverse flag is set, then the first (left most) two
       characters in the hex string will be the last byte in the byte string
       (e.g. '\x34\xab\x31'). Otherwise, the bytes string will be in the same
       order as the hex string (e.g '\x31\xab\x34')."""
    hi = convert_hex_string_to_int_array(hex_string, reverse)

    bs = ''
    for i in hi:
        bs += chr(i)
    return bs


###############################################################################
def convert_hex_string_to_int_array(hex_string, reverse = 0):
    """Converts a hex string (e.g. '0x31ab34') to an integer array. If the
       reverse flag is not set, then the first two characters in the hex
       string corresponding are placed in the lowest array index (e.g.
       [0x31, 0xab, 0x34]). Otherwise, the first two characters in the hex
       string are placed in the highest array index (e.g. [0x34, 0xab, 0x31])."""

    if not is_hex_string(hex_string):
        raise ValueError, "Input argument is not a hex string."
    # Strip out the leading "0x", if any.
    # TODO: if the hex string contains '0x' then it is implied that the
    # first 2 characters are the MSB and should be placed in the highest
    # array index. For now, we will ignore this fact and reverse the
    # string only if explicitly specified by the caller.
    hs = hex_lstrip(str(hex_string))

    ha = [int(hs[i:i + 2], 16) for i,x in enumerate(hs) if i % 2 == 0]

    if reverse:
        ha.reverse()

    return ha


###############################################################################
def convert_hex_string_to_byte_array(hex_string, reverse = 0):
    """Converts a hex string (e.g. '0x31ab34') to a byte array. Reverses the
       order of the byte array if the revers flag is set."""

    # Note: if the reverse flag is not set, then a human readable hex string
    # will have the 'wrong' endiannes.

    hi = convert_hex_string_to_int_array(hex_string, reverse)
    h_length = len(hi)
    hb = (ctypes.c_ubyte * h_length)()

    for i,val in enumerate(hi):
        hb[i] = val
    return hb


###############################################################################
def convert_byte_string_to_byte_array(byte_string, reverse = 0):
    """Converts a byte string (e.g. '\x31\xab\x34') to a byte array
       (e.g. [0x31, 0xab, 0x34]). If the reverse flag is set, then the
       order of the array elements are reversed, that is, the first byte
       in the bytes string is the last byte in the array (e.g. [0x34, 0xab, 0x31)."""

    if not isinstance(byte_string, str):
        raise ValueError, "Input argument is not a string."
    b_length = len(str(byte_string))
    ba = (ctypes.c_ubyte * b_length)()

    b_list = list(byte_string)
    if reverse:
        b_list.reverse()

    for i,val in enumerate(b_list):
        ba[i] = ord(val)

    return ba


###############################################################################
def convert_byte_string_to_int_array(byte_str, reverse = 0):
    """Converts a byte string (e.g. '\x31\xab\x34') to an integer array.
       Reverses the order of the array if the revers flag is set."""

    int_array = []
    for i in byte_str:
        int_array.append(ord(i))

    if reverse:
        int_array.reverse()

    return int_array


###############################################################################
def convert_byte_string_to_int(byte_string, reverse = 0):
    """Converts a byte string (e.g. '\x31\xab\x34') to an integer. If the
       reverse flag is set, reverses the order of the byte string before
       converting to an integer."""

    # Note: if the reverse flag is not set, then the first (left-most) byte
    # in the byte string will be the LSB of the resulting integer. Setting
    # the reverse flag will cause the first (left-most) byte in the byte
    # string to be the MSB of the integer.

    if not isinstance(byte_string, str):
        raise ValueError, "Input argument is not a string."

    byte_list = list(byte_string)
    if reverse:
        byte_list.reverse()

    int_val = 0
    for i, val in enumerate(byte_list):
        int_val |= ord(val) << (i * 8)

    return int_val


###############################################################################
def convert_byte_string_to_hex_string(byte_str, reverse = 0, hex_notation = 0):
    """Converts a byte string (e.g. '\x31\xab\x34') to a human readable hex
       string (e.g. '31ab34'). If the reverse flag is set, then the first
       byte of the byte string will be placed at the end of the hex string
       and the last byte of the bytes string will be placed at the beginning
       of the hex string. If the hex notation flag is set, the hex string is
       prepended with '0x'."""

    if not isinstance(byte_str, str):
        raise ValueError, "Input argument is not a string."

    if reverse:
        # Reverse the byte string order.
        byte_str = reverse_byte_string(byte_str)

    hex_str = ''
    for i,val in enumerate(byte_str):
        hex_str += '%02x' % ord(val)

    if hex_notation:
        hex_str = '0x' + hex_str

    return hex_str


###############################################################################
def reverse_byte_string(byte_str):
    """Reverse the order of a byte string."""
    byte_list = list(byte_str)
    byte_list.reverse()
    byte_str = ''.join(byte_list)

    return byte_str


###############################################################################
def xor_byte_strings(byte_str1, byte_str2):
    """Performs exclusive OR on two byte strings. Strings first need to be
       converted to integer byte values. Returns a byte string of the 
       resulting XOR. If one string is shorter than the other, only the
       first number of bytes corresponding to the shorter string's length
       will be XOR'd."""
    xor_str = ''
    if len(byte_str1) > len(byte_str2):
        xor_length = len(byte_str2)
        for i in range(0, xor_length):
            xor_str += chr(ord(byte_str1[i]) ^ ord(byte_str2[i]))
        xor_str += byte_str1[xor_length:]
        return xor_str
    else:
        xor_length = len(byte_str1)
        for i in range(0, xor_length):
            xor_str += chr(ord(byte_str1[i]) ^ ord(byte_str2[i]))
        xor_str += byte_str2[xor_length:]
        return xor_str


###############################################################################
def check_key_hex_string_parity(key_hex_string, parity = 'odd'):
    """Checks and verifies the parity of the specified key in human readable
       hex string format. The last bit of each byte in the key is assumed to
       be the parity bit. The parity type can be specified as 'odd' (1) or
       'even' (0). Returns True if the parity matches the type specified,
       otherwise returns False."""

    # Note: this routine expects the key string to be a human readable hex
    # string, not a byte string.

    if not isinstance(key_hex_string, str):
        raise ValueError, "Input argument is not a string."

    # Convert to a byte string (reverse the order).
    key_string = convert_hex_string_to_byte_string(key_hex_string, 1)

    ret_val = check_key_parity(key_string, parity)
    return ret_val


###############################################################################
def check_key_parity(key_string, parity = 'odd'):
    """Checks and verifies the parity of the specified key in byte string
       format. The last bit of each byte in the key is assumed to be the
       parity bit. The parity type can be specified as 'odd' (1) or 'even'
       (0). Returns True if the parity matches the type specified, otherwise
       returns False."""

    # Note: this routine expects the key to be a byte string, not a human
    # readable hex string.

    if not isinstance(key_string, str):
        raise ValueError, "Input argument is not a string."

    key_array = convert_byte_string_to_int_array(key_string)
    if parity in ('odd', '1'):
        for x in key_array:
            bit_count = count_set_bits(x)
            if bit_count & 1 == 0:
                # Parity is even, but should be odd.
                return False
        return True
    elif parity in ('even', '0'):
        for x in key_array:
            bit_count = count_set_bits(x)
            if bit_count & 1 == 1:
                # Parity is odd, but should be even.
                return False
        return True
    else:
        raise RuntimeError, "Invalid parity type '%s'." % parity


###############################################################################
def left_shift_byte_array(byte_array, left_shifts):
    """Left shifts the bytes in the array by the indicated number of bits.
       Any bits in a byte that are pushed past the 8th bit is added to its
       neighbor to the left. This routine makes no assumption of the endianness
       of the array (if it represents are larger number)."""
    if not left_shifts:
        return byte_array
    if left_shifts < 0:
        raise ValueError, "Negative left shifts not allowed."

    byte_shifts = left_shifts >> 3
    bit_shifts  = left_shifts & 0x07

    total_bytes = len(byte_array)
    if byte_shifts >= total_bytes:
        # Everything got shifted off the cliff.
        return [0] * total_bytes

    last_byte_index = total_bytes - byte_shifts - 1
    for i in range(0, last_byte_index):
        b0 = (byte_array[i + byte_shifts] << bit_shifts) & 0xFF
        b1 = (byte_array[i + byte_shifts + 1] >> (8 - bit_shifts))
        byte_array[i] = b0 | b1

    # Handle the last byte.
    i = last_byte_index
    b0 = (byte_array[i + byte_shifts] << bit_shifts) & 0xFF
    byte_array[i] = b0

    for i in range(last_byte_index + 1, total_bytes):
        byte_array[i] = 0

    return byte_array


###############################################################################
def convert_byte_array_to_hex_string(byte_array, reverse = 0, hex_notation = 0):
    """Converts a byte array (e.g. [ 0x34, 0xab, 0x31 ]) to a human readable
       hex string (e.g. '34ab31'). If the reverse flag is set, then the first
       byte of the byte array will be placed at the end of the hex string
       and the last byte of the bytes array will be placed at the beginning
       of the hex string. If the hex notation flag is set, the hex string is
       prepended with '0x'."""

    if reverse:
        # Reverse the byte string order.
        byte_array = reverse_byte_string(byte_array)

    hex_str = ''
    for i,val in enumerate(byte_array):
        hex_str += '%02x' % ord(val)

    if hex_notation:
        hex_str = '0x' + hex_str

    return hex_str

###############################################################################
def convert_int_byte_array_to_hex_string(byte_array, reverse = 0, hex_notation = 0):
    """Converts a byte array (e.g. [ 0x34, 0xab, 0x31 ]) to a human readable
       hex string (e.g. '34ab31'). If the reverse flag is set, then the first
       byte of the byte array will be placed at the end of the hex string
       and the last byte of the bytes array will be placed at the beginning
       of the hex string. If the hex notation flag is set, the hex string is
       prepended with '0x'."""

    if reverse:
        # Reverse the byte string order.
        byte_array = reverse_byte_string(byte_array)

    hex_str = ''
    for i,val in enumerate(byte_array):
        hex_str += '%02x' % val

    if hex_notation:
        hex_str = '0x' + hex_str

    return hex_str

###############################################################################
def strip_duplicates_from_sorted_list(sorted_list, verbosity = 0):
    """Strips duplicate items from a sorted list. The list must be sorted
       for this to work."""
    stripped_list = []
    last_item = None
    for item in sorted_list:
        if item == last_item:
            # Duplicate entry.
            if verbosity > 1:
                print "Duplicate item:", item
            continue
        stripped_list.append(item)
        last_item = item

    return stripped_list


###############################################################################
def parse_integer_arguments(int_args, dummy = 0, max_range=50000):
    """Parse the user's argument string containing comma separated integers
       and integer ranges (separated by a dash) and generates a list of the
       integers sorted in ascending order. Duplicate numbers are removed."""
    int_list = []
    while int_args:
        try:
            (int_arg, int_args) = string.split(int_args, ',', 1)
            if string.count(int_arg, '-') > 0:
                # Possibly a range argument.
                if string.count(int_arg, '-') > 1:
                    # Invalid range syntax.
                    raise ValueError, "Invalid integer range syntax. Multiple dashes."
                (r0, r1) = string.split(int_arg, '-')
                range0 = int(r0, 0)
                range1 = int(r1, 0)
                if range0 > range1:
                    raise ValueError, "Invalid integer range argument '%s-%s'." % (r0, r1)
                if (range1 - range0) > max_range:
                    raise ValueError, "Exceeded the maxium integer range %s." % (max_range,)
                    
                for r in range(range0, range1 + 1):
                    int_list.append(r)
            else:
                # Single integer number argument.
                i = int(int_arg, 0)
                int_list.append(i)
        except:
            # Some other error.
            raise

    # Sort the list.
    int_list = sorted(int_list)

    # Check for and strip duplicates.
    stripped_list = strip_duplicates_from_sorted_list(int_list)

    return stripped_list


###############################################################################
if __name__ == '__main__':
    print 'The key utilities module is not a stand alone program.'
    sys.exit(-1)
