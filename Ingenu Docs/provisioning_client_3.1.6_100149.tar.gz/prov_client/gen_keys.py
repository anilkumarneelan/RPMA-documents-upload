#!/usr/bin/env python
#
# Copyright (c) 2011. OnRamp Wireless, Inc.
# All rights reserved.
#
# OnRamp Wireless, Inc makes no representations about the suitability of
# this source code for any purpose. This source code is provided "AS IS"
# and without any express or implied warranties, including, without
# limitation, implied warranties of merchantability and fitness for any
# particular purpose.


"""Script to generate the gateway, code download, and node root keys necessary
   for provisioning an Onramp ULP network."""


import getopt
import os
import struct
import sys

from Crypto.Cipher import AES

from key_utils import *
from crypto_utils import *


# Allowable node ID range (exclusive) for key generation purposes.
_DEV_ID_MIN = 0x00000000
_DEV_ID_MAX = 0xFFFFFFFF


###############################################################################
def derive_key(aes_root, context, iteration, rng = None):
    """Derives K(i) using a new KDF based on AES-CMAC. AES-CMAC is equivalent
       to AES-ECB for a single 128 bit block."""

    L = 1 << 23;

    data = [0] * 16
    if context == None:
        if rng == None:
            context = get_urandom(8)
        else:
            context = rng.get_random(8)
    context = map(ord, context)

    # result = AES({ iteration, context, L, 0x0 })
    data[15] = (iteration & 0xff000000) >> 24
    data[14] = (iteration & 0x00ff0000) >> 16
    data[13] = (iteration & 0x0000ff00) >> 8
    data[12] = (iteration & 0x000000ff) >> 0

    data[11] = context[7]
    data[10] = context[6]
    data[9]  = context[5]
    data[8]  = context[4]
    data[7]  = context[3]
    data[6]  = context[2]
    data[5]  = context[1]
    data[4]  = context[0]

    data[3]  = (L & 0x00ff0000) >> 16
    data[2]  = (L & 0x0000ff00) >> 8
    data[1]  = (L & 0x000000ff) >> 0
    data[0]  = 0

    data_s = struct.pack('16B', *data)

    aes = AES.new(aes_root, AES.MODE_ECB)
    ciph = aes.encrypt(data_s)

    return ciph

###############################################################################
def gen_gw_keys(base, rng = None, dev_keys = False):
    """Generates gateway and gateway code download keys."""

    if dev_keys:
        gw_cdld = '\0'*16
        gw = '\0'*24
    else:
        if rng == None:
            context = get_urandom(8)
        else:
            context = rng.get_random(8)
        gw_cdld = derive_key(base, context, iteration = _DEV_ID_MIN)

        if rng == None:
            context = get_urandom(8)
        else:
            context = rng.get_random(8)
        gw1 = derive_key(base, context, iteration = _DEV_ID_MAX)

        if rng == None:
            context = get_urandom(8)
        else:
            context = rng.get_random(8)
        gw2 = derive_key(base, context, iteration = _DEV_ID_MAX)

        gw = gw1 + gw2
        gw = gw[:24]

    tmp = ''

    # Add in odd parity bits as needed.
    for byte in gw:

        byte = ord(byte) & 0x7f
        bitsum = 0
        for i in range(7):
            bitsum += (byte >> i) & 0x1

        # GW key should have odd parity.
        if bitsum & 1:
            # Parity is already odd.
            tmp += chr(byte)
        else:
            # Parity is even. Set MSB to make it odd.
            tmp += chr(0x80 | byte)

    gw = tmp

    return (gw, gw_cdld)


###############################################################################
def gen_device_key(base, context, dev_id, rng = None):
    """Generates a key for a device (node, emcm, etc)."""

    # Make sure our 32 bit ID doesn't rollover thereby exposing the gateway key.
    if (dev_id < _DEV_ID_MIN):
        raise ValueError, "Invalid ID."
    if (dev_id > _DEV_ID_MAX):
        raise ValueError, "ID rollover."

    if not base:
        # generate 128 bit random base aes key
        if rng == None:
            base = get_urandom(16)
        else:
            base = rng.get_random(16)

    key = derive_key(base, context, iteration = dev_id, rng = rng)

    return key

###############################################################################
def usage_gen_keys(s = ''):
    """Prints usage information."""

    if s:
        print '\n*** error:  ' + str(s) + ' ***\n'

    print """\
Usage:  %s [OPTS]

Generates gateway, gateway code download, and device specific keys. The
keys are written to OUTPUT_FILE, if specified, otherwise, to stdout. This
is primarily for testing the key generating functions. This file should
not be used as a stand-alone utility for generating keys for field deployed
devices.

Options:

    -n <X,Y>, --device-ids=<X,Y>
        Specifies the range of ID's to generate keys for.
        If no ID range is specified, then only generates the GW keys.
    -o <OUTPUT_FILE>, --output=<OUTPUT_FILE>
        Name of the key output file. If no output file is specified, then
        keys are displayed to stdout.
    -b <key_base>, --base=<key_base>
        The 16 byte hexadecimal base used for key generation. If not specified,
        a random value will be used.
    -v, --verbose
        Increase verbosity level.
    -h, --help
        Prints this help message.

Example:  %s --device-ids=0x12000,0x18000 new_keys_file
""" % (sys.argv[0], sys.argv[0])


###############################################################################
if __name__ == '__main__':
    short_opts = "n:o:b:vh"
    long_opts = ["device-ids=", "out=", "output=", "base=", "verbose", "help"]

    try:
        opts, args = getopt.getopt(sys.argv[1:], short_opts, long_opts)
    except getopt.GetoptError, err:
        usage_gen_keys(err)
        sys.exit(1)

    dev_id_range   = None
    outfname        = None
    key_base        = None
    verbosity       = 0

    for opt, val in opts:
        if opt in ("-h", "--help"):
            usage_gen_keys()
            sys.exit(0)
        elif opt in ("-n", "--device-ids"):
            if val.count(',') == 1:
                dev_id_range = [int(x, 0) for x in val.split(',')]
            elif val.count(',') == 0:
                if val.count('-') == 1:
                    dev_id_range = [int(x, 0) for x in val.split('-')]
                elif val.count('-') == 0:
                    dev_id_range = int(val, 0)
                else:
                    usage_gen_keys("Invalid ID range argument '%s'." % val)
                    sys.exit(2)
            else:
                usage_gen_keys("Invalid ID range argument '%s'." % val)
                sys.exit(3)
        elif opt in ("-o", "--out", "--output"):
            outfname = val
        elif opt in ("-b", "--base"):
            key_base = val
        elif opt in ("-v", "--verbose"):
            verbosity += 1
        else:
            usage_gen_keys("unhandled option %s" % opt)

    if key_base != None:
        # Verify that the key base argument is a number.
        try:
            tmp = int(key_base, 0)
        except:
            usage_gen_keys("Invalid key base argument '%s'." % key_base)
            sys.exit(4)
        # Convert the hex string to a byte string. Reverse the order
        # since the hex string is in human hex format.
        key_base = convert_hex_string_to_byte_string(key_base, reverse = 1)

    if len(args) > 0:
        # Output filename specified without the -o option.
        if outfname == None:
            outfname = args[0]
        else:
            print "Ignoring filename argument '%s'." % args[0]
            print "Output filename '%s' already specified with '-o' option." % \
                  outfname

    if dev_id_range:
        if verbosity > 0:
            if len(dev_id_range) == 2:
                print "Will generate keys for 0x%08x - 0x%08x" % \
                    (dev_id_range[0], dev_id_range[1])
            else:
                print "Will generate key for 0x%08x" % dev_id_range

    if outfname:
        outf = open(outfname, 'w')
    else:
        outf = sys.stdout

    aes_key = get_urandom(AES_KEY_SIZE_128)
    rng = EntropySource(aes_key)

    if key_base == None:
        if verbosity > 0:
            print "Getting random seeds..."
        key_base = rng.get_random(16)

    if verbosity > 0:
        print "Writing gateway keys..."
    gw, gw_cdld = map(convert_byte_string_to_int, gen_gw_keys(key_base, rng))
    prov_srvr_key = convert_byte_string_to_int(key_base)

    # Output the keys to a CSV file.
    outf.write("base,0x%032x\n" % prov_srvr_key)
    outf.write("gateway,0x%048x\n" % gw)
    outf.write("gateway_cdld,0x%032x\n" % gw_cdld)

    if verbosity > 2:
        print "prov_srvr_key  = 0x%032x" % prov_srvr_key
        print "gw_key   = 0x%048x" % gw
        print "cdld_key = 0x%032x" % gw_cdld

    if dev_id_range:
        if verbosity > 0:
            print "Writing device keys..."
        try:
            first, last = dev_id_range
        except:
            first = dev_id_range
            last  = dev_id_range
        for did in range(first, last + 1):
            context = rng.get_random(8)
            dev_key = convert_byte_string_to_int(gen_device_key(key_base, context, did))
            outf.write("0x%08x,0x%032x\n" % (did, dev_key))

    outf.close()
    rng.kill()

    sys.exit(0)
