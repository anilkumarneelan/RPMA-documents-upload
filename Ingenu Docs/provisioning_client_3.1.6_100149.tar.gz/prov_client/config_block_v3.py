#!/usr/bin/env python
#
# Copyright (c) 2010. OnRamp Wireless, Inc.
# All rights reserved.
#
# OnRamp Wireless, Inc makes no representations about the suitability of
# this source code for any purpose. This source code is provided "AS IS"
# and without any express or implied warranties, including, without
# limitation, implied warranties of merchantability and fitness for any
# particular purpose.

"""Module for converting a node configuration block text file into a message."""

import ctypes
import provisioning_error as p_err

FLASH_CONF_VERSION = 3 # not 2, not 4...Three shall be the number thou shalt count, and the number of the counting shall be three. Four shalt thou not count, neither count thou two, excepting that thou then proceed to three. Five is right out. Once the number three, being the third number, be reached, then lobbest thou thy Holy Hand Grenade of Antioch towards thy foe, who being naughty in My sight, shall snuff it. Amen.
_MAX_NUM_CHANNELS = 24


class ValueMissingException(Exception):
    """A value should be defined in the file but isn't."""
    pass


class ValueOutOfRangeException(Exception):
    """A value is out of range."""
    pass


def parse_file(fname):
    """Returns a dict of variables parsed from a python-syntaxed config file."""

    t = open(fname, 'U').read()

    _locals = {}
    _globals = {}
    exec(t, _locals, _globals)

    return _globals


def validate(cfg):
    """Range checking, etc."""

    checked = {}

    def validate_range(key, lower, upper):
        if not cfg.has_key(key):
            raise ValueMissingException("'%s' entry is missing" % key)

        val = cfg[key]
        if not lower <= val <= upper:
            raise ValueOutOfRangeException("%s = %d, must be in range [%d, %d]" % (key, val, lower, upper))

        checked[key] = val

    def validate_set(key, valid=[], invalid=[]):
        if not cfg.has_key(key):
            raise ValueMissingException("'%s' entry is missing" % key)

        val = cfg[key]

        if valid and val not in valid:
            raise ValueOutOfRangeException("%s = %d, must be in set %s" % (key, val, valid))

        if invalid and val in invalid:
            raise ValueOutOfRangeException("%s = %d, must not be in set %s" % (key, val, invalid))

        checked[key] = val


    def validate_relative(key1, key2, op):
        """Why?  They never validate me..."""

        if not cfg.has_key(key1):
            raise ValueMissingException("'%s' entry is missing" % key)

        val1 = cfg[key1]

        if not cfg.has_key(key2):
            raise ValueMissingException("'%s' entry is missing" % key)

        val2 = cfg[key2]

        if not op(val1, val2):
            raise ValueOutOfRangeException("%s (%d) %s %s (%d) failed" % (key1, val1, op.func_name, key2, val2))

        checked[key1] = val1
        checked[key2] = val2


    def validate_bad_combo(key1, key2, c1, c2):
        if not cfg.has_key(key1):
            raise ValueMissingException("'%s' entry is missing" % key)

        val1 = cfg[key1]

        if not cfg.has_key(key2):
            raise ValueMissingException("'%s' entry is missing" % key)

        val2 = cfg[key2]

        if val1 == c1 and val2 == c2:
            raise ValueOutOfRangeException("invalid combination of %s (%d) and %s (%d)" % (key1, val1, key2, val2))

    validate_set('flash_config_version', [FLASH_CONF_VERSION])
    validate_range('system_id', 0, 255)
    validate_range('country_code', 1, 1000)
    validate_range('max_tx_power', 0, 25)

    validate_set('sys_sel_sleep_timer_min', [], [0])
    validate_set('sys_sel_sleep_timer_max', [], [0])

    def less_than(a, b):
        return a < b

    validate_relative('sys_sel_sleep_timer_min', 'sys_sel_sleep_timer_max', less_than)

    validate_set('operating_mode', [0, 4])
    validate_set('autorun', [0, 1])
    validate_bad_combo('operating_mode', 'autorun', 4, 0)

    chan_sum = 0

    for i in range(_MAX_NUM_CHANNELS):
        key = 'ap_%02d_channel' % i
        rng = list(range(1, 51)) + [255]
        validate_set(key, rng)
        chan_sum += cfg[key]

    if not chan_sum:
        print "warning:  at least one channel must be assigned."

    for i in range(_MAX_NUM_CHANNELS):
        key = 'ap_%02d_reuse' % i
        validate_range(key, 0, 255)

    # optional system id specification in ap list
    for i in range(_MAX_NUM_CHANNELS):
        key = 'ap_%02d_system_id' % i
        if key in cfg.keys():
            validate_range(key, 0, 255)
            
    # New configuration parameters.
    validate_set('join_type', [0, 1])
    validate_set('join_backoff_type', [0, 1])
    validate_set('tcxo_freq', [0])
    validate_set('dl_bcast_spreading', [11])
    validate_range('ota_dwnld_node_type_init_seq', 0, 0xff)
    validate_set('sys_sel_immediate_join_threshold', [0, -112 * 16])
    validate_set('sys_sel_max_freq_optimized_passes', [15])
    # We'll allow any value for field test parameters.
    validate_range('field_test_num_pdus_per_frame', 0, 0xffff)
    validate_range('field_test_num_frame_period', 0, 0xffff)
    validate_range('field_test_ul_rssi_margin', 0, 0xff)

    validate_set('antennaDiversityEnabled', [0, 1])

    keys = cfg.keys()
    keys.sort()

    # warn about unknown values
    for key in keys:
        if not checked.has_key(key):
            print "warning:  unknown value '%s' in configuration will be ignored." % key

    return checked


def get_cfg_data_struct(cfg, node_msg):
    """Returns a flash configuration object with desired configuration and defaults."""

    s = node_msg.FlashConfiguration()

    # make some ctypes arrays
    bcgc_arr = (ctypes.c_uint*_MAX_NUM_CHANNELS)()
    chan_arr = (ctypes.c_ubyte*_MAX_NUM_CHANNELS)()

    # fill in channels
    for i in range(_MAX_NUM_CHANNELS):
        chan = 'ap_%02d_channel' % i
        reuse = 'ap_%02d_reuse' % i
        sysid = 'ap_%02d_system_id' % i
        
        system_id = cfg['system_id']
        if sysid in cfg.keys():
            if i == 0:
                raise p_err.ULPProvisioningError(p_err.ErrorCodes.CONF_FILE_INVALID, "Cannot specify system ID for the first item of the AP list")
            system_id = cfg[sysid]

        chan_arr[i] = cfg[chan]

        goldcode = 0x1000000
        goldcode = goldcode + ( system_id % 0x100)*0x10000
        freq = 2402 + (cfg[chan] - 1)*2
        goldcode = goldcode + (freq % 0x100)*0x100
        goldcode = goldcode + (cfg[reuse] % 0x100)

        bcgc_arr[i] = goldcode if cfg[chan] else 0

    s.v3.version = FLASH_CONF_VERSION
    s.v3.bcastGoldCode = bcgc_arr
    s.v3.channel = chan_arr
    s.v3.tcxoFreq = cfg['tcxo_freq']
    s.v3.countryCode = cfg['country_code']
    s.v3.sysSelMinSleepTimer = cfg['sys_sel_sleep_timer_min']
    s.v3.fieldTestNumPdusPerFrame = cfg['field_test_num_pdus_per_frame']
    s.v3.fieldTestNumFramePeriod = cfg['field_test_num_frame_period']
    s.v3.fieldTestUlRssiMargin = cfg['field_test_ul_rssi_margin']
    s.v3.autorun = cfg['autorun']
    s.v3.operatingMode = cfg['operating_mode']
    s.v3.dlBcastSpreading = cfg['dl_bcast_spreading']
    s.v3.maxTxPwrLimit = cfg['max_tx_power']
    s.v3.joinType = cfg['join_type']
    s.v3.joinBackoffType = cfg['join_backoff_type']
    s.v3.otaDwnldNodeType_InitSeq = cfg['ota_dwnld_node_type_init_seq']
    s.v3.sysSelMaxSleepTimer = cfg['sys_sel_sleep_timer_max']

    # This should stay 0 to disable immediate joins in a
    # single freq. network. Can be set to -112*16 for
    # multi freq. networks in future.
    s.v3.sysSelImmediateJoinThreshold = cfg['sys_sel_immediate_join_threshold']
    s.v3.sysSelMaxFreqOptimizedPasses = cfg['sys_sel_max_freq_optimized_passes']

    s.v3.antennaDiversityEnabled = cfg['antennaDiversityEnabled']
    
    return s


def get_ap_list_struct(cfg, node_msg):
    """Returns a None object. This method is needed for compatibility with the v4 flash
       configuration which has a separate AP list from the config data."""
    return None


if __name__ == '__main__':
    import sys

    cfg = validate(parse_file(sys.argv[1]))
    import node_msg_1_4
    print get_cfg_data_struct(cfg, node_msg_1_4).pretty()

