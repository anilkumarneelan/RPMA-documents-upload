"""provisioning client <-> server comm support."""

import urllib2
import StringIO
import sys
import struct
import hashlib
import ssl
import time

import prov_client_server_inf as xml_msg

import key_utils
import crypto_utils
import provisioning_error as p_err

###############################################################################
def EncryptKeyInfo(root_key, timestamp, config_id, device_id, kms_pub_key):

    # Argument checking ...
    
    # root_key & kms_pub_key should be binary strings
    if not isinstance(root_key, str):
        raise p_err.ULPProvisioningError( \
            p_err.ErrorCodes.INVALID_ARGUMENTS,
            target=p_err.CommType.LOCAL_ERROR,
            extraInfo='root_key not passed as binary string')

    if not isinstance(kms_pub_key, str):
        raise p_err.ULPProvisioningError( \
            p_err.ErrorCodes.INVALID_ARGUMENTS,
            target=p_err.CommType.LOCAL_ERROR,
            extraInfo='kms_pub_key not passed as binary string')

    # timestamp & network id should be integer
    try:
        timestamp = int(timestamp)
    except:
        raise p_err.ULPProvisioningError( \
            p_err.ErrorCodes.INVALID_ARGUMENTS,
            target=p_err.CommType.LOCAL_ERROR,
            extraInfo='timestamp not an int')
    try:
        config_id = int(config_id)
    except:
        raise p_err.ULPProvisioningError( \
            p_err.ErrorCodes.INVALID_ARGUMENTS,
            target=p_err.CommType.LOCAL_ERROR,
            extraInfo='network id not an int')
        
    # device id can be either ...
    if isinstance(device_id, str):
        if len(device_id) > 16:
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.INVALID_ARGUMENTS,
                target=p_err.CommType.LOCAL_ERROR,
                extraInfo='device_id too long (128 bit max)')
        if len(device_id) < 16:
            # front pad with 0
            pad = '\0'*(16 - len(device_id))
            device_id = pad + device_id
    elif isinstance(device_id, int) or isinstance(device_id, long):
        device_id = '\0'*8 + struct.pack('> Q', device_id)
    else:
        raise p_err.ULPProvisioningError( \
            p_err.ErrorCodes.INVALID_ARGUMENTS,
            target=p_err.CommType.LOCAL_ERROR,
            extraInfo='device id not passed as int or binary string')
    
    # encryption input is binary string of:
    # 16-bit key length (bytes)
    # key of length specified
    # 32-bit unix timestamp_provisioned
    # 64-bit config ID
    # 128-bit device id
    # remaining zeroes to pad to an integer multiple of 256 bytes
    key_string = \
        struct.pack('> H', len(root_key)) + \
        root_key + \
        struct.pack('> LQ', timestamp, config_id) + \
        device_id

    if len(key_string)%256 != 0:
        pad = '\0' * (256 - len(key_string)%256)
        key_string = key_string + pad

    rsa_pub_key = crypto_utils.rsa_import_key(kms_pub_key)
    encrypted = crypto_utils.rsa_encrypt(rsa_pub_key, key_string)
    return encrypted
    
class TargetFileInfo():
    def __init__(self, factory_config_path, factory_config_md5_hash,
                 field_config_path, field_config_md5_hash,
                 firmware_path, firmware_md5_hash, useHTTP, logger,
                 server, port, url_opener,
                 path_trans_from = '', path_trans_to = '', localCachePrefix='node'):

        self.logger = logger
        self.factory_config_md5_hash  = factory_config_md5_hash 
        self.field_config_md5_hash    = field_config_md5_hash   
        self.firmware_md5_hash        = firmware_md5_hash       
        self.server = server
        self.port = port
        self.url_opener = url_opener

        if useHTTP:
            if factory_config_path:
                self.factory_config_url = \
                    factory_config_path.replace(path_trans_from, path_trans_to, 1)
                self.factory_config_path = localCachePrefix + '_factory_config.cache'
                self.cacheHTTP(
                    self.factory_config_url,
                    self.factory_config_path,
                    self.factory_config_md5_hash)

            if field_config_path:
                self.field_config_url = \
                    field_config_path.replace(path_trans_from, path_trans_to, 1)
                self.field_config_path = localCachePrefix + '_field_config.cache'
                self.cacheHTTP(
                    self.field_config_url,
                    self.field_config_path,
                    self.field_config_md5_hash)
                
            if firmware_path:
                self.firmware_url = \
                    firmware_path.replace(path_trans_from, path_trans_to, 1)
                self.firmware_path = localCachePrefix + '_firmware.cache'
                self.cacheHTTP(
                    self.firmware_url,
                    self.firmware_path,
                    self.firmware_md5_hash)
        else:
            if factory_config_path:
                self.factory_config_path      = \
                    factory_config_path.replace(path_trans_from, path_trans_to, 1)
            if field_config_path:
                self.field_config_path        = \
                    field_config_path.replace(path_trans_from, path_trans_to, 1)
            if firmware_path:
                self.firmware_path            = \
                    firmware_path.replace(path_trans_from, path_trans_to, 1)

        # Allow for app sections without all files required
        if factory_config_path:
            self.checkHash(self.factory_config_path, self.factory_config_md5_hash)
        else:
            self.factory_config_path = None
            
        if field_config_path:
            self.checkHash(self.field_config_path, self.field_config_md5_hash)
        else:
            self.field_config_path = None

        if firmware_path:
            self.checkHash(self.firmware_path, self.firmware_md5_hash)
        else:
            self.firmware_path = None
        
    def checkHash(self, path, exp_hash):
        md5 = hashlib.md5()

        try:
            f = open(path, 'rb')
            md5.update(f.read())
            f.close()
            md5sum = md5.hexdigest()
            if md5sum.upper() != exp_hash.upper():
                raise p_err.ULPProvisioningError( \
                    p_err.ErrorCodes.VERIFICATION_FAILED, target=p_err.CommType.PROV_SERVER,
                    extraInfo = 'MD5 hash mismatch (%s: 0x%s v.s. 0x%s)' % \
                        (path, md5sum, exp_hash))
        except IOError:
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.CONF_FILE_INVALID, target=p_err.CommType.PROV_SERVER,
                extraInfo = "Can't open file %s" % path)            

    def cacheHTTP(self, url_ext, localName, exp_hash):
        # check if local file exists and has correct hash ... if so, nothing to do
        try:
            with open(localName, 'rb') as f:
                md5 = hashlib.md5()
                md5.update(f.read())
                md5sum = md5.hexdigest()
                if md5sum.upper() == exp_hash.upper():
                    self.logger.info("Local cached file hash matches")
                    return
        except IOError:
            pass

        # not up to date or doesn't exist, so grab from server
        url_path = '%s:%d/provisioning/main/download?file_path=%s' % (self.server, self.port, url_ext)
        self.logger.info("Local cached file mismatches - fetching %s" % url_path)
        try:
            with open(localName, 'wb') as f:
                req = self.url_opener(url_path, timeout = 60*3)
                while True:
                    chunk = req.read(16 * 1024)
                    if not chunk: break
                    f.write(chunk)
                req.close()
        except IOError as e:
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.UNKNOWN_PROVISIONING_ERROR, target=p_err.CommType.LOCAL_ERROR,
                extraInfo = "IO error fetching cachename %s: %s" % (localName, str(e)))
        except urllib2.URLError as e:
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.COMM_FAILURE, target=p_err.CommType.PROV_SERVER, extraInfo=str(e))

        # note we don't need to re-check hash as that will be sanity checked later ...
        
class ConfigData():
    def __init__(self):
        self.node_version = '0.0.0'
        self.kms_pub_key = '\x00' * 256
        self.gw_wide_key = '\x00' * 24
        self.gw_cdld_key = '\x00' * 16
        self.node_files = None

        self.app_names = []
        self.app_versions = []
        self.app_pub_keys = []
        self.app_files = []
        
class ProvisioningServerInterface():
    """The provisioning server interface for the provisioning client. The client
       communicates with the server by creating an instance of this
       class."""

    def __init__(self, logger, server = 'localhost', port = 8085, 
                 debug=False, timeout=60.0, useSSL=True,
                 server_keyfile='key.pem', client_keyfile='key.pem',
                 client_key_password='onramp'):
        self.server = server
        self.port = port
        self.url_path = '%s:%d/provisioning/main/nptrequest' % (server, port)
        self.debug = debug
        self.logger = logger
        self.timeout = timeout
        self.server_keyfile = server_keyfile
        self.client_keyfile = client_keyfile
        self.client_key_password = client_key_password
        
        if useSSL:
            # SSL ... check for minimum python version
            new_ssl_version = (2, 7, 9)
            if sys.version_info < new_ssl_version:
                raise p_err.ULPProvisioningError( \
                    p_err.ErrorCodes.UNSUPPORTED_SW_VERSION,
                    target=p_err.CommType.LOCAL_ERROR,
                    extraInfo='SSL certificate validation requires python >= 2.7.9')
            self.url_prefix = 'https://'
        else:
            self.url_prefix = 'http://'
        
    def _url_opener(self, url_path, timeout = None, request = None):
        if not timeout:
            timeout = self.timeout
            
        if request:
            open_arg = request
        else:
            open_arg = self.url_prefix + url_path
            
        if self.url_prefix == 'https://':
            # certificate checks are enabled ...
            self.logger.info("SSL enabled.")
            ctx = ssl.create_default_context(cafile=self.server_keyfile)
            ctx.check_hostname = False
            ctx.load_cert_chain(self.client_keyfile, password=self.client_key_password)
            return urllib2.urlopen(open_arg, timeout = timeout, context = ctx)
        else:
            # just open with http
            self.logger.info("SSL disabled, attempting http with open_arg")
            return urllib2.urlopen(open_arg, timeout = timeout)
            
    def _post(self, data):
        # It was found that there can be a  TCP connection failure between Windows client and Windows server.
        # The trial after 10 seconds seems to solve the problem, that is, always connects in the re-trial after 10 seconds
        tmoSeconds = 0;
        tmoDelta = 10;
        try:
            while (True):
                try:
                    request = urllib2.Request(self.url_prefix + self.url_path, data)
                    request.add_header('Content-Type', 'application/xml')
                    response = self._url_opener(self.url_path, request = request)
                    data = response.read()
                    response.close()
                    return data
                except urllib2.URLError as expt:
                    if tmoSeconds > 55:
                        raise expt
                    tmoSeconds += tmoDelta
                    self.logger.info("Failed to connect to the server: %s ", str(expt))
                    self.logger.info("Will retry the connection in %s seconds", str(tmoSeconds))
                    time.sleep(tmoSeconds)
        except urllib2.URLError as ex:
            raise p_err.ULPProvisioningError( \
                    p_err.ErrorCodes.COMM_FAILURE, target=p_err.CommType.PROV_SERVER, extraInfo=str(ex))
            
    def getConfig(self, node_id, node_type, config_id, path_in = '', path_out = '', configAlias = None):

        # create message object
        if configAlias:
            config_req_msg = xml_msg.Config_Values_Request_Type( \
                NID=node_id, 
                Node_Type=node_type, 
                Config_Alias=configAlias)
        else:
            config_req_msg = xml_msg.Config_Values_Request_Type( \
                NID=node_id, 
                Node_Type=node_type, 
                Prov_Config_ID=config_id)
        topMsg = xml_msg.Prov_Inf_Message(Config_Values_Request=config_req_msg)

        # convert to XML string
        xmlStrIO = StringIO.StringIO()
        topMsg.export(xmlStrIO, 0, namespace_='tns:', namespacedef_='xmlns:tns="orw:prov"')
        xmlStr = xmlStrIO.getvalue()
        xmlStrIO.close()

        if self.debug:
            self.logger.info('sending to %s:\n%s' % (self.url_path, xmlStr))

        rsp_xml = self._post(xmlStr)
        if self.debug:
            self.logger.info('received:\n%s' % rsp_xml)
            
        rsp = xml_msg.parseString(rsp_xml).get_Config_Values_Response()
        if not rsp:
            self.logger.error("Received unparseable or wrong response message")
            if self.debug:
                self.logger.info(rsp_xml)
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.COMM_FAILURE, target=p_err.CommType.PROV_SERVER)
        if rsp.get_Status() != 'success':
            self.logger.error("Response received with error %s" % rsp.get_Status())
            if self.debug:
                self.logger.info(rsp_xml)
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.ERROR_RSP, target=p_err.CommType.PROV_SERVER)

        # populate output data
        data = ConfigData()

        node_info = rsp.get_Node_Info()
        data.node_version = node_info.get_Node_Version()
        data.kms_pub_key = node_info.get_KMS_Public_Key()
        data.gw_wide_key = node_info.get_GW_Wide_Key()
        data.gw_cdld_key = node_info.get_GW_CDLD_Key()

        # ensure node type matches
        if node_type and node_type != node_info.get_Node_Type():
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.VERIFICATION_FAILED,
                target=p_err.CommType.PROV_SERVER,
                extraInfo='node_type mismatch: local %s server %s' % (node_type, node_info.get_Node_Type()))
            
        # convert hex strings to binary
        data.kms_pub_key = key_utils.convert_hex_string_to_byte_string(data.kms_pub_key)
        data.gw_wide_key = key_utils.convert_hex_string_to_byte_string(data.gw_wide_key)
        data.gw_cdld_key = key_utils.convert_hex_string_to_byte_string(data.gw_cdld_key)
        
        data.node_files = TargetFileInfo(
            node_info.get_Node_Factory_Config().get_Path(),
            node_info.get_Node_Factory_Config().get_MD5_Hash(),
            node_info.get_Node_Field_Config().get_Path(),
            node_info.get_Node_Field_Config().get_MD5_Hash(),
            node_info.get_Node_Binary_Config().get_Path(),
            node_info.get_Node_Binary_Config().get_MD5_Hash(),
            rsp.get_UseHttpFileXfer(),
            self.logger,
            self.server,
            self.port,
            self._url_opener,
            path_in, path_out, 'node')

        for app_info in rsp.get_App_Info():
            data.app_names.append(app_info.get_App_Name())
            data.app_versions.append(app_info.get_App_Host_Version())
            
            if app_info.get_App_Backend_Public_Key():
                data.app_pub_keys.append( \
                    key_utils.convert_hex_string_to_byte_string( \
                        app_info.get_App_Backend_Public_Key()))
            else:
                data.app_pub_keys.append(None)

            if app_info.get_App_Factory_Config():
                factoryPath = app_info.get_App_Factory_Config().get_Path()
                factorymd5 = app_info.get_App_Factory_Config().get_MD5_Hash()
            else:
                factoryPath = None
                factorymd5 = None
            if app_info.get_App_Field_Config():
                fieldPath = app_info.get_App_Field_Config().get_Path()
                fieldmd5 = app_info.get_App_Field_Config().get_MD5_Hash()
            else:
                fieldPath = None
                fieldmd5 = None
            if app_info.get_App_Binary_Config():
                binaryPath = app_info.get_App_Binary_Config().get_Path()
                binarymd5 = app_info.get_App_Binary_Config().get_MD5_Hash()
            else:
                binaryPath = None
                binarymd5 = None
                
            data.app_files.append(TargetFileInfo(
                    factoryPath, factorymd5,
                    fieldPath, fieldmd5,
                    binaryPath, binarymd5,
                    rsp.get_UseHttpFileXfer(),
                    self.logger,
                    self.server,
                    self.port,
                    self._url_opener,
                    path_in, path_out, app_info.get_App_Name()))
            
        return data

    def setDutParams(self, timestamp, config_id, batch, node_id, 
                     nodeKey=None, app_names = [], app_ids = [], app_keys=[],
                     extraAppInfo=[], configAlias = None):

        if len(app_names) != len(app_keys) or \
                len(app_names) != len(app_ids) or \
                len(app_names) != len(extraAppInfo):
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.INVALID_ARGUMENTS,
                target=p_err.CommType.LOCAL_ERROR,
                extraInfo='App arrays not of consistent length')
            
        if nodeKey:
            node_key_hex = key_utils.convert_byte_string_to_hex_string(nodeKey)
            nodeinfo = xml_msg.Node_Key_Info_Type(Encrypted_Node_Key=node_key_hex)
        else:
            nodeinfo = None

        if configAlias:
            set_params_msg = xml_msg.End_Device_Set_Parameters_Values_Request_Type(
                Timestamp_Provisioned=timestamp, 
                Config_Alias=configAlias,
                Batch_Number=batch,
                NID=node_id, 
                Node_Key_Info=nodeinfo)
        else:
            set_params_msg = xml_msg.End_Device_Set_Parameters_Values_Request_Type(
                Timestamp_Provisioned=timestamp, 
                Prov_Config_ID=config_id,
                Batch_Number=batch,
                NID=node_id, 
                Node_Key_Info=nodeinfo)

        for idx in range(len(app_names)):
            if not app_keys[idx]:
                continue

            if extraAppInfo[idx]:
                extra_s = key_utils.convert_byte_string_to_hex_string(extraAppInfo[idx])
            else:
                extra_s = None

            if app_keys[idx]:
                app_key_hex = key_utils.convert_byte_string_to_hex_string(app_keys[idx])
            else:
                app_key_hex = None
                
            appinfo = xml_msg.App_Key_Info_Type(
                App_Name=app_names[idx],
                App_ID=app_ids[idx],
                Encrypted_App_Key=app_key_hex,
                Other_App_Info=extra_s)
            set_params_msg.add_App_Key_Info(appinfo)

        topMsg = xml_msg.Prov_Inf_Message(End_Device_Set_Parameters_Values_Request=set_params_msg)

        # convert to XML string
        xmlStrIO = StringIO.StringIO()
        topMsg.export(xmlStrIO, 0, namespace_='tns:', namespacedef_='xmlns:tns="orw:prov"')
        xmlStr = xmlStrIO.getvalue()
        xmlStrIO.close()

        if self.debug:
            self.logger.info('sending:\n%s' % xmlStr)

        rsp_xml = self._post(xmlStr)
        if self.debug:
            self.logger.info('received:\n%s' % rsp_xml)
            
        rsp = xml_msg.parseString(rsp_xml).get_End_Device_Set_Parameters_Values_Response()
        if not rsp:
            self.logger.error("Received unparseable or wrong response message")
            if self.debug:
                self.logger.info(rsp_xml)
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.COMM_FAILURE, target=p_err.CommType.PROV_SERVER)
        if rsp.get_Status() != 'success':
            self.logger.error("Response received with error %s" % rsp.get_Status())
            if self.debug:
                self.logger.info(rsp_xml)
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.ERROR_RSP, target=p_err.CommType.PROV_SERVER)


###############################################################################
# Main program body.
###############################################################################
if __name__ == '__main__':
    print 'Not intended as a standalone program!'
    sys.exit(-1)
