"""Provides host interface message classes and construction methods.

See host_msg.h/host_msg.c for more info about these interface message structures.
"""

# If you want to know how this all works, keep reading:
#
# Most messages are defined as a class which inherits from Message.  Message
# is a ctypes class.  The message names are important, they have to match the
# name used in the enum from host_msg.h/host_customer_msg.h which is copied in
# this file.  By matching the names we can do lookups into the table, etc.
#
# All Message/ucl_nhp_msg.Structure objects have the ability to set/get bytes/strings as well
# as do normal ctypes things.
#
# A function provides the ability to construct a message from a list of bytes.
#
# Variable length messages are supported by constructing a class at runtime with
# correctly sized fields.  The TX_SDU message is a good example.  Variable length
# message support is still a work in progress.


import ctypes
import struct
import warnings

import ucl_nhp_msg
import util

try:
    import parsePackedDbg
except ImportError:
    parsePackedDbg = None

class Message(ucl_nhp_msg.Message):
    """Message class for host interface messages."""

    def pack_header(self):
        self.header.msgType = eval('types.%s' % self.__class__.__name__)
        self.header.msgLen = self.sizeof()

        self._msgType = self.header.msgType
        self._msgLen = self.header.msgLen


Header = ucl_nhp_msg.Header
Footer = ucl_nhp_msg.Footer


MAX_SDU_SIZE = 464
MAX_WITH_SECURITY_SDU_SIZE = 480
NUM_SCAN_SYSTEMS_V3 = 24
NUM_SCAN_SYSTEMS_V4 = 63
UNIL_LOG_BMSK_SIZE = 32


class PROTOCOL_VERSION_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]


class PROTOCOL_VERSION_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('major_version', ctypes.c_uint),
        ('minor_version', ctypes.c_uint),
        ('branch_epoch', ctypes.c_uint),
        ('reserved', ctypes.c_ubyte * 244),
        ('footer', Footer),
    ]


class DBG_STR_IND(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('num_bytes', ctypes.c_ubyte),
        ('rsv1', ctypes.c_ubyte),
        ('rsv2', ctypes.c_ushort),
        ('string', ctypes.c_char*100),
        ('footer', Footer),
    ]

    def __str__(self):
        s = self.string[:self.num_bytes]
        return s

class DBG_PACKED_IND(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]
    
    def __init__(self, *args, **kwargs):
        Message.__init__(self, *args, **kwargs)
        self.debugString = None

    def set_bytes(self, bytes):
        if parsePackedDbg:
            hdr = Header()
            hdr.set_bytes(bytes)
            typ = hdr.msgType
            length = hdr.msgLen
            self.debugString = parsePackedDbg.parseMsg(length, "".join((map(chr,bytes[4:]))))

    def __str__(self):
        return 'NODE DBG: ' + self.debugString
                                                      
    
class SET_LOG_MASK(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('mask', ctypes.c_uint),
        ('footer', Footer),
    ]


class GET_LOG_MASK(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]


class GET_LOG_MASK_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('mask', ctypes.c_uint),
        ('footer', Footer),
    ]


class FRAME_ENERGY_DIAG(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('segment', ctypes.c_uint),
        ('values', ctypes.c_uint*64),
        ('footer', Footer),
    ]


class GET_VERSION_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]

class GET_VERSION_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('major', ctypes.c_ubyte),
        ('minor', ctypes.c_ubyte),
        ('point', ctypes.c_ubyte),
        ('pad', ctypes.c_ubyte),
        ('descr', ctypes.c_char*16),
        ('buildStamp', ctypes.c_char*128),
        ('footer', Footer),
    ]

class SCAN_RESULT_IND(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('bchGoldCode', ctypes.c_uint),
        ('channel', ctypes.c_ubyte),
        ('result', ctypes.c_ubyte),
        ('rssiRaw', ctypes.c_short),
        ('avgLinearAPMetric', ctypes.c_uint),
        ('avgDLSFMetric', ctypes.c_ushort),
        ('isJoined', ctypes.c_ubyte),
        ('count', ctypes.c_ubyte),
        ('sysMgrState', ctypes.c_ubyte),
        ('sysSelState', ctypes.c_ubyte),
        ('flashSlot', ctypes.c_ubyte),
        ('antennaSetting', ctypes.c_ubyte),
        ('apMetric', ctypes.c_short),
        ('pad', ctypes.c_ubyte*2),
        ('footer', Footer),
    ]

class NETWORK_EXIT_IND(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('lastNetExitReason', ctypes.c_ubyte),
        ('lastHardStartReason', ctypes.c_ubyte),
        ('pad', ctypes.c_ubyte*2),
        ('footer', Footer),
    ]

class GET_HOST_INTF_STATE_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]

class GET_HOST_INTF_STATE_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('airlinkOn', ctypes.c_ubyte),
        ('frameStatsEnabled', ctypes.c_ubyte),
        ('hostConnected', ctypes.c_ubyte),
        ('phyTestMode', ctypes.c_ubyte),
        ('logMask', ctypes.c_uint),
        ('footer', Footer),
    ]

class POTENTIAL_POWER_FAIL(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]

class POWER_FAIL(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('payload', ctypes.c_ubyte*22),
        ('payloadLen', ctypes.c_ubyte),
        ('pad', ctypes.c_ubyte),
        ('footer', Footer),
    ]

class IS_POWER_FAILED_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]
class IS_POWER_FAILED_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('isPowerFailed', ctypes.c_uint),
        ('footer', Footer),
    ]

class POWER_RESTORED(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]

class PF_SDU_STATUS(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('sduStatus', ctypes.c_ushort),
        ('pad', ctypes.c_ushort),
        ('footer', Footer),
    ]
    
class RX_SAMPLE_IND(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('packedSample', ctypes.c_uint*125),
        ('footer', Footer),
    ]
    
class GET_CDLD_STATUS_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]

class GET_CDLD_STATUS_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('currentPhyFrameNumber', ctypes.c_int),
        ('currentSystemFrameNumber', ctypes.c_int),
        ('firstPhyFrameNumber', ctypes.c_int),
        ('framesBeforeFirst', ctypes.c_int),
        ('numSdus', ctypes.c_ushort),
        ('numSdusReceived', ctypes.c_ushort),
        ('isImageDone', ctypes.c_ubyte),
        ('isImageIgnored', ctypes.c_ubyte),
        ('isReady', ctypes.c_ubyte),
        ('isImmediate', ctypes.c_ubyte),
        ('currentBroadcastSeq', ctypes.c_ubyte),
        ('currentSeq', ctypes.c_ubyte),
        ('seq', ctypes.c_ubyte),
        ('currentNodeType', ctypes.c_ubyte),
        ('nodeType', ctypes.c_ubyte),
        ('imageType', ctypes.c_ubyte),
        ('sduReceivedBits', ctypes.c_ubyte*64),
        ('nodeTypeInBch0', ctypes.c_byte),
        ('reserved', ctypes.c_ubyte),
        ('footer', Footer),
    ]


class SET_CDLD_STATUS_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('numSdus', ctypes.c_ushort),
        ('numSdusReceived', ctypes.c_ushort),
        ('isImageDone', ctypes.c_ubyte),
        ('isReady', ctypes.c_ubyte),
        ('isImmediate', ctypes.c_ubyte),
        ('seq', ctypes.c_ubyte),
        ('nodeType', ctypes.c_ubyte),
        ('imageType', ctypes.c_ubyte),
        ('sduReceivedBits', ctypes.c_ubyte*64),
        ('reserved', ctypes.c_ubyte*2),
        ('footer', Footer),
    ]

class GET_POWER_CTRL_OFFSETS_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]

class GET_POWER_CTRL_OFFSETS_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('pwrCtrlParam', ctypes.c_ubyte*NUM_SCAN_SYSTEMS_V4),
        ('reserved', ctypes.c_ubyte),
        ('footer', Footer),
    ]

class CLEAR_POWER_CTRL_OFFSETS_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]

class CLEAR_COUNTERS_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('resetWdogCount', ctypes.c_ubyte),
        ('resetSysMetricsCounters', ctypes.c_ubyte),
        ('pad', ctypes.c_ubyte*2),
        ('footer', Footer),
    ]


class GET_MUD_GROUPS_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('eraseAllMudGroupsAndKeys', ctypes.c_uint),
        ('reserved', ctypes.c_uint),
        ('footer', Footer),
    ]


class GET_MUD_GROUPS_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('numGroups', ctypes.c_uint),
        ('groups', ctypes.c_ushort*8),
        ('reserved', ctypes.c_uint),
        ('footer', Footer),
    ]


class TxSdu(ucl_nhp_msg.Structure):
    pass


def make_txsdu(num_bytes = MAX_SDU_SIZE, *args, **kwargs):
    """Class generator to construct a TxSdu of the correct payload length."""

    #assert num_bytes <= MAX_SDU_SIZE, "can't construct TXSDU of size %d" % num_bytes

    class MyTxSdu(TxSdu):
        _pack_ = 1
        _fields_ = [
            ('header', Header),
            ('size', ctypes.c_ushort),
            ('host_tag', ctypes.c_ushort),
            ('flags', ctypes.c_ushort),
            ('pad', ctypes.c_ushort),
            ('payload', ctypes.c_ubyte*num_bytes),
            ('footer', Footer),
        ]

        def __init__(self, *args, **kwargs):
            """Necessary to bypass TxSdu constructor."""
            ucl_nhp_msg.Structure.__init__(self, *args, **kwargs)

        def getId(self):
            return types.TXSDU

    return MyTxSdu(*args, **kwargs)


class TXSDU_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('host_tag', ctypes.c_ushort),
        ('isEnqueued', ctypes.c_ushort),
        ('footer', Footer),
    ]


txsdu_result_status = util.Enum( # ripped from host_customer_msg.h
    """
    HOST_MSG_SDU_STATUS_BITS_TRANSMITTED            = (1<<0),
    HOST_MSG_SDU_STATUS_BITS_ACK_SUCCESS            = (1<<1),
    HOST_MSG_SDU_STATUS_BITS_ACK_FAIL               = (1<<2),
    HOST_MSG_SDU_STATUS_BITS_REPLACED               = (1<<3),
    HOST_MSG_SDU_STATUS_BITS_BUFFER_FULL            = (1<<4),
    HOST_MSG_SDU_STATUS_BITS_OTHER_ERROR            = (1<<5),
    HOST_MSG_SDU_STATUS_BITS_DROPPED_NET_EXIT       = (1<<6),
    HOST_MSG_SDU_STATUS_BITS_DROPPED_HOST           = (1<<7),
    HOST_MSG_SDU_STATUS_BITS_DROPPED_MAINTENANCE    = (1<<8),
    HOST_MSG_SDU_STATUS_BITS_DROPPED_CDLD           = (1<<9),
    HOST_MSG_SDU_STATUS_BITS_DROPPED_NOT_JOINED     = (1<<10),
    HOST_MSG_SDU_STATUS_BITS_DROPPED_BAD_SIZE       = (1<<11),
    HOST_MSG_SDU_STATUS_BITS_DROPPED_BAD_FLAGS      = (1<<12),
    HOST_MSG_SDU_STATUS_BITS_DROPPED_NOT_REACHABLE  = (1<<13),
    HOST_MSG_SDU_STATUS_BITS_DROPPED_POWER_FAIL     = (1<<14),
    """,
    prefix='HOST_MSG_SDU_STATUS_BITS_',
)


class TXSDU_RESULT(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('host_tag', ctypes.c_ushort),
        ('sduStatus', ctypes.c_ushort),
        ('footer', Footer),
    ]


class TX_BE_PDU(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('payload', ctypes.c_ubyte*8),
        ('footer', Footer),
    ]


class RxSdu(ucl_nhp_msg.Structure):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('size', ctypes.c_ushort),
        ('flags', ctypes.c_ushort),
        ('payload', ctypes.c_ubyte*MAX_SDU_SIZE),
        ('footer', Footer),
    ]

class RxSduPayload(ucl_nhp_msg.Structure):
    _pack_ = 1
    
class TxSduPayload(ucl_nhp_msg.Structure):
    _pack_ = 1
    
def genRxSduPayload(numBytes = MAX_SDU_SIZE):
    assert numBytes <= MAX_SDU_SIZE

    class _RxSduPayload(RxSduPayload):
        _pack_ = 1
        _fields_ = [
            ('sdu', ctypes.c_ubyte * numBytes),
        ]

    return _RxSduPayload

def genTxSduPayload(numBytes = MAX_SDU_SIZE):
    assert numBytes <= MAX_SDU_SIZE

    class _TxSduPayload(TxSduPayload):
        _pack_ = 1
        _fields_ = [
            ('sdu', ctypes.c_ubyte * numBytes),
        ]

    return _TxSduPayload

def genRxSdu(numBytes = MAX_SDU_SIZE):
    assert numBytes <= MAX_SDU_SIZE
    class RXSDU(Message):
        _pack_ = 1
        _fields_ = [ 
            ('header', Header),
            ('size', ctypes.c_ushort),
            ('pad', ctypes.c_ushort),
            ('payload', genRxSduPayload(numBytes)),
            ('footer', Footer),
        ]

    return RXSDU

def genTxSdu(numBytes = MAX_SDU_SIZE):
    assert numBytes <= MAX_SDU_SIZE
    payloadSize = ((size + 3)/4)*4
    class TXSDU(Message):
        _pack_ = 1
        _fields_ = [ 
            ('header', Header),
            ('size', ctypes.c_ushort),
            ('host_tag', ctypes.c_ushort),
            ('flags', ctypes.c_ushort),
            ('pad', ctypes.c_ushort),
            ('payload', genTxSduPayload(payloadSize)),
            ('footer', Footer),
        ]

    return TXSDU

systemSetStateEnum = {
    'AIRLINK_OFF' : 0,
    'AIRLINK_ON' : 1}


class SYSTEM_SET_STATE(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('phy_enable', ctypes.c_uint),
        ('footer', Footer),
    ]


class GET_STATE(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]

systemGetStateEnum = {
    'SYS_STATE_NIL'      : 0,
    'SYS_STATE_STARTUP'  : 1,
    'SYS_STATE_IDLE'     : 2,
    'SYS_STATE_SCANNING' : 3,
    'SYS_STATE_TRACK'    : 4,
    'SYS_STATE_JOINED'   : 5}

class GET_STATE_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('state', ctypes.c_uint),
        ('footer', Footer),
    ]

class OTA_DIAG_IND(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('status', ctypes.c_uint),
        ('footer', Footer),
    ]

class PROVISION_KEYS_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),

        ('rootKey', ctypes.c_ubyte*16),
        ('gatewayKey', ctypes.c_ubyte*24),
        ('gatewayCdldKey', ctypes.c_ubyte*16),

        ('footer', Footer),
    ]


class GET_KEYS_PROVISIONED_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]


class GET_KEYS_PROVISIONED_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('result', ctypes.c_uint),
        ('footer', Footer),
    ]

class PROVISION_KEYS_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]


class GET_NODE_TYPE_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]

nodeTypeEnum = {
    'ENODE' : 0,
    'UNODE' : 1,
    'DNODE' : 2,
    'PNODE' : 3,
    'UNKNOWN' : 255 }
nodeTypeReverseEnum = dict([(v, k) for (k, v) in nodeTypeEnum.items()])

class GET_NODE_TYPE_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('nodeType', ctypes.c_ubyte),
        ('pad', ctypes.c_ubyte*3),
        ('footer', Footer),
    ]

manufTxTestModeEnum = {
    'OFF' : 0,
    'CW_CENTER' : 1,
    'CW_OFFSET' : 2,
    'MODULATED' : 3}

class CONF_MANUF_TX_TEST(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('centerFreqKHzOffset', ctypes.c_uint),
        ('vga', ctypes.c_ubyte),
        ('mode', ctypes.c_ubyte),
        ('antennaSetting', ctypes.c_ubyte),
        ('spreading', ctypes.c_ubyte),
        ('footer', Footer),
    ]

class MANUF_TX_TEST_IND(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('temperature', ctypes.c_short),
        ('vga', ctypes.c_short),
        ('txPower', ctypes.c_short),
        ('pad', ctypes.c_short),
        ('footer', Footer),
    ]

class READ_TXPWR_CAL_DATA_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]

class READ_TXPWR_CAL_DATA_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('maxTxVGALow', ctypes.c_uint),
        ('maxTxVGAMid', ctypes.c_uint),
        ('maxTxVGAHigh', ctypes.c_uint),
        ('max_tx_pwr_low_freq', ctypes.c_uint),
        ('max_tx_pwr_mid_freq', ctypes.c_uint),
        ('max_tx_pwr_high_freq', ctypes.c_uint),
        ('tx_vga35_pwr_low_freq', ctypes.c_uint),
        ('tx_vga35_pwr_mid_freq', ctypes.c_uint),
        ('tx_vga35_pwr_high_freq', ctypes.c_uint),
        ('temperature_pt', ctypes.c_short*10),
        ('temp_power_diff_q4', ctypes.c_short*10),
        ('footer', Footer),
    ]

class CONF_MANUF_RX_TEST(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('centerFreqKHzOffset', ctypes.c_uint),
        ('lna', ctypes.c_ubyte),
        ('vga', ctypes.c_ubyte),
        ('adcSamples', ctypes.c_ushort),
        ('adcSamplesSkip', ctypes.c_ushort),
        ('antennaSetting', ctypes.c_ubyte),
        ('pad', ctypes.c_ubyte),
        ('footer', Footer),
    ]
    
class SYSTEM_STATE(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('state', ctypes.c_uint),
        ('footer', Footer),
    ]


class GET_SYS_METRICS(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]


class SysMetricsCounters(ucl_nhp_msg.Structure):
    #_pack_ = True
    _fields_ = [
        ('numJoinFail', ctypes.c_ubyte),
        ('numUserNetEnter', ctypes.c_ubyte),
        ('numPhyNetExit', ctypes.c_ubyte),
        ('numMacNetExit', ctypes.c_ubyte),
        ('numUserNetExit', ctypes.c_ubyte),
        ('curTemp', ctypes.c_ubyte),
        ('minTemp', ctypes.c_ubyte),
        ('maxTemp', ctypes.c_ubyte),
        ('numLogErr', ctypes.c_ubyte),
        ('numDroppedHostBoundMsgs', ctypes.c_ubyte),
        ('lastNetExitReason', ctypes.c_ubyte),
        ('lastHardStartReason', ctypes.c_ubyte),
        ('numSecurityIncidents', ctypes.c_ubyte),
        ('numSearchWidened', ctypes.c_ubyte),
        ('numAPIDChanged', ctypes.c_ubyte),
        ('numTxP1SdusFailed', ctypes.c_ubyte),
        ('numTxP2SdusFailed', ctypes.c_ubyte),
        ('numHostAbortSdus', ctypes.c_ubyte),
        ('numRxSdusSuccess', ctypes.c_ushort),
        ('numTxP1Sdus', ctypes.c_ushort),
        ('numTxP2Sdus', ctypes.c_ushort),
        ('numTxSystematicPdus', ctypes.c_ushort),
        ('numTxParityPdus', ctypes.c_ushort),
        ('rssiMean', ctypes.c_long),
        ('rssiVariance', ctypes.c_long),
        ('numRxPdus', ctypes.c_uint),
        ('numTxPdus', ctypes.c_uint),
    ]


class GET_SYS_METRICS_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('sfn', ctypes.c_uint),
        ('counters', SysMetricsCounters),
        ('footer', Footer),
    ]


class CONNECT(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('connected', ctypes.c_uint),
        ('footer', Footer),
    ]


class PhyRegsPayload(ucl_nhp_msg.Structure):
    _pack_ = 1
    _fields_ = [
        ('contents', ctypes.c_uint * 3),
    ]


class MacStatsIndPdusPayload(ucl_nhp_msg.Structure):
    _pack_ = 1


def genMacStatsIndPdusPayload(numPdus = 40):
    assert numPdus <= 40

    class _MacStatsIndPdusPayload(MacStatsIndPdusPayload):
        _pack_ = 1
        _fields_ = [
            ('typeOfPdus', ctypes.c_ubyte),
            ('numPdus', ctypes.c_ubyte),
            ('pdus', PhyRegsPayload * numPdus),
        ]

    return _MacStatsIndPdusPayload


class MacStatsIndSduPayload(ucl_nhp_msg.Structure):
    _pack_ = 1


def genMacStatsIndSduPayload(numBytes = MAX_WITH_SECURITY_SDU_SIZE):
    assert numBytes <= MAX_WITH_SECURITY_SDU_SIZE

    class _MacStatsIndSduPayload(MacStatsIndSduPayload):
        _pack_ = 1
        _fields_ = [
            ('typeOfSdu', ctypes.c_ubyte),
            ('size', ctypes.c_ushort),
            ('sdu', ctypes.c_ubyte * numBytes),
        ]

    return _MacStatsIndSduPayload


class MacStatsIndStreamReport(ucl_nhp_msg.Structure):
    _pack_ = 1
    _fields_ = [
        ('_pStateSize', ctypes.c_ubyte),
        ('seqNumNorm', ctypes.c_ubyte),
        ('seqNumCtrl', ctypes.c_ubyte),
        ('seqNumHigh', ctypes.c_ubyte),
        ('numTimeouts', ctypes.c_ubyte),


        ('_pStateSize', ctypes.c_ubyte),

        ('currentStream', ctypes.c_uint),
        ('canStartSdus', ctypes.c_uint),

        ('txCount', ctypes.c_ubyte),
        ('numTimeouts', ctypes.c_ubyte),
        ('encActive', ctypes.c_ubyte),
        ('pad0', ctypes.c_ubyte),

        ('encSdu', ctypes.c_uint),
        ('encStream', ctypes.c_ubyte),
        
        ('encWasFlushed', ctypes.c_ubyte),
        ('encDone', ctypes.c_ubyte),


        ('_streamStateSize', ctypes.c_ubyte),

        ('n_isActive', ctypes.c_ubyte),
        ('n_isActiveStream', ctypes.c_ubyte),
        ('n_isEncoded', ctypes.c_ubyte),
        ('n_timesEncoded', ctypes.c_ubyte),
        ('n_sdu', ctypes.c_uint),
        ('n_pduIndex', ctypes.c_ubyte),
        ('n_dribbleLow', ctypes.c_ubyte),
        ('n_timeOut', ctypes.c_ushort),
        ('n_absPduIndex', ctypes.c_ushort),
        ('n_pad1', ctypes.c_ushort),
        ('n_frameOfLastTx', ctypes.c_uint),
        ('n_pdusLeftInBurst', ctypes.c_uint),
        ('n_frameOfSessionStart', ctypes.c_uint),

        ('c_isActive', ctypes.c_ubyte),
        ('c_isActiveStream', ctypes.c_ubyte),
        ('c_isEncoded', ctypes.c_ubyte),
        ('c_timesEncoded', ctypes.c_ubyte),
        ('c_sdu', ctypes.c_uint),
        ('c_pduIndex', ctypes.c_ubyte),
        ('c_dribbleLow', ctypes.c_ubyte),
        ('c_timeOut', ctypes.c_ushort),
        ('c_absPduIndex', ctypes.c_ushort),
        ('c_pad1', ctypes.c_ushort),
        ('c_frameOfLastTx', ctypes.c_uint),
        ('c_pdusLeftInBurst', ctypes.c_uint),
        ('c_frameOfSessionStart', ctypes.c_uint),

        ('h_isActive', ctypes.c_ubyte),
        ('h_isActiveStream', ctypes.c_ubyte),
        ('h_isEncoded', ctypes.c_ubyte),
        ('h_timesEncoded', ctypes.c_ubyte),
        ('h_sdu', ctypes.c_uint),
        ('h_pduIndex', ctypes.c_ubyte),
        ('h_dribbleLow', ctypes.c_ubyte),
        ('h_timeOut', ctypes.c_ushort),
        ('h_absPduIndex', ctypes.c_ushort),
        ('h_pad1', ctypes.c_ushort),
        ('h_frameOfLastTx', ctypes.c_uint),
        ('h_pdusLeftInBurst', ctypes.c_uint),
        ('h_frameOfSessionStart', ctypes.c_uint),
        
    ]

class MacStatsIndDlAckReport(ucl_nhp_msg.Structure):
    _pack_ = 1
    _fields_ = [
        ('bits', ctypes.c_uint * 2),
        ('isActive', ctypes.c_ubyte),
        ('isComplete', ctypes.c_ubyte),
        ('missedDemods', ctypes.c_ubyte),
        ('isFrag', ctypes.c_ubyte),
        ('seqNum', ctypes.c_ubyte),
        ('frameType', ctypes.c_ubyte),
        ('count', ctypes.c_ubyte),
        ('pad', ctypes.c_ubyte),
    ]

class MacStatsIndSduReportPayload(ucl_nhp_msg.Structure):
    _pack_ = 1
    _fields_ = [
        ('dlAck', MacStatsIndDlAckReport),
        ('stream', MacStatsIndStreamReport),
    ]

class MacStatsIndBufferUsagePayload(ucl_nhp_msg.Structure):
    _pack_ = 1
    _fields_ = [
        ('txSduQueueUsed', ctypes.c_ubyte),
        ('txSduQueueMax', ctypes.c_ubyte),
        ('hpSduQueueUsed', ctypes.c_ubyte),
        ('hpSduQueueMax', ctypes.c_ubyte),
        ('rdSduQueueUsed', ctypes.c_ubyte),
        ('rdSduQueueMax', ctypes.c_ubyte),
        ('beSduQueueUsed', ctypes.c_ubyte),
        ('beSduQueueMax', ctypes.c_ubyte),
    ]
    
class MacStatsIndRxReportPayload(ucl_nhp_msg.Structure):
    _pack_ = 1
    _fields_ = [
        ('macFlags', ctypes.c_uint),
        ('numRxPdus', ctypes.c_ushort),
        ('dlChannelOpen', ctypes.c_ubyte),
        ('rxCompleteStatus', ctypes.c_ubyte),
        ('numDiscardedSdus', ctypes.c_ubyte),
        ('numCompletedDataSdus', ctypes.c_ubyte),
        ('numCompletedControlSdus', ctypes.c_ubyte),
        ('consecutiveFailedDemodCondition', ctypes.c_ubyte),
        ('consecutiveFailedDeomds', ctypes.c_ubyte),
        ('consecutiveBchFailures', ctypes.c_ubyte),
        ('numDupPdus', ctypes.c_ubyte),
        ('bufferUsage', MacStatsIndBufferUsagePayload),
    ]
    
class MacStatsIndTxReportPayload(ucl_nhp_msg.Structure):
    _pack_ = 1
    _fields_ = [
        ('macFlags', ctypes.c_uint),
        ('numTxPdus', ctypes.c_ushort),
        ('txCompleteStatus', ctypes.c_ubyte),
        ('spreadingFactor', ctypes.c_ubyte),
        ('startingSubslot', ctypes.c_ushort),
        ('bufferUsage', MacStatsIndBufferUsagePayload),
    ]


class MacStatsIndFlagsPayload(ucl_nhp_msg.Structure):
    _pack_ = 1
    _fields_ = [
        ('macFlags', ctypes.c_uint),
    ]


class MacStatsIndTxSchedulePayload(ucl_nhp_msg.Structure):
    _pack_ = 1
    _fields_ = [
        ('txReason', ctypes.c_ubyte),
        ('retStat', ctypes.c_ubyte),
        ('nextSchedulable', ctypes.c_ushort),
        ('sfn', ctypes.c_uint),
        ('phyFrame', ctypes.c_uint),
    ]


class MacStatsIndRxSchedulePayload(ucl_nhp_msg.Structure):
    _pack_ = 1
    _fields_ = [
        ('rxReason', ctypes.c_ubyte),
        ('channel', ctypes.c_ubyte),
        ('spreadingFactor', ctypes.c_ubyte),
        ('returnValue', ctypes.c_ubyte),
        ('goldCode', ctypes.c_int),
        ('startingSubSlot', ctypes.c_ushort),
        ('numberOfSubSlots', ctypes.c_ushort),
        ('sfn', ctypes.c_uint),
        ('phyFrame', ctypes.c_uint),
    ]
    

class MacStatsIndCommon(ucl_nhp_msg.Structure):
    _pack_ = 1
    _fields_ = [ 
        ('numLoggingMsgsDropped', ctypes.c_ubyte),
        ('sfn', ctypes.c_uint),
    ]


def genMacStatsIndPdus(numPdus = 40):
    assert numPdus <= 40

    class MAC_STATS_IND_PDUS(Message):
        _pack_ = 1
        _fields_ = [ 
            ('header', Header),
            ('common', MacStatsIndCommon),
            ('payload', genMacStatsIndPdusPayload(numPdus)),
            ('footer', Footer),
        ]

    return MAC_STATS_IND_PDUS


def genMacStatsIndSdu(numBytes = MAX_WITH_SECURITY_SDU_SIZE):
    assert numBytes <= MAX_WITH_SECURITY_SDU_SIZE
    class MAC_STATS_IND_SDU(Message):
        _pack_ = 1
        _fields_ = [ 
            ('header', Header),
            ('common', MacStatsIndCommon),
            ('payload', genMacStatsIndSduPayload(numBytes)),
            ('footer', Footer),
        ]

    return MAC_STATS_IND_SDU


class MAC_STATS_IND_RX_REPORT(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('common', MacStatsIndCommon),
        ('payload', MacStatsIndRxReportPayload),
        ('footer', Footer),
    ]


class MAC_STATS_IND_TX_REPORT(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('common', MacStatsIndCommon),
        ('payload', MacStatsIndTxReportPayload),
        ('pad', ctypes.c_ubyte),
        ('footer', Footer),
    ]

class MAC_STATS_IND_SDU_REPORT(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('common', MacStatsIndCommon),
        ('payload', MacStatsIndSduReportPayload),
        ('pad', ctypes.c_ubyte),
        ('footer', Footer),
    ]

class MAC_STATS_IND_FLAGS(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('common', MacStatsIndCommon),
        ('payload', MacStatsIndFlagsPayload),
        ('pad', ctypes.c_ubyte*3),
        ('footer', Footer),
    ]


class MAC_STATS_IND_TX_SCHEDULE(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('common', MacStatsIndCommon),
        ('payload', MacStatsIndTxSchedulePayload),
        ('pad', ctypes.c_ubyte*3),
        ('footer', Footer),
    ]


class MAC_STATS_IND_RX_SCHEDULE(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('common', MacStatsIndCommon),
        ('payload', MacStatsIndRxSchedulePayload),
        ('pad', ctypes.c_ubyte*3),
        ('footer', Footer),
    ]


class WRITE_FLASH_PAGE_REQ(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('offset', ctypes.c_uint),
        ('data', ctypes.c_ubyte*256),
        ('footer', Footer),
    ]


class WRITE_FLASH_PAGE_RSP(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('footer', Footer),
    ]


class READ_FLASH_PAGE_REQ(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('offset', ctypes.c_uint),
        ('footer', Footer),
    ]


class READ_FLASH_PAGE_RSP(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('data', ctypes.c_ubyte*256),
        ('footer', Footer),
    ]


class VERIFY_FLASH_PAGE_REQ(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('offset', ctypes.c_uint),
        ('data', ctypes.c_ubyte*256),
        ('footer', Footer),
    ]


class VERIFY_FLASH_PAGE_RSP(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('valid', ctypes.c_ubyte),
        ('reserved', ctypes.c_ubyte*3),
        ('footer', Footer),
    ]


class FLUSH_TXSDU_QUEUE(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('includeInProgressSdus', ctypes.c_uint),
        ('footer', Footer),
    ]


class FLUSH_TXSDU_QUEUE_RSP(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('success', ctypes.c_uint),
        ('footer', Footer),
    ]


class SET_PRE_UPDATE_NOTIFICATION_REQ(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('timeInMs', ctypes.c_uint),
        ('footer', Footer),
    ]


class SET_PRE_UPDATE_NOTIFICATION_RSP(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('result', ctypes.c_uint),
        ('footer', Footer),
    ]


class SET_HOST_METADATA_REQ(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('appId', ctypes.c_uint),
        ('size', ctypes.c_ubyte),
        ('metadata', ctypes.c_ubyte*12),
        ('reserved', ctypes.c_ubyte*8),
        ('pad', ctypes.c_ubyte*3),
        ('footer', Footer),
    ]


class PRE_UPDATE_NOTIFICATION_IND(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('reserved', ctypes.c_uint),
        ('footer', Footer),
    ]


class TIME_UNTIL_UPDATE_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]


class TIME_UNTIL_UPDATE_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('seconds', ctypes.c_uint),
        ('footer', Footer),
    ]


class BLACKOUT_START_IND(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('secUntilStart', ctypes.c_uint),
        ('durationInSec', ctypes.c_uint),
        ('footer', Footer),
    ]

class BLACKOUT_END_IND(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('wasUpdateIntervalSkipped', ctypes.c_ubyte),
        ('pad', ctypes.c_ubyte*3),
        ('footer', Footer),
    ]

class BROADCAST_START_IND(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('bcastId', ctypes.c_uint),
        ('payload', ctypes.c_ubyte*256),
        ('length', ctypes.c_uint),
        ('footer', Footer),
    ]

class BROADCAST_START_CNF(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('bcastId', ctypes.c_uint),
        ('acceptBroadcast', ctypes.c_uint),
        ('footer', Footer),
    ]

class BROADCAST_END_IND(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('bcastId', ctypes.c_uint),
        ('length', ctypes.c_uint),
        ('footer', Footer),
    ]

class BROADCAST_DATA_REQ(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('bcastId', ctypes.c_uint),
        ('offset', ctypes.c_uint),
        ('length', ctypes.c_uint),
        ('footer', Footer),
    ]

broadcastStatusEnum = {
    'SUCCESS' : 0,
    'FAILURE_OUT_OF_RANGE' : 1,
    'INVALID_BCAST_ID' : 2}

class BROADCAST_DATA_RSP(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('status', ctypes.c_ushort),
        ('pack', ctypes.c_ushort),
        ('bcastId', ctypes.c_uint),
        ('offset', ctypes.c_uint),
        ('length', ctypes.c_uint),
        ('payload', ctypes.c_ubyte*256),
        ('footer', Footer),
    ]

class NODE_SW_UPGRADE_IND(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('footer', Footer),
    ]

class NODE_SW_UPGRADE_CNF(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('footer', Footer),
    ]

class SET_HOST_ID_REQ(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('hostId', ctypes.c_ubyte*16),
        ('footer', Footer),
    ]

class START_FRAME_STATS(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]


class STOP_FRAME_STATS(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]

phyOpEnum = {
    0 : 'LOCKED_PREAMBLE_FOR_TRACKING',
    1 : 'LOCKED_PREAMBLE_FOR_TX',
    2 : 'LOCKED_PREAMBLE_FOR_BGSCAN',
    3 : 'PREAMBLE_PLUS_DEMOD',
    4 : 'FRAME_TRACKING',
    5 : 'FRAME_TRACKING_FAIL_RECOVERY',
    6 : 'COLD_ACQU',
    7 : 'BACKGROUND_SCAN'}

class FRAME_STATS(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('fingerTimingOffsetParity',ctypes.c_ushort*10),
        ('fingerCAFC',ctypes.c_short*10),
        ('boostedFineAFCMetric', ctypes.c_ushort*10),
        ('fingerEnergy',ctypes.c_ushort*10),
        ('hammingWeight', ctypes.c_short*10),
        ('fingerFineAFCs',ctypes.c_ubyte*10),
        ('winningFineAFC', ctypes.c_ubyte*10),
        ('fingerPower', ctypes.c_uint*10),
        ('lowTimingOffset', ctypes.c_ushort),
        ('highTimingOffset', ctypes.c_ushort),
        ('lowCAFC', ctypes.c_short),
        ('highCAFC', ctypes.c_short),
        ('frameDelaySymbols', ctypes.c_ushort),
        ('RSSI', ctypes.c_short),
        ('rssi_high', ctypes.c_short),
        ('rssi_low', ctypes.c_short),
        ('freqOffset', ctypes.c_int),
        ('oscCal32k', ctypes.c_uint),
        ('oscCal26m', ctypes.c_uint),
        ('phyFrameNum', ctypes.c_uint),
        ('subslot', ctypes.c_ubyte),
        ('lastDchSpreading', ctypes.c_ubyte),
        ('channel', ctypes.c_ubyte),
        ('numLoggingMsgsDropped', ctypes.c_ubyte),
        ('tempAdc', ctypes.c_ushort),
        ('tempEst', ctypes.c_short),
        ('numSubslots', ctypes.c_ushort),
        ('sfn', ctypes.c_ushort),
        ('backgroundScanConfig', ctypes.c_uint),
        ('servingAPConfig', ctypes.c_uint),
        ('dchGoldCode', ctypes.c_uint),
        ('calcDchSF', ctypes.c_ubyte),
        ('phyOperation', ctypes.c_ubyte),
        ('antennaSetting', ctypes.c_ubyte),
        ('apMetric', ctypes.c_short),
        ('pad', ctypes.c_ubyte*3),
        ('footer', Footer),
    ]
    
    def __makeList(self, array):
        returnTuple = ()
        for element in array:
            returnTuple += (element,)
        return returnTuple
    
    def __str__(self):
        str = 'FRAME STATS: %s\n' % phyOpEnum[self.phyOperation]
        
        if (4294967295 == self.sfn):
            str += 'System Frame Number: Unknown\n'
        else:
            str += 'System Frame Number: %d\n' % self.sfn
        str += 'PHY Frame Number: %d\n' % self.phyFrameNum

        str += 'TEMPERATURE: adc = 0x%x estimate = %dC\n' % (self.tempAdc, self.tempEst)
        str += 'ANTENNA SELECT: %d\n' % self.antennaSetting
        str += 'RECTANGLE: CAFC = %d - %d, TIME = %d - %d\n' % (self.lowCAFC,
                                                                 self.highCAFC,
                                                                 self.lowTimingOffset,
                                                                 self.highTimingOffset)
        str += 'OSC CAL: 32khz = %d, 26mhz = %d\n' % (self.oscCal32k, self.oscCal26m)

        if self.numLoggingMsgsDropped > 0:
            str += 'DROPPED LOGS: %d\n' % self.numLoggingMsgsDropped
            
        if phyOpEnum[self.phyOperation] == 'FRAME_TRACKING' or \
           phyOpEnum[self.phyOperation] == 'FRAME_TRACKING_FAIL_RECOVERY' or \
           phyOpEnum[self.phyOperation] == 'COLD_ACQU':
            str += 'HIGH RSSI: %.1f\n' % (float(self.rssi_high)/16,)
            str += 'FRAME OFFSET IN SYMBOLS: %u\n' % self.frameDelaySymbols
        else:
            str += 'RSSI = %.1f, low = %.1f, high = %.1f\n' % \
                   (float(self.RSSI)/16, float(self.rssi_low)/16, float(self.rssi_high)/16)
            str += 'AP Metric: %.1f\n' % (float(self.apMetric)/16,)

        if phyOpEnum[self.phyOperation] == 'PREAMBLE_PLUS_DEMOD':
            if self.channel == 0:
                str += 'BROADCAST CHANNEL DEMOD: START PREAMBLE %d NUM SUBSLOTS %d\n' % \
                       (self.subslot, self.numSubslots)
            else:
                str += 'DATA CHANNEL DEMOD: START PREAMBLE %d NUM SUBSLOTS %d SF %d GC 0x%x\n' % \
                       (self.subslot, self.numSubslots, self.lastDchSpreading, self.dchGoldCode)
                
        if not (phyOpEnum[self.phyOperation] == 'FRAME_TRACKING' or \
                phyOpEnum[self.phyOperation] == 'FRAME_TRACKING_FAIL_RECOVERY' or \
                phyOpEnum[self.phyOperation] == 'COLD_ACQU'):
            str += 'FREQ OFFSET: %d\n' % self.freqOffset
            str += 'DESIRED DL SF: %d\n' % self.calcDchSF

        if phyOpEnum[self.phyOperation] == 'BACKGROUND_SCAN':
            str += 'BACKGROUND SCAN CHANNEL %d GOLD CODE 0x%X\n' % \
                   (self.backgroundScanConfig >> 24,
                    (self.backgroundScanConfig & 0xFFFFFF) | 0x1000000)
        else:
            str += 'SERVING AP CHANNEL %d GOLD CODE 0x%X\n' % \
                   (self.servingAPConfig >> 24,
                    (self.servingAPConfig & 0xFFFFFF) | 0x1000000)
            
        str += 'FINGER FAFCS: \t%.5u    %.5u    %.5u    %.5u    %.5u    %.5u    %.5u    %.5u    %.5u    %.5u\n' % self.__makeList(self.fingerFineAFCs)
        str += 'FINGER TIME OFFSET:  \t%.5u    %.5u    %.5u    %.5u    %.5u    %.5u    %.5u    %.5u    %.5u    %.5u\n' % tuple([(i >> 2) for i in self.__makeList(self.fingerTimingOffsetParity)])
        str += 'FINGER TIME PARITY:  \t%.5u    %.5u    %.5u    %.5u    %.5u    %.5u    %.5u    %.5u    %.5u    %.5u\n' % tuple([(i & 0x3) for i in self.__makeList(self.fingerTimingOffsetParity)])
        str += 'FINGER CAFC:  \t%.5d    %.5d    %.5d    %.5d    %.5d    %.5d    %.5d    %.5d    %.5d    %.5d\n' % self.__makeList(self.fingerCAFC)
        str += 'FINGER ENERGY: \t%.5u    %.5u    %.5u    %.5u    %.5u    %.5u    %.5u    %.5u    %.5u    %.5u\n' % tuple(self.__makeList(self.fingerEnergy))
        str += 'FINGER POWER: \t%.5u    %.5u    %.5u    %.5u    %.5u    %.5u    %.5u    %.5u    %.5u    %.5u\n' % self.__makeList(self.fingerPower)

        if not (phyOpEnum[self.phyOperation] == 'FRAME_TRACKING' or \
                phyOpEnum[self.phyOperation] == 'FRAME_TRACKING_FAIL_RECOVERY' or \
                phyOpEnum[self.phyOperation] == 'COLD_ACQU'):
            str += 'HAMMING WEIGHT:  \t%.5d    %.5d    %.5d    %.5d    %.5d    %.5d    %.5d    %.5d    %.5d    %.5d\n' % self.__makeList(self.hammingWeight)
            str += 'WINNING FAFC:  \t%.5d    %.5d    %.5d    %.5d    %.5d    %.5d    %.5d    %.5d    %.5d    %.5d\n' % self.__makeList(self.winningFineAFC)
            str += 'FINE AFC METRIC:  \t%.5d    %.5d    %.5d    %.5d    %.5d    %.5d    %.5d    %.5d    %.5d    %.5d\n' % self.__makeList(self.boostedFineAFCMetric)

        return str

class TX_PROGRAMMED(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('txFreqStride', ctypes.c_int),
        ('txTimeTrackingStride', ctypes.c_int),
        ('freqOffset', ctypes.c_int),
        ('spreading', ctypes.c_ushort),
        ('startingSubslot', ctypes.c_ushort),
        ('digitalTruncation', ctypes.c_ushort),
        ('txVGA', ctypes.c_ushort),
        ('numSubslots', ctypes.c_ushort),
        ('numLoggingMsgsDropped', ctypes.c_ubyte),
        ('pad1', ctypes.c_ubyte),
        ('footer', Footer),
    ]
    def __str__(self):
        str = '+ TX: freq stride %d time stride %d freq offset %d\n' % \
                             (self.txFreqStride, self.txTimeTrackingStride, self.freqOffset)
        str += '+ TX: spreading %d subslot %d num slots %d\n' % \
                             (2 << (self.spreading - 1), self.startingSubslot, self.numSubslots)
        str += '+ TX: vga %d truncation %d\n' % (self.txVGA, self.digitalTruncation)
        
        if self.numLoggingMsgsDropped > 0:
            str += 'WARNING: %d dropped low priority messages\n' % self.numLoggingMsgsDropped

        return str

class UPTIME_STATS_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]



class UPTIME_STATS_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('numWdogResets', ctypes.c_uint),
        ('lastBootWasWatchdog', ctypes.c_uint),
        ('secondsSinceLastBoot', ctypes.c_uint),
        ('footer', Footer),
    ]


class GET_EXCEPTION_BUFFER_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('clearBuffer', ctypes.c_ubyte),
        ('chunk', ctypes.c_ubyte),
        ('reserved2', ctypes.c_ushort),
        ('footer', Footer),
    ]


class GET_EXCEPTION_BUFFER_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('buffer', ctypes.c_ubyte*256),
        ('footer', Footer),
    ]


class SET_SPREADING(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('dlBcastSpreading', ctypes.c_uint),
        ('ulSpreading', ctypes.c_uint),
        ('footer', Footer),
    ]

spreadingEnum = {
    'AUTO' : 0,
    '16' : 4,
    '32' : 5,
    '64' : 6,
    '128' : 7,
    '256' : 8,
    '512' : 9,
    '1024' : 10,
    '2048' : 11,
    '4096' : 12,
    '8192' : 13}


class SET_GOLD_CODES(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('bcastGoldCode', ctypes.c_uint),
        ('dataGoldCode', ctypes.c_uint),
        ('footer', Footer),
    ]


class SET_CHANNEL(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('channelNum', ctypes.c_uint),
        ('footer', Footer),
    ]



class VERSION(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]



class VERSION_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('swRev', ctypes.c_uint),
        ('phyRev', ctypes.c_uint),
        ('footer', Footer),
    ]


class GET_PARAMS(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]



class GET_PARAMS_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('channelBW', ctypes.c_ushort),
        ('channelNum', ctypes.c_ushort),
        ('numNCAccum', ctypes.c_ushort),
        ('rssiMargin', ctypes.c_short),
        ('demodChannel', ctypes.c_ushort),
        ('bcastSlot', ctypes.c_ushort),
        ('dataSubslot', ctypes.c_ushort),
        ('pad', ctypes.c_ushort),
        ('bcastGoldCode', ctypes.c_uint),
        ('dlDataGoldCode', ctypes.c_uint),
        ('bcastSpreading', ctypes.c_ushort),
        ('dlDataSpreading', ctypes.c_ushort),
        ('ulSpreading', ctypes.c_ushort),
        ('systemState', ctypes.c_ushort),
        ('cid', ctypes.c_ushort),
        ('listenInterval', ctypes.c_byte),
        ('slotInterval', ctypes.c_byte),
        ('nodeId', ctypes.c_uint),
        ('maxTxPwrLimit', ctypes.c_short),
        ('maxTxPwrLimitHeadRoom', ctypes.c_short),
        ('footer', Footer),
    ]

systemStateEnum = {
    'NIL' : 0,
    'STARTUP' : 1,
    'IDLE' : 2,
    'SCANNING' : 3,
    'TRACK' : 4,
    'JOINED' : 5}

def flash_config_cmp(self, other):
    if not other:
        return 1
    self_buf = buffer(self)
    other_buf = buffer(other)
    if len(self_buf) < len(other_buf):
        return -1
    if len(self_buf) > len(other_buf):
        return 1
    for i in range(0, len(self_buf)):
        if self_buf[i] < other_buf[i]:
            return -1
        if self_buf[i] > other_buf[i]:
            return 1
    # They must be the same.
    return 0

class FlashConfigurationV3(ucl_nhp_msg.Structure):
    _pack_ = 1
    _fields_ = [
        ('version', ctypes.c_uint),
        ('bcastGoldCode', ctypes.c_uint*NUM_SCAN_SYSTEMS_V3),
        ('channel', ctypes.c_ubyte*NUM_SCAN_SYSTEMS_V3),
        ('tcxoFreq', ctypes.c_uint),
        ('countryCode', ctypes.c_ushort),
        ('sysSelMinSleepTimer', ctypes.c_ushort),
        ('fieldTestNumPdusPerFrame', ctypes.c_ushort),
        ('fieldTestNumFramePeriod', ctypes.c_ushort),
        ('fieldTestUlRssiMargin', ctypes.c_ubyte),
        ('autorun', ctypes.c_ubyte),
        ('operatingMode', ctypes.c_ubyte),
        ('dlBcastSpreading', ctypes.c_ubyte),
        ('maxTxPwrLimit', ctypes.c_ubyte),
        ('joinType', ctypes.c_ubyte),
        ('joinBackoffType', ctypes.c_ubyte),
        ('otaDwnldNodeType_InitSeq', ctypes.c_ubyte),
        ('sysSelMaxSleepTimer', ctypes.c_uint),
        ('sysSelImmediateJoinThreshold', ctypes.c_short),
        ('sysSelMaxFreqOptimizedPasses', ctypes.c_ubyte),
        ('antennaDiversityEnabled', ctypes.c_ubyte),
    ]
    __cmp__ = flash_config_cmp

class FlashConfigurationV4(ucl_nhp_msg.Structure):
    _pack_ = 1
    _fields_ = [
        ('version', ctypes.c_uint),
        ('countryCode', ctypes.c_ushort),
        ('sysSelMinSleepTimer', ctypes.c_ushort),
        ('fieldTestNumPdusPerFrame', ctypes.c_ushort),
        ('fieldTestNumFramePeriod', ctypes.c_ushort),
        ('fieldTestUlRssiMargin', ctypes.c_ubyte),
        ('autorun', ctypes.c_ubyte),
        ('operatingMode', ctypes.c_ubyte),
        ('dlBcastSpreading', ctypes.c_ubyte),
        ('maxTxPwrLimit', ctypes.c_ubyte),
        ('joinType', ctypes.c_ubyte),
        ('joinBackoffType', ctypes.c_ubyte),
        ('otaDwnldNodeType_InitSeq', ctypes.c_ubyte),
        ('sysSelMaxSleepTimer', ctypes.c_uint),
        ('sysSelMaxFreqOptimizedPasses', ctypes.c_ubyte),
        ('batteryNodeRescanUIs', ctypes.c_ubyte),
        ('highAbsAPProperJoinThresholdDb', ctypes.c_ubyte), # unused in 2.1
        ('lowAbsAPProperJoinThresholdDb', ctypes.c_ubyte),  # unused in 2.1
        ('antennaDiversityEnabled', ctypes.c_ubyte),
        ('txDutyCyclePercent', ctypes.c_ubyte),
        ('maxDelayDuringOutage', ctypes.c_ubyte),
        ('padding', ctypes.c_ubyte),
    ]
    __cmp__ = flash_config_cmp

class FlashConfiguration(ucl_nhp_msg.Union):
    _pack_ = 1
    _fields_ = [
        ('v3', FlashConfigurationV3),
        ('v4', FlashConfigurationV4),
    ]


class READ_FLASH_CONF(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]


class READ_FLASH_CONF_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('configData', FlashConfiguration),
        ('footer', Footer),
    ]

class WRITE_FLASH_CONF(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('configData', FlashConfiguration),
        ('footer', Footer),
    ]

class APList(ucl_nhp_msg.Structure):
    _pack_ = 1
    _fields_ = [
        ('apList', ctypes.c_uint*NUM_SCAN_SYSTEMS_V4),
    ]
    
class READ_FLASH_AP_LIST_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]

class READ_FLASH_AP_LIST_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('apList', APList),
        ('footer', Footer),
    ]

class WRITE_FLASH_AP_LIST_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('apList', APList),
        ('footer', Footer),
    ]
    
class BEGIN_SW_UPGR(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('numChunks', ctypes.c_uint),
        ('checksum', ctypes.c_uint),
        ('footer', Footer),
    ]


class BEGIN_SW_UPGR_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('result', ctypes.c_uint),
        ('footer', Footer),
    ]


class SW_UPGR2_BEGIN_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('numChunks', ctypes.c_ushort),
        ('imageType', ctypes.c_ushort),
        ('checksum', ctypes.c_uint),
        ('footer', Footer),
    ]


class SW_UPGR2_BEGIN_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('result', ctypes.c_uint),
        ('footer', Footer),
    ]


class SW_UPGR2_CHUNK_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('num', ctypes.c_uint),
        ('checksum', ctypes.c_uint),
        ('chunk', ctypes.c_ubyte*256),
        ('footer', Footer),
    ]


class SW_UPGR2_CHUNK_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('result', ctypes.c_uint),
        ('footer', Footer),
    ]


class SW_UPGR2_END_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]


class SW_UPGR2_END_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('result', ctypes.c_uint),
        ('footer', Footer),
    ]


class ACK(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]


class TIME_SYNC_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]



class TIME_SYNC_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('time_of_day_whole', ctypes.c_uint),
        ('time_of_day_frac', ctypes.c_uint),
        ('year', ctypes.c_ushort),
        ('month', ctypes.c_ubyte),
        ('day', ctypes.c_ubyte),
        ('valid', ctypes.c_ubyte),
        ('rsv1', ctypes.c_ubyte),
        ('rsv2', ctypes.c_ushort),
        ('footer', Footer),
    ]

    def __str__(self):
        hour = self.time_of_day_whole / (60 * 60)
        _min = (self.time_of_day_whole - hour * 60 * 60) / (60)
        sec = self.time_of_day_whole - hour * 60 *60 - _min * 60 + self.time_of_day_frac / float(2**32 - 1)
        year = self.year
        month = self.month
        day = self.day

        if self.valid:
            now = "%04d-%02d-%02d %02d:%02d:%06.3f" % (year, month, day, hour, _min, sec)
        else:
            now = "time sync unavailable"
        
        return 'TIME SYNC: %s' % now
        
class POKE(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('address', ctypes.c_uint),
        ('data', ctypes.c_uint),
        ('footer', Footer),
    ]


class POKE_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]


class PEEK(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('address', ctypes.c_uint),
        ('footer', Footer),
    ]


class PEEK_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('res', ctypes.c_uint),
        ('footer', Footer),
    ]


class RF_SPI_POKE(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('arg1', ctypes.c_uint),
        ('arg2', ctypes.c_uint),
        ('footer', Footer),
    ]


class RF_SPI_POKE_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]


class AFE_SPI_POKE(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('arg1', ctypes.c_uint),
        ('arg2', ctypes.c_uint),
        ('footer', Footer),
    ]


class AFE_SPI_POKE_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]


class AFE_SPI_PEEK(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('arg', ctypes.c_uint),
        ('footer', Footer),
    ]


class AFE_SPI_PEEK_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('arg2', ctypes.c_uint),
        ('footer', Footer),
    ]


class AFE_POKE(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('address', ctypes.c_uint),
        ('data', ctypes.c_uint),
        ('footer', Footer),
    ]



class AFE_POKE_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]


class AFE_PEEK(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('address', ctypes.c_uint),
        ('footer', Footer),
    ]


class AFE_PEEK_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('data', ctypes.c_uint),
        ('footer', Footer),
    ]


class TOGGLE_TOUT(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('toggleCount', ctypes.c_uint),
        ('footer', Footer),
    ]


class TOGGLE_TOUT_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]

class SET_AFE_MODE_REQ(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('mode', ctypes.c_uint),
        ('footer', Footer),
    ]

class SET_AFE_MODE_RSP(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('footer', Footer),
    ]

class SET_BW(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('BW', ctypes.c_uint),
        ('footer', Footer),
    ]

bandwidthEnum = {
    'BW_2000_KHZ' : 0,
    'BW_1000_KHZ' : 1,
    'BW_500_KHZ' : 2}


class SET_SCAN_RANGE(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('scanLowFreqHz', ctypes.c_short),
        ('scanHighFreqHz', ctypes.c_short),
        ('footer', Footer),
    ]


class SET_NC_ACCUM(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('num_nc_accum', ctypes.c_uint),
        ('footer', Footer),
    ]


class SET_UL_MARGIN(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('ulMarginInDb', ctypes.c_uint),
        ('footer', Footer),
    ]

phyTestModeEnum = {
    'DISABLED' : 0,
    'CLASSIC' : 1,
    'WITH_SYSTEM_SELECTION' : 2 }

class SET_PHY_TEST_MODE(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('mode', ctypes.c_uint),
        ('enableBackgroundScans', ctypes.c_uint),
        ('footer', Footer),
    ]


class RX_TEST_SET_DEMOD_PARAMS(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('channel', ctypes.c_uint),
        ('startingSubslotNumber', ctypes.c_uint),
        ('numSubslots', ctypes.c_uint),
        ('dataSpreading', ctypes.c_uint),
        ('footer', Footer),
    ]


demodChannelEnum = {
    'BROADCAST' : 0,
    'DATA' : 1 }


class TEST_RXDATA(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('frame_87_64', ctypes.c_uint),
        ('frame_63_32', ctypes.c_uint),
        ('frame_31_0', ctypes.c_uint),
        ('footer', Footer),
    ]


class TEST_TXDATA(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('high', ctypes.c_uint),
        ('low', ctypes.c_uint),
        ('footer', Footer),
    ]


class TX_TEST_MODE_CLEAR_PAYLOADS(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]


class TX_TEST_MODE_ADD_PAYLOAD(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('frame_87_64', ctypes.c_uint),
        ('frame_63_32', ctypes.c_uint),
        ('frame_31_0', ctypes.c_uint),
        ('footer', Footer),
    ]


class TX_TEST_MODE_SET_START_SUBSLOT(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('arg', ctypes.c_uint),
        ('footer', Footer),
    ]


class ADC_SAMPLE_READ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]


class ADC_SAMPLE_READ_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('buff', ctypes.c_uint*125),
        ('footer', Footer),
    ]


class ADC_SAMPLE_BURST_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('mode', ctypes.c_uint), # 0 = 9-bit samples, 1 = 1-bit samples
        ('cnt', ctypes.c_uint), # Minimum number of 9-bit samples to send
        ('offset', ctypes.c_uint), # number of samples to skip
        ('footer', Footer),
    ]


class ADC_SAMPLE_BURST_IND(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('buff', ctypes.c_uint*125),
        ('footer', Footer),
    ]


class SET_SLEEP_TIME_FRAMES(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('arg', ctypes.c_uint),
        ('footer', Footer),
    ]


class FORCE_AFE_RADIO_ACTIVE(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('arg', ctypes.c_uint),
        ('footer', Footer),
    ]


class GET_AUXADC_VALS(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]


class GET_AUXADC_VALS_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('RadioTemperature', ctypes.c_ushort),
        ('VBatt', ctypes.c_ushort),
        ('footer', Footer),
    ]


class AGC_DIAG(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('segment', ctypes.c_uint),
        ('values', ctypes.c_uint*64),
        ('footer', Footer),
    ]


class SET_TX_AP_ID(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('systemId', ctypes.c_uint),
        ('footer', Footer),
    ]


class SET_LOWEST_POWER_STATE(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('state', ctypes.c_uint),
        ('footer', Footer),
    ]


class SET_TX_PWR_LIMIT(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('maxTxPwrLimit', ctypes.c_uint),
        ('footer', Footer),
    ]


class GET_TX_AP_ID(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]


class GET_TX_AP_ID_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('systemId', ctypes.c_uint),
        ('footer', Footer),
    ]


class SET_AUX_DAC_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('value', ctypes.c_uint),
        ('enabled', ctypes.c_uint),
        ('footer', Footer),
    ]


class SET_AUX_DAC_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]


class ARB_MEM_ACC_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('address', ctypes.c_uint),
        ('value', ctypes.c_uint),
        ('operation', ctypes.c_uint),
        ('footer', Footer),
    ]


class ARB_MEM_ACC_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('value', ctypes.c_uint),
        ('footer', Footer),
    ]


class FlashCalibrationV2(ucl_nhp_msg.Structure):
    _pack_ = 1
    _fields_ = [
        ('version', ctypes.c_uint),
        ('hardware_version', ctypes.c_uint),
        ('serial_num', ctypes.c_uint),
        ('node_id', ctypes.c_uint),
        ('k_phy', ctypes.c_uint),
        ('maxTxVGALow', ctypes.c_uint),
        ('maxTxVGAMid', ctypes.c_uint),
        ('maxTxVGAHigh', ctypes.c_uint),
        ('maxTxVGAOutputPwr', ctypes.c_uint),
        ('max_tx_pwr_low_freq', ctypes.c_uint),
        ('max_tx_pwr_mid_freq', ctypes.c_uint),
        ('max_tx_pwr_high_freq', ctypes.c_uint),
        ('tx_vga35_pwr_low_freq', ctypes.c_uint),
        ('tx_vga35_pwr_mid_freq', ctypes.c_uint),
        ('tx_vga35_pwr_high_freq', ctypes.c_uint),
        ('lna_high_gain_low_freq', ctypes.c_uint),
        ('lna_mid_gain_low_freq', ctypes.c_uint),
        ('lna_low_gain_low_freq', ctypes.c_uint),
        ('lna_high_gain_mid_freq', ctypes.c_uint),
        ('lna_mid_gain_mid_freq', ctypes.c_uint),
        ('lna_low_gain_mid_freq', ctypes.c_uint),
        ('lna_high_gain_high_freq', ctypes.c_uint),
        ('lna_mid_gain_high_freq', ctypes.c_uint),
        ('lna_low_gain_high_freq', ctypes.c_uint),
        ('noise_pwr_1mhz', ctypes.c_uint),
        ('i_offset', ctypes.c_uint),
        ('q_offset', ctypes.c_uint),
        ('osc_26mhz', ctypes.c_uint),
        ('osc_32khz', ctypes.c_uint),
        ('pa_temp_mcomp', ctypes.c_uint),
        ('pa_temp_bcomp', ctypes.c_uint),
        ('aux_a2d_temp_m', ctypes.c_uint),
        ('aux_a2d_temp_b', ctypes.c_uint),
        ('t_cal', ctypes.c_uint),
        ('aux_a2d_chan1_m', ctypes.c_uint),
        ('aux_a2d_chan1_b', ctypes.c_uint),
        ('aux_a2d_chan2_m', ctypes.c_uint),
        ('aux_a2d_chan2_b', ctypes.c_uint),
    ]

class FlashCalibrationV3(ucl_nhp_msg.Structure):
    _pack_ = 1
    _fields_ = FlashCalibrationV2._fields_ + [
        ('temperature_pt', ctypes.c_short * 10),
        ('temp_power_diff_q4', ctypes.c_short * 10),
        ('tx_vga_slope_q10', ctypes.c_short),
        ('pa_dac_codeword', ctypes.c_ushort),
    ]

class FlashCalibrationV4(ucl_nhp_msg.Structure):
    _pack_ = 1
    _fields_ = FlashCalibrationV2._fields_ + [
        ('temperature_pt', ctypes.c_short * 10),
        ('temp_power_diff_q4', ctypes.c_short * 10),
        ('tx_vga_slope_q10', ctypes.c_short),
        ('cal_temp_rx', ctypes.c_short),
        ('rssi_temp_slope_q10', ctypes.c_short),
        ('unused_alignment_pad', ctypes.c_short),
    ]

class FlashCalibration(ucl_nhp_msg.Union):
    _pack_ = 1
    _fields_ = [
        ('v2', FlashCalibrationV2),
        ('v3', FlashCalibrationV3),
        ('v4', FlashCalibrationV4),
    ]

    def __cmp__(self, other):
        if not other:
            return 1
        self_buf = buffer(self)
        other_buf = buffer(other)
        if len(self_buf) < len(other_buf):
            return -1
        if len(self_buf) > len(other_buf):
            return 1
        for i in range(0, len(self_buf)):
            if self_buf[i] < other_buf[i]:
                return -1
            if self_buf[i] > other_buf[i]:
                return 1
        # They must be the same.
        return 0


class READ_FLASH_CAL(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]


class READ_FLASH_CAL_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('calData', FlashCalibration),
        ('footer', Footer),
    ]


class WRITE_FLASH_CAL(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('secretCode', ctypes.c_uint),
        ('calData', FlashCalibration),
        ('footer', Footer),
    ]


class ERROR_IND(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('errorCode', ctypes.c_uint),
        ('arg1', ctypes.c_uint),
        ('arg2', ctypes.c_uint),
        ('arg3', ctypes.c_uint),
        ('footer', Footer),
    ]

class AFE_TESTMODE(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('mode', ctypes.c_uint),
        ('footer', Footer),
    ]


class AFE_TESTMODE_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('mode', ctypes.c_uint),
        ('footer', Footer),
    ]


class AUX_ADC_READ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('bitmap', ctypes.c_uint),
        ('footer', Footer),
    ]


class AUX_ADC_READ_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('bitmap', ctypes.c_uint),
        ('vdd_2', ctypes.c_uint),
        ('temperature', ctypes.c_uint),
        ('rssi', ctypes.c_uint),
        ('vbatt', ctypes.c_uint),
        ('padetect', ctypes.c_uint),
        ('footer', Footer),
    ]


class AUX_ADC_READ_V2(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('bitmap', ctypes.c_uint),
        ('footer', Footer),
    ]


class AUX_ADC_READ_V2_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('bitmap', ctypes.c_uint),
        ('vdd_2', ctypes.c_uint),
        ('temperature', ctypes.c_uint),
        ('rssi', ctypes.c_uint),
        ('vbatt', ctypes.c_uint),
        ('padetect', ctypes.c_uint),
        ('auxadccal', ctypes.c_uint),
        ('vref', ctypes.c_uint),
        ('footer', Footer),
    ]


class TEST_PIN_POKE(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('setMask', ctypes.c_uint32),
        ('clearMask', ctypes.c_uint32),
        ('footer', Footer),
    ]
testPinBits = {
    'TOUT'          : 1 << 0,
    'ANT_SEL'       : 1 << 1,
    'USTATUS'       : 1 << 2,
    }


class TEST_PIN_POKE_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]


class TEST_PIN_PEEK(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('peekMask', ctypes.c_uint32),
        ('footer', Footer),
    ]


class TEST_PIN_PEEK_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('peekedMask', ctypes.c_uint32),
        ('setMask', ctypes.c_uint32),
        ('footer', Footer),
    ]


class PHY_COMP_CTRL(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('ctrlFlag', ctypes.c_uint),
        ('footer', Footer),
    ]


class PHY_COMP_CTRL_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('ctrlFlag', ctypes.c_uint),
        ('footer', Footer),
    ]


class MacStatsIndCommon_(ucl_nhp_msg.Structure):
    _pack_ = 1
    _fields_ = [
        ('numLoggingMsgsDropped', ctypes.c_ubyte),
        ('pad1', ctypes.c_ubyte),
        ('pad2', ctypes.c_ushort),
        ('sfn', ctypes.c_uint),
    ]


class PhyRegsPayloadType(ucl_nhp_msg.Structure):
    _pack_ = 1
    _fields_ = [
        ('frame_87_64', ctypes.c_uint),
        ('frame_63_32', ctypes.c_uint),
        ('frame_31_0', ctypes.c_uint),
    ]


class MacStatsIndPduPayload(ucl_nhp_msg.Structure):
    _pack_ = 1
    _fields_ = [
        ('pad', ctypes.c_ushort),
        ('typeOfPdu', ctypes.c_int),
        ('numPdus', ctypes.c_ubyte),
        ('pdus', PhyRegsPayloadType*40),
    ]


"""
class MAC_STATS_IND_PDUS(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('common', MacStatsIndCommon),
        ('payload', MacStatsIndPduPayload),
        ('footer', Footer),
    ]


class MAC_STATS_IND_SDU(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('common', MacStatsIndCommon),
        ('sdu', MacStatsIndPduPayload),
        ('footer', Footer),
    ]
"""


class SET_DL_RANDOM_PDU_DROP_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('dropMaxPercentage', ctypes.c_uint32),
        ('footer', Footer),
    ]

class SET_DL_RANDOM_PDU_DROP_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]

class GET_DL_RANDOM_PDU_DROP_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]

class GET_DL_RANDOM_PDU_DROP_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('dropMaxPercentage', ctypes.c_uint32),
        ('footer', Footer),
    ]

class SEC_TEST_HOOK_REQ(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),

        ('newJoinCounter',         ctypes.c_uint),
        ('newRootKeyCounter',      ctypes.c_uint),
        ('rsvd1',                  ctypes.c_uint),
        ('newDlRdSduCounter',      ctypes.c_uint),
        ('newUlSduCounter',        ctypes.c_uint),
        ('rsvd2',                  ctypes.c_uint),

        ('newJoinCounterValid',    ctypes.c_ubyte),
        ('newRootKeyCounterValid', ctypes.c_ubyte),
        ('rsvd3',                  ctypes.c_ubyte),
        ('newDlRdSduCounterValid', ctypes.c_ubyte),
        ('newUlSduCounterValid',   ctypes.c_ubyte),
        ('rsvd4',                  ctypes.c_ubyte*3),

        ('footer', Footer),
    ]

class FORCE_HANDOVER(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('apFlashIndex', ctypes.c_uint32),
        ('bchGoldCode', ctypes.c_uint32),
        ('channel', ctypes.c_ubyte),
        ('antennaSetting', ctypes.c_ubyte),
        ('pad', ctypes.c_ubyte*2),
        ('footer', Footer),
    ]

class GET_FLASH_IDENT_REQ(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('footer', Footer),
    ]
    
class GET_FLASH_IDENT_RSP(Message):
    _pack_ = 1
    _fields_ = [ 
        ('header', Header),
        ('ident', ctypes.c_ubyte*5),
        ('pad', ctypes.c_ubyte*3),
        ('footer', Footer),
    ]
    
hostIfDataSink = ctypes.CFUNCTYPE(None, ctypes.POINTER(ctypes.c_ubyte), ctypes.c_ubyte)

def phy_ctrl_set_state_msg(enable):
    return SYSTEM_SET_STATE(phy_enable =  enable and 1 or 0)


def get_state_msg():
    return GET_STATE()
    

def tx_sdu_msg(bytes, host_tag=0, flags=0):
    """Generates a TX SDU message from an array of bytes."""
    #Make sure padding is added such that the length of the message payload will be a multiple of 4 bytes
    if(len(bytes) < 4):
        pad = 4 - len(bytes)
    else:
        pad = 4 - (len(bytes) % 4) 

    if(pad == 4):
        pad = 0
        
   # print "pad = %d" % pad
   # print "bytes length before: %d" % len(bytes)
    
    for i in range(pad):
        temp = (0,)
        bytes = bytes + temp
   
   # print "bytes length after: %d" % len(bytes)
    
    return make_txsdu(len(bytes), header = (16+len(bytes), types.TXSDU), size = len(bytes) - pad, host_tag = host_tag, flags = flags, pad = 0, payload = tuple(bytes), footer = 0xA5A5F0F0)


def connect_msg():
    return CONNECT(connected=1)


def get_msg_for_bytes(bytes):
    """Inspects a list of bytes, returns a message object of the correct
    type if possible (None otherwise)."""

    hdr = Header()
    hdr.set_bytes(bytes)
    typ = hdr.msgType
    length = hdr.msgLen

    for k,v in types.items():
        if v == typ:
            try:
                _class = eval(k)
                msg = _class()
                msg.set_bytes(bytes)
                return msg
            except:

                if typ == types.MAC_STATS_IND_PDUS:
                    msg = genMacStatsIndPdus(40)()
                    msg.set_bytes(bytes)
                    msg = genMacStatsIndPdus(msg.payload.numPdus)()
                elif typ == types.MAC_STATS_IND_SDU:
                    msg = genMacStatsIndSdu(MAX_WITH_SECURITY_SDU_SIZE)()
                    msg.set_bytes(bytes)
                    msg = genMacStatsIndSdu(msg.payload.size)()
                elif typ == types.RXSDU:
                    msg = genRxSdu(MAX_SDU_SIZE)()
                    msg.set_bytes(bytes)
                    msg = genRxSdu(msg.size)()
                elif typ == types.TXSDU:
                    msg = genTxSdu(MAX_SDU_SIZE)()
                    msg.set_bytes(bytes)
                    msg = genTxSdu(msg.size)()
                else:
                    return None

                msg.set_bytes(bytes)
                return msg

def get_msg_for_three_tuple(len, type, body):
    """This function takes the output from ser_ctrl_back.getMsg() and reconstructs the message call to get_msg_for_bytes()"""
    string = struct.pack('HH', len, type) + body
    bytes = map(ord, string)
    return get_msg_for_bytes(bytes)
                

def get_msg_name_for_id(id):
    for k,v in types.items():
        if v == id:
            return k


HOST_MSG_DIR_HOST_TO_NODE = 0x4000
HOST_MSG_DIR_NODE_TO_HOST = 0x0000
HOST_MSG_ONRAMP           = 0x8000

types = util.Enum(
    # from host_msg.h
    """
    /** From Host to Node: enables frame stats that are sent by Node */
    HOST_MSG_TYPE_START_FRAME_STATS   = HOST_MSG_DIR_HOST_TO_NODE | 0x00,
    /** From Host to Node: disables frame stats that are sent by Node */
    HOST_MSG_TYPE_STOP_FRAME_STATS    = HOST_MSG_DIR_HOST_TO_NODE | 0x01,
    /** From Node to Host: contains statistics for debug use */
    HOST_MSG_TYPE_FRAME_STATS         = HOST_MSG_DIR_NODE_TO_HOST | 0x02,
    /** Informs Host that a TX is programmed to be sent over the air */
    HOST_MSG_TYPE_TX_PROGRAMMED       = HOST_MSG_DIR_NODE_TO_HOST | 0x03,
    /** From Host to Node: uptime message request */
    HOST_MSG_TYPE_UPTIME_STATS_REQ    = HOST_MSG_DIR_HOST_TO_NODE | 0x04,
    /** From Node to Host: uptime message request response */
    HOST_MSG_TYPE_UPTIME_STATS_RSP    = HOST_MSG_DIR_NODE_TO_HOST | 0x04,
    /** From Host to Node: exception buffer message request */
    HOST_MSG_TYPE_GET_EXCEPTION_BUFFER_REQ    = HOST_MSG_DIR_HOST_TO_NODE | 0x05,
    /** From Node to Host: exception buffer message request response */
    HOST_MSG_TYPE_GET_EXCEPTION_BUFFER_RSP    = HOST_MSG_DIR_NODE_TO_HOST | 0x05,

    /* configuration messages: */
    /** Host to Node: turn Node Over-The-Air interface On or Off */
    HOST_MSG_TYPE_SYSTEM_SET_STATE    = HOST_MSG_DIR_HOST_TO_NODE | 0x10,
    /** Node to Host: current status of Node (off, scanning, or tracking) */
    HOST_MSG_TYPE_SYSTEM_STATE        = HOST_MSG_DIR_NODE_TO_HOST | 0x11,
    /** Host to Node: set Broadcast Spreading Factor */
    HOST_MSG_TYPE_SET_SPREADING       = HOST_MSG_DIR_HOST_TO_NODE | 0x12,
    /** Host to Node: set Broadcast Gold Code */
    HOST_MSG_TYPE_SET_GOLD_CODES      = HOST_MSG_DIR_HOST_TO_NODE | 0x13,
    /** Host to Node: set Center Frequency of channel that Node tracks to */
    HOST_MSG_TYPE_SET_CHANNEL         = HOST_MSG_DIR_HOST_TO_NODE | 0x14,
    /** Host to Node: request Software and Hardware version */
    HOST_MSG_TYPE_VERSION             = HOST_MSG_DIR_HOST_TO_NODE | 0x15,
    /** Node to Host: contains Software and Hardware version */
    HOST_MSG_TYPE_VERSION_RSP         = HOST_MSG_DIR_NODE_TO_HOST | 0x15,
    /** Host to Node: request configuration parameters */
    HOST_MSG_TYPE_GET_PARAMS          = HOST_MSG_DIR_HOST_TO_NODE | 0x16,
    /** Node to Host: contains configuration parameters */
    HOST_MSG_TYPE_GET_PARAMS_RSP      = HOST_MSG_DIR_NODE_TO_HOST | 0x16,
    /** Host to Node: request flash configuration */
    HOST_MSG_TYPE_READ_FLASH_CONF     = HOST_MSG_DIR_HOST_TO_NODE | 0x17,
    /** Node to Host: contains flash configuration */
    HOST_MSG_TYPE_READ_FLASH_CONF_RSP = HOST_MSG_DIR_NODE_TO_HOST | 0x17,
    /** Host to Node: specifies flash configuration to be programmed into flash */
    HOST_MSG_TYPE_WRITE_FLASH_CONF    = HOST_MSG_DIR_HOST_TO_NODE | 0x18,
    /** Host to Node: State query. */
    HOST_MSG_TYPE_GET_STATE           = HOST_MSG_DIR_HOST_TO_NODE | 0x19,
    /** Node to Host: State response. */
    HOST_MSG_TYPE_GET_STATE_RSP       = HOST_MSG_DIR_NODE_TO_HOST | 0x19,
    /** Host to Node: State query. */
    HOST_MSG_TYPE_BEGIN_SW_UPGR       = HOST_MSG_DIR_HOST_TO_NODE | 0x1A,
    /** Node to Host: State response. */
    HOST_MSG_TYPE_BEGIN_SW_UPGR_RSP   = HOST_MSG_DIR_NODE_TO_HOST | 0x1A,
    /** Node to Host: OTA diag indication. */
    HOST_MSG_TYPE_OTA_DIAG_IND        = HOST_MSG_DIR_NODE_TO_HOST | 0x1B,
    /** Host to Node: provision keys request. */
    HOST_MSG_TYPE_PROVISION_KEYS_REQ  = HOST_MSG_DIR_HOST_TO_NODE | 0x1C,
    /** Node to Host: provision keys response. */
    HOST_MSG_TYPE_PROVISION_KEYS_RSP  = HOST_MSG_DIR_NODE_TO_HOST | 0x1C,
    /** Host to Node: begin SW upgrade. */
    HOST_MSG_TYPE_SW_UPGR2_BEGIN_REQ  = HOST_MSG_DIR_HOST_TO_NODE | 0x1D,
    /** Node to Host: begin SW upgrade response. */
    HOST_MSG_TYPE_SW_UPGR2_BEGIN_RSP  = HOST_MSG_DIR_NODE_TO_HOST | 0x1D,
    /** Host to Node: chunk for a SW upgrade. */
    HOST_MSG_TYPE_SW_UPGR2_CHUNK_REQ  = HOST_MSG_DIR_HOST_TO_NODE | 0x1E,
    /** Node to Host: chunk for a SW upgrade response. */
    HOST_MSG_TYPE_SW_UPGR2_CHUNK_RSP  = HOST_MSG_DIR_NODE_TO_HOST | 0x1E,
    /** Host to Node: end SW upgrade. */
    HOST_MSG_TYPE_SW_UPGR2_END_REQ    = HOST_MSG_DIR_HOST_TO_NODE | 0x1F,
    /** Node to Host: end SW upgrade response. */
    HOST_MSG_TYPE_SW_UPGR2_END_RSP    = HOST_MSG_DIR_NODE_TO_HOST | 0x1F,



    /* user data messages: */
    /** Host to Node: A MAC-bound (uplink) SDU. */
    HOST_MSG_TYPE_TXSDU               = HOST_MSG_DIR_HOST_TO_NODE | 0x20,
    /** Node to Host: tx feedback messages */
    HOST_MSG_TYPE_TXSDU_RSP           = HOST_MSG_DIR_NODE_TO_HOST | 0x20,
    /** Node to Host: contains success/failure information about SDU transmission */
    HOST_MSG_TYPE_TXSDU_RESULT        = HOST_MSG_DIR_NODE_TO_HOST | 0x21,
    /** Node to Host: A host-bound (downlink) SDU. */
    HOST_MSG_TYPE_RXSDU               = HOST_MSG_DIR_NODE_TO_HOST | 0x22,
    /** Host to Node: Requests all queued uplink SDU to be dropped. */
    HOST_MSG_TYPE_FLUSH_TXSDU_QUEUE     = HOST_MSG_DIR_HOST_TO_NODE | 0x23,
    /** Node to Host: Flush TXSDU queue response. */
    HOST_MSG_TYPE_FLUSH_TXSDU_QUEUE_RSP = HOST_MSG_DIR_NODE_TO_HOST | 0x23,
    /** Host to Node: A MAC-bound (uplink) Best Effort Unauthenticated PDU. */
    HOST_MSG_TYPE_TX_BE_PDU           = HOST_MSG_DIR_HOST_TO_NODE | 0x24,

    /* common messages: */
    /** Node to Host: ack sent for every Host to Node msg */
    HOST_MSG_TYPE_ACK                 = HOST_MSG_DIR_NODE_TO_HOST | 0x30,
    /** Node to Host: Error indication */
    HOST_MSG_TYPE_ERROR_IND           = HOST_MSG_DIR_NODE_TO_HOST | 0x31,
    /** Host to node: enables node to host messages */
    HOST_MSG_TYPE_CONNECT             = HOST_MSG_DIR_HOST_TO_NODE | 0x32,

    /** Host to node: request time synchronization */
    HOST_MSG_TYPE_TIME_SYNC_REQ       = HOST_MSG_DIR_HOST_TO_NODE | 0x33,
    /** Node to host: time synchronization response */
    HOST_MSG_TYPE_TIME_SYNC_RSP       = HOST_MSG_DIR_NODE_TO_HOST | 0x33,

    /** Host to node: request set pre-update-interval notification */
    HOST_MSG_TYPE_SET_PRE_UPDATE_NOTIFICATION_REQ       = HOST_MSG_DIR_HOST_TO_NODE | 0x34,
    /** Node to host: set pre-update-interval notification response */
    HOST_MSG_TYPE_SET_PRE_UPDATE_NOTIFICATION_RSP       = HOST_MSG_DIR_NODE_TO_HOST | 0x34,
    /** Node to host: pre-update-interval notification indication */
    HOST_MSG_TYPE_PRE_UPDATE_NOTIFICATION_IND       = HOST_MSG_DIR_NODE_TO_HOST | 0x35,
    /** Host to node: request set host metadata */
    HOST_MSG_TYPE_SET_HOST_METADATA_REQ = HOST_MSG_DIR_HOST_TO_NODE | 0x36,

    /** Host to node: How long until next update interval? */
    HOST_MSG_TYPE_TIME_UNTIL_UPDATE_REQ       = HOST_MSG_DIR_HOST_TO_NODE | 0x37,
    /** Node to host: Seconds until next update */
    HOST_MSG_TYPE_TIME_UNTIL_UPDATE_RSP       = HOST_MSG_DIR_NODE_TO_HOST | 0x37,

    /* Network blackout related messages */
    /** Node to host: indication containing time to blackout period start */
    HOST_MSG_TYPE_BLACKOUT_START_IND  = HOST_MSG_DIR_NODE_TO_HOST | 0x40,
    /** Node to host: indication of blackout period end */
    HOST_MSG_TYPE_BLACKOUT_END_IND    = HOST_MSG_DIR_NODE_TO_HOST | 0x41,

    /* Messages involving broadcast images for the host (i.e. host upgrade OTA) */
    /** Node to host: broadcast starting indication */
    HOST_MSG_TYPE_BROADCAST_START_IND = HOST_MSG_DIR_NODE_TO_HOST | 0x42,
    /** Host to node: decides whether this image should be received */
    HOST_MSG_TYPE_BROADCAST_START_CNF = HOST_MSG_DIR_HOST_TO_NODE | 0x42,
    /** Node to host: image is received, available locally */
    HOST_MSG_TYPE_BROADCAST_END_IND   = HOST_MSG_DIR_NODE_TO_HOST | 0x43,
    /** Host to node: request image chunk */
    HOST_MSG_TYPE_BROADCAST_DATA_REQ  = HOST_MSG_DIR_HOST_TO_NODE | 0x44,
    /** Node to host: transfer image chunk to host */
    HOST_MSG_TYPE_BROADCAST_DATA_RSP  = HOST_MSG_DIR_NODE_TO_HOST | 0x44,

    /* Messages around enode software update */
    /** Node to host: node starting upgrade */
    HOST_MSG_TYPE_NODE_SW_UPGRADE_IND = HOST_MSG_DIR_NODE_TO_HOST | 0x45,
    /** Host to node: confirm node starting upgrade */
    HOST_MSG_TYPE_NODE_SW_UPGRADE_CNF = HOST_MSG_DIR_HOST_TO_NODE | 0x45,

    /** Host to node: configure unique host ID for diag purposes (optional) */
    HOST_MSG_TYPE_SET_HOST_ID_REQ     = HOST_MSG_DIR_HOST_TO_NODE | 0x46,

    /** Host to node:  are security keys provisioned? */
    HOST_MSG_TYPE_GET_KEYS_PROVISIONED_REQ = HOST_MSG_DIR_HOST_TO_NODE | 0x47,
    /** Node to host:  are security keys provisioned? response */
    HOST_MSG_TYPE_GET_KEYS_PROVISIONED_RSP = HOST_MSG_DIR_NODE_TO_HOST | 0x47,

    /** Host to node:  request node type */
    HOST_MSG_TYPE_GET_NODE_TYPE_REQ = HOST_MSG_DIR_HOST_TO_NODE | 0x48,
    /** Node to host:  node type response */
    HOST_MSG_TYPE_GET_NODE_TYPE_RSP = HOST_MSG_DIR_NODE_TO_HOST | 0x48,

    /**  Host to node: configure manufacturing TX test mode */
    HOST_MSG_TYPE_CONF_MANUF_TX_TEST = HOST_MSG_DIR_HOST_TO_NODE | 0x49,
    /* new for sys rel 1.4 */

    /**  Host to node: request calibration data for TX power control */
    HOST_MSG_TYPE_READ_TXPWR_CAL_DATA_REQ = HOST_MSG_DIR_HOST_TO_NODE | 0x4A,
    /**  Node to host: calibration data for TX power control */
    HOST_MSG_TYPE_READ_TXPWR_CAL_DATA_RSP = HOST_MSG_DIR_NODE_TO_HOST | 0x4A,
    
    /**  Host to node: configure manufacturing RX test mode */
    HOST_MSG_TYPE_CONF_MANUF_RX_TEST = HOST_MSG_DIR_HOST_TO_NODE | 0x4B,
    
    /* backported from 2.0 to 1.4 */
    /** Node to host: scan result indication */
    HOST_MSG_TYPE_SCAN_RESULT_IND = HOST_MSG_DIR_NODE_TO_HOST | 0x4C,

    /** Node to host: externally visible RX sample message */
    HOST_MSG_TYPE_RX_SAMPLE_IND = HOST_MSG_DIR_NODE_TO_HOST | 0x4D,

    /** Node to host: status of current RF TX test */
    HOST_MSG_TYPE_MANUF_TX_TEST_IND = HOST_MSG_DIR_NODE_TO_HOST | 0x4E,
    
    /* new for sys rel 2.0 */
    /** Host to node:  read AP list */
    HOST_MSG_TYPE_READ_FLASH_AP_LIST_REQ = HOST_MSG_DIR_HOST_TO_NODE | 0x60,
    /** Node to host:  read AP list response */
    HOST_MSG_TYPE_READ_FLASH_AP_LIST_RSP = HOST_MSG_DIR_NODE_TO_HOST | 0x60,
    /** Host to node:  write AP list */
    HOST_MSG_TYPE_WRITE_FLASH_AP_LIST_REQ = HOST_MSG_DIR_HOST_TO_NODE | 0x61,

    /** Node to host: network exit indication */
    HOST_MSG_TYPE_NETWORK_EXIT_IND = HOST_MSG_DIR_NODE_TO_HOST | 0x62,

    /** Host to node:  get host interface state */
    HOST_MSG_TYPE_GET_HOST_INTF_STATE_REQ = HOST_MSG_DIR_HOST_TO_NODE | 0x63,
    /** Node to host:  get host interface state response */
    HOST_MSG_TYPE_GET_HOST_INTF_STATE_RSP = HOST_MSG_DIR_NODE_TO_HOST | 0x63,

    /** host to node: power fail notification (trigger last gasp operation) */
    HOST_MSG_TYPE_POWER_FAIL = HOST_MSG_DIR_HOST_TO_NODE | 0x64,

    /** host to node: is the node currently in the power fail mode (due to */
    /* previous message)? */
    HOST_MSG_TYPE_IS_POWER_FAILED_REQ = HOST_MSG_DIR_HOST_TO_NODE | 0x65,
    /** node to host: current power failure state */
    HOST_MSG_TYPE_IS_POWER_FAILED_RSP = HOST_MSG_DIR_NODE_TO_HOST | 0x65,

    /** host to node: potential power fail notification */
    HOST_MSG_TYPE_POTENTIAL_POWER_FAIL = HOST_MSG_DIR_HOST_TO_NODE | 0x66,

    /** host to node: power has been restored notification */
    HOST_MSG_TYPE_POWER_RESTORED = HOST_MSG_DIR_HOST_TO_NODE | 0x67,

    /** node to host: status of power fail SDU */
    HOST_MSG_TYPE_PF_SDU_STATUS = HOST_MSG_DIR_NODE_TO_HOST | 0x68,
    
    /* OnRamp Internal Use (not available to customers) */
    
    HOST_MSG_TYPE_POKE                           = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x00,
    HOST_MSG_TYPE_POKE_RSP                       = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x00,
    HOST_MSG_TYPE_PEEK                           = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x01,
    HOST_MSG_TYPE_PEEK_RSP                       = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x01,
    HOST_MSG_TYPE_RF_SPI_POKE                    = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x02,
    HOST_MSG_TYPE_RF_SPI_POKE_RSP                = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x02,
    HOST_MSG_TYPE_AFE_SPI_POKE                   = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x03,
    HOST_MSG_TYPE_AFE_SPI_POKE_RSP               = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x03,
    HOST_MSG_TYPE_AFE_SPI_PEEK                   = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x04,
    HOST_MSG_TYPE_AFE_SPI_PEEK_RSP               = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x04,
    HOST_MSG_TYPE_TOGGLE_TOUT                    = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x05,
    HOST_MSG_TYPE_TOGGLE_TOUT_RSP                = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x05,
    HOST_MSG_TYPE_SET_AFE_MODE_REQ               = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x06,
    HOST_MSG_TYPE_SET_AFE_MODE_RSP               = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x06,
    HOST_MSG_TYPE_AFE_POKE                       = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x07,
    HOST_MSG_TYPE_AFE_POKE_RSP                   = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x07,
    HOST_MSG_TYPE_AFE_PEEK                       = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x08,
    HOST_MSG_TYPE_AFE_PEEK_RSP                   = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x08,

    HOST_MSG_TYPE_SET_BW                         = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x10,
    HOST_MSG_TYPE_SET_SCAN_RANGE                 = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x11,
    HOST_MSG_TYPE_SET_NC_ACCUM                   = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x12,
    HOST_MSG_TYPE_SET_UL_MARGIN                  = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x13,
    HOST_MSG_TYPE_SET_PHY_TEST_MODE              = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x14,
    HOST_MSG_TYPE_RX_TEST_SET_DEMOD_PARAMS       = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x15,
    HOST_MSG_TYPE_TEST_RXDATA                    = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x16,
    HOST_MSG_TYPE_TEST_TXDATA                    = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x17,
    HOST_MSG_TYPE_TX_TEST_MODE_CLEAR_PAYLOADS    = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x18,
    HOST_MSG_TYPE_TX_TEST_MODE_ADD_PAYLOAD       = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x19,
    HOST_MSG_TYPE_TX_TEST_MODE_SET_START_SUBSLOT = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x1a,
    HOST_MSG_TYPE_ADC_SAMPLE_READ                = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x1b,
    HOST_MSG_TYPE_ADC_SAMPLE_READ_RSP            = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x1b,
    HOST_MSG_TYPE_SET_SLEEP_TIME_FRAMES          = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x1c,
    HOST_MSG_TYPE_FORCE_AFE_RADIO_ACTIVE         = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x1d,
    HOST_MSG_TYPE_GET_AUXADC_VALS                = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x1e,
    HOST_MSG_TYPE_GET_AUXADC_VALS_RSP            = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x1e,
    HOST_MSG_TYPE_AGC_DIAG                       = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x1f,
    HOST_MSG_TYPE_FRAME_ENERGY_DIAG              = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x20,
    /** Sets TX system ID (essentially sets UL gold code) */
    HOST_MSG_TYPE_SET_TX_AP_ID                   = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x21,
    /** Sets the lowest power state possible */
    HOST_MSG_TYPE_SET_LOWEST_POWER_STATE         = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x22,
    HOST_MSG_TYPE_SET_TX_PWR_LIMIT               = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x23,
    /** Gets TX AP ID (essentially sets UL gold code) */
    HOST_MSG_TYPE_GET_TX_AP_ID                   = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x24,
    HOST_MSG_TYPE_GET_TX_AP_ID_RSP               = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x24,    
    /** Aux DAC control */
    HOST_MSG_TYPE_SET_AUX_DAC_REQ                    = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x25,
    HOST_MSG_TYPE_SET_AUX_DAC_RSP                    = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x25,
    /** Arbitrary memory access (NON-RELEASE BUILDS ONLY) */
    HOST_MSG_TYPE_ARB_MEM_ACC_REQ                = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x26,
    HOST_MSG_TYPE_ARB_MEM_ACC_RSP                = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x26,
    HOST_MSG_TYPE_ADC_SAMPLE_BURST_REQ           = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x27,
    HOST_MSG_TYPE_ADC_SAMPLE_BURST_IND           = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x27,
    HOST_MSG_TYPE_SET_DL_RANDOM_PDU_DROP_REQ     = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x28,
    HOST_MSG_TYPE_SET_DL_RANDOM_PDU_DROP_RSP     = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x28,
    HOST_MSG_TYPE_GET_DL_RANDOM_PDU_DROP_REQ     = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x29,
    HOST_MSG_TYPE_GET_DL_RANDOM_PDU_DROP_RSP     = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x29,


    HOST_MSG_TYPE_READ_FLASH_CAL                 = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x30,
    HOST_MSG_TYPE_READ_FLASH_CAL_RSP             = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x30,
    HOST_MSG_TYPE_WRITE_FLASH_CAL                = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x31,

    HOST_MSG_TYPE_AFE_TESTMODE                   = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x40,
    HOST_MSG_TYPE_AFE_TESTMODE_RSP               = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x40,
    HOST_MSG_TYPE_AUX_ADC_READ                   = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x41,
    HOST_MSG_TYPE_AUX_ADC_READ_RSP               = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x41,
    HOST_MSG_TYPE_PHY_COMP_CTRL                  = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x42,
    HOST_MSG_TYPE_PHY_COMP_CTRL_RSP              = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x42,
    HOST_MSG_TYPE_AUX_ADC_READ_V2                = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x43,
    HOST_MSG_TYPE_AUX_ADC_READ_V2_RSP            = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x43,
    HOST_MSG_TYPE_TEST_PIN_POKE                  = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x44,
    HOST_MSG_TYPE_TEST_PIN_POKE_RSP              = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x44,
    HOST_MSG_TYPE_TEST_PIN_PEEK                  = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x45,
    HOST_MSG_TYPE_TEST_PIN_PEEK_RSP              = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x45,


    /** Debug string indication */
    HOST_MSG_TYPE_DBG_STR_IND                    = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x50,
    HOST_MSG_TYPE_SET_LOG_MASK                   = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x51,
    HOST_MSG_TYPE_GET_LOG_MASK                   = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x52,
    HOST_MSG_TYPE_GET_LOG_MASK_RSP               = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x53,
    HOST_MSG_TYPE_GET_SYS_METRICS                = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x54,
    HOST_MSG_TYPE_GET_SYS_METRICS_RSP            = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x54,
    HOST_MSG_TYPE_GET_VERSION_REQ                = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x56,
    HOST_MSG_TYPE_GET_VERSION_RSP                = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x56,

    /** Mac Stats Indication: PDUs */
    HOST_MSG_TYPE_MAC_STATS_IND_PDUS             = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x60,
    /** Mac Stats Indication: SDU */
    HOST_MSG_TYPE_MAC_STATS_IND_SDU              = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x61,
    /** Mac Stats Indication: Rx Report */
    HOST_MSG_TYPE_MAC_STATS_IND_RX_REPORT        = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x62,
    /** Mac Stats Indication: Tx Report */
    HOST_MSG_TYPE_MAC_STATS_IND_TX_REPORT        = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x63,
    /** Mac Stats Indication: Mac Flags */
    HOST_MSG_TYPE_MAC_STATS_IND_FLAGS            = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x64,
    /** Mac Stats Indication: Tx Schedule */
    HOST_MSG_TYPE_MAC_STATS_IND_TX_SCHEDULE      = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x65,
    /** Mac Stats Indication Rx Schedule */
    HOST_MSG_TYPE_MAC_STATS_IND_RX_SCHEDULE      = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x66,
    /** Mac Stats Indication Sdu Report */
    HOST_MSG_TYPE_MAC_STATS_IND_SDU_REPORT       = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x67,
    /* might as well reserve 0x67 - 0x6F for other mac stats messages */

    /** Write a flash page request. */
    HOST_MSG_TYPE_WRITE_FLASH_PAGE_REQ           = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x70,
    /** Write a flash page response. */
    HOST_MSG_TYPE_WRITE_FLASH_PAGE_RSP           = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x70,
    /** Read a flash page request. */
    HOST_MSG_TYPE_READ_FLASH_PAGE_REQ           = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x71,
    /** Read a flash page response. */
    HOST_MSG_TYPE_READ_FLASH_PAGE_RSP           = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x71,
    /** Verify a flash page request. */
    HOST_MSG_TYPE_VERIFY_FLASH_PAGE_REQ           = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x72,
    /** Verify a flash page response. */
    HOST_MSG_TYPE_VERIFY_FLASH_PAGE_RSP           = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x72,

    /** Security test build hook. */
    HOST_MSG_TYPE_SEC_TEST_HOOK_REQ              = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x73,

    /** code download status */
    HOST_MSG_TYPE_GET_CDLD_STATUS_REQ            = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x74,
    HOST_MSG_TYPE_GET_CDLD_STATUS_RSP            = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x74,

    /** Host to node: read power control params */
    HOST_MSG_TYPE_GET_POWER_CTRL_OFFSETS_REQ = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x76,
    /** Node to host: read power control params response */
    HOST_MSG_TYPE_GET_POWER_CTRL_OFFSETS_RSP = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x76,
    /** Host to node: clear power control params */
    HOST_MSG_TYPE_CLEAR_POWER_CTRL_OFFSETS_REQ = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x77,

    /** Host to node: clear watchdog count and/or sys metrics counters */
    HOST_MSG_TYPE_CLEAR_COUNTERS_REQ            = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x78,
    
    /** Node to host: binary debug string data */
    HOST_MSG_TYPE_DBG_PACKED_IND                = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x79,

    HOST_MSG_TYPE_SET_CDLD_STATUS_REQ            = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x7a,

    /** Get/clear MUD groups. */
    HOST_MSG_TYPE_GET_MUD_GROUPS_REQ            = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x7B,
    HOST_MSG_TYPE_GET_MUD_GROUPS_RSP            = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x7B,

    HOST_MSG_TYPE_FORCE_HANDOVER                = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x7C,

    HOST_MSG_TYPE_GET_FLASH_IDENT_REQ            = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0x7D,
    HOST_MSG_TYPE_GET_FLASH_IDENT_RSP            = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0x7D,

    HOST_MSG_TYPE_PROTOCOL_VERSION_REQ          = HOST_MSG_ONRAMP | HOST_MSG_DIR_HOST_TO_NODE | 0xFF,
    HOST_MSG_TYPE_PROTOCOL_VERSION_RSP          = HOST_MSG_ONRAMP | HOST_MSG_DIR_NODE_TO_HOST | 0xFF,
    """,
    prefix='HOST_MSG_TYPE_',

    replace=[
        ('HOST_MSG_DIR_HOST_TO_NODE', '0x%04x' % ucl_nhp_msg.ROUTING_FLAG_DIR_HOST_TO_NODE),
        ('HOST_MSG_DIR_NODE_TO_HOST', '0x%04x' % ucl_nhp_msg.ROUTING_FLAG_DIR_NODE_TO_HOST),
        ('HOST_MSG_ONRAMP', '0x%04x' % ucl_nhp_msg.ROUTING_FLAG_ONRAMP),
    ]
)

messages = []
for name in dir():
    obj = eval(name)
    if hasattr(obj, '__bases__') and issubclass(obj, Message) and not obj is Message:
        # audit of message size and constructability
        size = obj().sizeof()
        assert size % 4 == 0, "Message %s size is %d, not multiple of 4." % (obj, size)
        messages.append(obj)

del name


