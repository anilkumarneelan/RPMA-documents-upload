#!/usr/bin/env python

"""Command line interface to ATE TX test modes"""

import sys
import signal
import traceback

import ucl_nhp
import orwCmdLineParams
import host_cmn_msg

def usage(s = ''):
    """Prints the help text."""

    if s:
        print "Error: %s\n" % s

    print "Usage:  %s [OPTION] MODE" % sys.argv[0]
    print """

Configures a node for one of several ATE TX test modes.

MODE must be one of "CW_CENTER", "CW_OFFSET", "MODULATED", or "OFF".

CW_CENTER: generate a test tone at the center frequency.
CW_OFFSET: generate a test tone at center frequency + 100 kHz.
MODULATED: generate a modulated test signal.
OFF:       return to normal node operation (node reset is recommended).

OPTIONS:
"""
    for usageStr in orwCmdLineParams.usageLong():
        print "    %s" % usageStr

    print "    -F centerFreqInKhz"
    print "       Set center frequency (in integer kHz units)."
    print "    -V vga"
    print "       Set TX VGA control - use 0 to 63 or 255 for max calibrated VGA"
    print "    -A antenna"
    print "       Set antenna port to TX on (0 or 1) - only effective on micronodes"
    print "    -n, --no-host-cmn"
    print "       Disable host_cmn messaging for non-host_cmn hosts"
    print "    -h, --help"
    print "       Prints this help message."

    print """
EXAMPLE:

    %s -d /dev/ttyS0 -F 2405000 -V 32 -A 0 CW_CENTER
    """ % sys.argv[0]


if __name__ == '__main__':
    short_opts = "hF:V:A:n"
    long_opts  = ["help", "no-host-cmn"]
    (commArgs, extraOptions, args) = \
               orwCmdLineParams.parseParams(sys.argv[1:],short_opts,long_opts)

    def signal_handler(signal, frame):
        print 'Ctrl-C: canceled by user'
        if connection != None:
            connection.close()
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)
    
    vga = 32
    centerFreq = 2440000
    antenna = 0
    host_cmn = True
    
    for (opt, val) in extraOptions.items():
        if opt in ("-h", "--help"):
            usage()
            sys.exit(0)
        elif opt in ("-F",):
            centerFreq = int(val[0])
        elif opt in ("-V",):
            vga = int(val[0])
        elif opt in ("-A",):
            antenna = int(val[0])
        elif opt in ("-n", "--no-host-cmn"):
            host_cmn = False
        else:
            print "Unhandled option '%s'." % opt
            sys.exit(1)
        
    if len(args) == 0:
        usage("Missing MODE argument.")
        sys.exit(3)

    if len(args) > 1:
        usage("Extra arguments.")
        sys.exit(4)

    if centerFreq < 2402000 or centerFreq > 2500000:
        print 'center freq. %d is out of range (2402000 - 2500000)' % centerFreq
        sys.exit(5)

    if antenna != 0 and antenna != 1:
        print 'invalid antenna choice (must be 0 or 1)'
        sys.exit(6)

    if vga < 0 or vga > 63:
        if vga != 255:
            print 'invalid vga value %d (valid range 0 - 63 or 255)' % vga
            sys.exit(7)

    try:
        connection = ucl_nhp.Connection(commArgs)
    except Exception, err:
        print 'Error opening connection: %s' % err
        usage()
        sys.exit(-1)

    try:
        if host_cmn:
            msg = host_cmn_msg.HOST_OPERATING_MODE( \
                operatingMode=host_cmn_msg.HOST_OPERATING_MODE.PASSTHROUGH)
            ack = connection.sendMsg(msg)
            if not ack:
                raise IOError, 'Failed to get ACK for HOST_OPERATING_MODE message.'
            msg = host_cmn_msg.HOST_SET_DUT_POWER_REQ(state=1)
            rsp = connection.sendMsgGetRsp(msg, host_cmn_msg.HOST_SET_DUT_POWER_RSP)
            if not rsp:
                raise IOError, 'Failed to get response for HOST_SET_DUT_POWER_REW message.'
                
        connection.interrogate_nodes(nodes=commArgs["nodeIndex"])
        node_idx = commArgs["nodeIndex"][0]
        node_msg = connection.node(n=node_idx).node_msg

        # force node idle
        msg = node_msg.SYSTEM_SET_STATE(phy_enable=0)
        ack = connection.sendMsg(msg)
        if not ack:
            raise IOError, 'Failed to get ACK for SYSTEM_SET_STATE message.'

        # actually initiate test
        mode = node_msg.manufTxTestModeEnum[args[0]]
        msg = node_msg.CONF_MANUF_TX_TEST(centerFreqKHzOffset = centerFreq - 2400000,
                                          vga = vga,
                                          mode = mode,
                                          antennaSetting = antenna)
        ack = connection.sendMsg(msg,
                                 node_idx = node_idx)
        
        if not ack:
            raise IOError, 'Failed to get ACK for CONF_MANUF_TX_TEST message.'
    except Exception, e:
        print 'Error: %s' % e
        traceback.print_exc()
    finally:
        connection.close()
        sys.exit(0)
