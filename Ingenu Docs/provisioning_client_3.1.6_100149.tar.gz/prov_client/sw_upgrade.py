#!/usr/bin/env python

"""Performs a ULP node software upgrade via ehost."""

import ctypes
import os
import sys
import time
import zlib
import logging
import traceback

import struct

import orwCmdLineParams
import provisioning_error as p_err
import flash_compat

PAGE_SIZE = 256

def usage(s = ''):
    """Prints the help text."""

    if s:
        print "Error: %s\n" % s

    print "Usage:  %s [OPTION] BINFILE" % sys.argv[0]
    print """

Performs a host-based software upgrade of a ULP node. You will be prompted
before the upgrade is executed.

Note: the node will be placed in the idle state prior to upgrading.

OPTIONS:
"""
    for usageStr in orwCmdLineParams.usageLong():
        print "    %s" % usageStr

    print "    --just-do-it"
    print "       Do not prompt user before performing the upgrade."
    print "    --it-is-a-boot-loader"
    print "       The image to be flashed is a bootloader. Very bad things will happen"
    print "       if you lie about this."
    print "    -v, --verbose"
    print "       Increases verbosity level. Overridden if quiet mode is enabled."
    print "    -q, --quiet"
    print "       Enables quiet mode. Suppresses progress messages. Overrides verbosity"
    print "       setting."
    print "    --image-version=x.y.z"
    print "       Overrides autodetection of image version"
    print "    -h, --help"
    print "       Prints this help message."

    print """
EXAMPLE:

    %s -d /dev/ttyS0 enode.bin
    """ % sys.argv[0]


class nodeFwUpgrade():
    def __init__(self, connection, node_idx, \
                 quietMode = False, timeout = 5.0, logger = None, \
                 interactive = True, verbose = False):
        self.conn = connection
        self.node_idx = node_idx
        self.node_msg = connection.node(n=node_idx).node_msg
        self.timeout = timeout
        self.interactive = interactive
        self.verbose = verbose
        
        if isinstance(logger, logging.Logger):
            self._logger = logger
        elif logger is None:
            # No preconfigured logger passed in; default to info -> console
            self._logger = logging.getLogger('sw_upgrade')
            ch = logging.StreamHandler()
            if quietMode:
                self._logger.setLevel(logging.ERROR)
                ch.setLevel(logging.ERROR)
            elif verbose:
                self._logger.setLevel(logging.DEBUG)
                ch.setLevel(logging.DEBUG)
            else:
                self._logger.setLevel(logging.INFO)
                ch.setLevel(logging.INFO)
            ch.setFormatter(logging.Formatter())
            self._logger.addHandler(ch)
        else:
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.INVALID_LOGGER, target=p_err.CommType.LOCAL_ERROR)
        
    def _get_node_version(self):
        """Requests node version. Returns version tuple."""

        msg = self.conn.sendMsgGetRsp(self.node_msg.GET_VERSION_REQ(),
                                      self.node_msg.GET_VERSION_RSP,
                                      timeout=self.timeout,
                                      node_idx = self.node_idx )
        
        if msg is None:
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.COMM_FAILURE)

        major, minor, point = msg.major, msg.minor, msg.point
        return (major, minor, point)

    def _get_node_type(self):
        """Requests node version. Returns version tuple."""

        if not hasattr(self.node_msg, 'GET_NODE_TYPE_REQ'):
            # ancient 1.2 support
            return 'ENODE'
        
        msg = self.conn.sendMsgGetRsp(self.node_msg.GET_NODE_TYPE_REQ(),
                                      self.node_msg.GET_NODE_TYPE_RSP,
                                      timeout=self.timeout,
                                      node_idx = self.node_idx )
        
        if msg is None:
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.COMM_FAILURE)

        if msg.nodeType not in self.node_msg.nodeTypeReverseEnum:
            self._logger.error('Mismatch between node type and message lib! Need updated tools.')
            raise p_err.ULPProvisioningError(p_err.ErrorCodes.UNSUPPORTED_SW_VERSION, \
                                                 target=p_err.CommType.LOCAL_ERROR)
        
        return self.node_msg.nodeTypeReverseEnum[msg.nodeType]

    def _get_fpga_version(self):
        """Requests the node FPGA and software version."""

        msg = self.conn.sendMsgGetRsp(self.node_msg.VERSION(),
                                      self.node_msg.VERSION_RSP,
                                      timeout=self.timeout,
                                      node_idx = self.node_idx )
        
        if msg is None:
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.COMM_FAILURE)

        swRev, fpgaRev = msg.swRev, msg.phyRev
        return (swRev, fpgaRev)

    def _get_flash_cal_data(self):
        """Reads the flash calibration values from the node."""

        msg = self.conn.sendMsgGetRsp(self.node_msg.READ_FLASH_CAL(),
                                      self.node_msg.READ_FLASH_CAL_RSP,
                                      timeout=self.timeout,
                                      node_idx = self.node_idx )
            
        if msg is None:
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.COMM_FAILURE)

        cal_version = msg.calData.v2.version
        if hasattr(msg.calData, "v%d" % cal_version):
            return eval("msg.calData.v%d" % cal_version)
            
        self._logger.error("ERROR: Unknown flash calibration version %d." % cal_version)
        raise p_err.ULPProvisioningError( \
            p_err.ErrorCodes.UNKNOWN_CAL_VERSION)
    
    def _parse_image_version(self, nodeType, img):
        if nodeType == 'ENODE':
            return (None, None, None)
        # header:
        # uint32_t length;
        # uint32_t crc32;
        # uint32_t platform;
        # uint8_t version_major;
        # uint8_t version_minor;
        # uint8_t version_point;
        # uint8_t version_rel;
        (major, minor, point) = struct.unpack('<BBB', img[12:15])
        return (major, minor, point)

    def _validate_image_type(self, imgName, img, nodeType, is_boot_loader):

        if nodeType == 'ENODE':
            # No header or signature, and it's not quite good enough simply to
            # verify that this is not a unode image - might be random junk. We
            # can verify that the reset vectors look sane (since we don't need to
            # inspect the actual relocated values, just the instructions to load
            # said values, this won't vary from build to build).
            vecRelocJump = '\x18\xf0\x9f\xe5' # (LE) ldr pc, [pc #24]
            unusedVec0x14 = '\x00' * 4
            eNodeResetVectors = vecRelocJump*5 + unusedVec0x14 + vecRelocJump*2
            return (img[:32] == eNodeResetVectors)
        elif nodeType in ['UNODE', 'DNODE', 'PNODE', 'NNODE']:
            if is_boot_loader and os.path.basename(imgName).find('bootloader') >= 0:
                return True
            (length, origCrc, platform) = struct.unpack('<LLL', img[:12])
            img2 = img[:4] + '\x00'*4 + img[8:] # Zero out CRC
            calcCrc = zlib.crc32(img2) & (2**32 - 1)
            return (calcCrc == origCrc and platform == 1)
        else:
            # If we don't know the node type, we can't say anything about the
            # image
            self._logger.warning("Warning: can't validate image for node type %s" % nodeType)
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.UNSUPPORTED_HW_TYPE)

    def validate_flash_type(self, major, minor, point):
        if not hasattr(self.node_msg, 'GET_FLASH_IDENT_REQ'):
            self._logger.info("Can't ask for flash identifier, assume good")
            return True

        self.conn.sendMsg(self.node_msg.GET_FLASH_IDENT_REQ(),
                          timeout=self.timeout,
                          node_idx = self.node_idx)

        # should have error or ident rsp msg waiting
        while True:
            msg = self.conn.getMsg(timeout=0.1, node_idx = self.node_idx)
            if msg is None:
                self._logger.warning("Request for flash identifier timed out, proceeding anyway")
                return True
            if msg.name == 'ERROR_IND':
                self._logger.warning("Request for flash identifier returned error ind, proceeding anyway")
                return True
            if msg.name == 'GET_FLASH_IDENT_RSP':
                break

        # node told us what flash he has, so check it ...
        self._logger.debug("Reported flash type %s" % flash_compat.flashNameFromIdent(msg.ident))
        compat = flash_compat.isVersionCompatible(msg.ident, major, minor, point)
        if not compat:
            self._logger.error("Image version %d.%d.%d not compatible with this flash type!" % \
                                   (major, minor, point))
        else:
            self._logger.debug("Image version %d.%d.%d is compatible with this flash type." % \
                                   (major, minor, point))
        return compat
        
    def do_upgrade(self, img, img_name, is_boot_loader = False, skip_validation = False, \
                       img_major = None, img_minor = None, img_point = None):
        """ Do complete upgrade. """

        try:
            img_type = 0 # default to main image

            # break into pages
            pages = [img[i:i+PAGE_SIZE] for i,x in enumerate(img) if i % PAGE_SIZE == 0]

            # last page may not be a full page, so pad it
            pages[-1] += (PAGE_SIZE - len(pages[-1]))*chr(0xff)

            checksum = sum([sum(map(ord, page)) for page in pages])

            if not skip_validation:
                calData = self._get_flash_cal_data()
                fwRevMajor, fwRevMinor, fwRevPoint = self._get_node_version()
                fwRev = "%d.%d.%d" % (fwRevMajor, fwRevMinor, fwRevPoint)
                (swRev, fpgaRev) = self._get_fpga_version()
                nodeType = self._get_node_type()
                
                (major, minor, point) = self._parse_image_version(nodeType, img)
                if img_major is None:
                    img_major = major
                    img_minor = minor
                    img_point = point
                    
                self._logger.debug('Node type: %s' % nodeType)
                self._logger.debug('Node ID: 0x%X' % calData.node_id)
                self._logger.debug('Node SN: 0x%x' % calData.serial_num)
                self._logger.debug('Node FW revision: %s' % fwRev)
                self._logger.debug('Node HW revision: 0x%X' % calData.hardware_version)
                self._logger.debug('Node SW revision: 0x%X' % swRev)
                self._logger.debug('Node FPGA revision: 0x%X' % fpgaRev)
                self._logger.debug('image version: %s.%s.%s' % \
                                       (str(img_major), str(img_minor), str(img_point)))
                
                if fwRevMajor < 4 or (fwRevMajor == 4 and fwRevMinor < 4):
                    self._logger.error("ERROR: Node firmware revision %s does not support upgrade protocol." % fwRev)
                    raise p_err.ULPProvisioningError( \
                        p_err.ErrorCodes.UNSUPPORTED_SW_VERSION)

                if not self._validate_image_type(img_name, img, nodeType, is_boot_loader):
                    self._logger.error("Image '%s' does not match node type %s!" % \
                                         (img_name, nodeType))
                    raise p_err.ULPProvisioningError( \
                        p_err.ErrorCodes.UPGRADE_BAD_IMAGE)
                if nodeType != 'ENODE' and img_major != None:
                    if not self.validate_flash_type(img_major, img_minor, img_point):
                        self._logger.error("ERROR: image %d.%d.%d not supported by this HW (flash type)." % \
                                               (img_major, img_minor, img_point))
                        raise p_err.ULPProvisioningError( \
                            p_err.ErrorCodes.UNSUPPORTED_HW_TYPE)
                        
            self._logger.info("Programming node image '%s':  %d bytes, %d pages will be written." % \
                              (img_name, len(img), len(pages)))
            self._logger.info("Warning: do not interrupt power until script finishes.")

            if self.interactive:
                print "Press <enter> to continue, or <ctrl-c> to exit..."
                try:
                    raw_input()
                except KeyboardInterrupt:
                    print "Aborted by user before upgrade started."
                    raise p_err.ULPProvisioningError( \
                        p_err.ErrorCodes.USER_ABORT)

                if is_boot_loader:
                    print "Is %s REALLY a bootloader?  [yes/no]" % img_name,
                    try:
                        rsp = raw_input()

                        if rsp.lower() != 'yes':
                            print "Aborted by user before upgrade started."
                            raise p_err.ULPProvisioningError( \
                                p_err.ErrorCodes.USER_ABORT)
                    except KeyboardInterrupt:
                        print "Aborted by user before upgrade started."
                        raise p_err.ULPProvisioningError( \
                            p_err.ErrorCodes.USER_ABORT)
                    img_type = 1

            self._logger.debug("Putting node in SW upgrade mode ...")

            # Force node to idle state.
            req = self.node_msg.SYSTEM_SET_STATE(phy_enable=0)
            ack = self.conn.sendMsg(req, node_idx = self.node_idx)
            if not ack:
                self._logger.error("ERROR: Failed to get ACK for SYSTEM_SET_STATE request.")
                raise p_err.ULPProvisioningError( \
                    p_err.ErrorCodes.COMM_FAILURE)

            # Give the node a chance to change state.
            time.sleep(0.1)

            # Query the node for its new state.
            req = self.node_msg.GET_STATE()
            msg = self.conn.sendMsgGetRsp(req, self.node_msg.GET_STATE_RSP, node_idx = self.node_idx )
            
            if msg is None:
                self._logger.error("ERROR: GET_STATE_RSP response message never received.")
                raise p_err.ULPProvisioningError( \
                    p_err.ErrorCodes.COMM_FAILURE)
                
            state_name = None
            node_state = msg.state
            for (k,v) in self.node_msg.systemGetStateEnum.iteritems():
                if v == node_state:
                    state_name = k[len('SYS_STATE_'):]
                    break
            if state_name == None:
                self._logger.error("ERROR: Unknown node state %d" % node_state)
                raise p_err.ULPProvisioningError( \
                    p_err.ErrorCodes.COMM_FAILURE)
            elif node_state != self.node_msg.systemGetStateEnum['SYS_STATE_IDLE']:
                self._logger.error("ERROR: Node is not IDLE. Node is in %s state." % state_name)
                raise p_err.ULPProvisioningError( \
                    p_err.ErrorCodes.COMM_FAILURE)

            self._logger.debug("Node is IDLE")

            begin_req = self.node_msg.SW_UPGR2_BEGIN_REQ(numChunks = len(pages),
                                                         checksum = checksum,
                                                         imageType = img_type)
            
            begin_rsp = self.conn.sendMsgGetRsp( begin_req,
                                                 self.node_msg.SW_UPGR2_BEGIN_RSP,
                                                 node_idx = self.node_idx )
            
            if begin_rsp is None:
                raise p_err.ULPProvisioningError( \
                    p_err.ErrorCodes.COMM_FAILURE)
                
            if begin_rsp.result != 0:
                reasons = { 1: 'must be idle', 2: 'image too large', 3: 'must be 512kB Atmel-based eNode' }

                if begin_rsp.result in (reasons.keys()):
                    reason = reasons[begin_rsp.result]
                else:
                    reason = 'unknown'

                self._logger.error("ERROR: SW_UPGR2_BEGIN request was rejected: %d (%s)" % \
                                   (begin_rsp.result, reason))
                raise p_err.ULPProvisioningError( \
                    p_err.ErrorCodes.ERROR_RSP)

            self._logger.debug("Writing new SW image ...")

            # There doesn't seem to be a reliable way to get the term width on any
            # potential target platform (Windows x, Linux flavor y).  For now, just
            # use the standard 80.
            if self.interactive or self.verbose:
                term_width = 80
                num_marks = term_width - 2
                print '|' + '-'*num_marks + '|'
                print '|',
                marks_printed = 0

            startTime = time.time()

            for i,page in enumerate(pages):
                # last page may not be a full page, so pad it
                page += (PAGE_SIZE - len(page))*chr(0)

                # calc checksum
                checksum = sum(map(ord, page)) & 0xffffffff

                payload = [ord(byte) for byte in page]
                payload_a = (ctypes.c_ubyte*256)()
                for j,byte in enumerate(payload):
                    payload_a[j] = payload[j]

                chunk_req = self.node_msg.SW_UPGR2_CHUNK_REQ(num=i, checksum=checksum, chunk=payload_a)
                chunk_rsp = self.conn.sendMsgGetRsp(chunk_req,
                                                    self.node_msg.SW_UPGR2_CHUNK_RSP,
                                                    node_idx = self.node_idx )
                if not chunk_rsp:
                    raise p_err.ULPProvisioningError( \
                        p_err.ErrorCodes.COMM_FAILURE)

                if chunk_rsp.result != 0:
                    self._logger.error('ERROR: chunk rejected!')
                    raise p_err.ULPProvisioningError( \
                        p_err.ErrorCodes.ERROR_RSP)

                if self.interactive or self.verbose:
                    if (float(i) / len(pages)) > (float(marks_printed) / num_marks):
                        sys.stdout.write('=')
                        sys.stdout.flush()
                        marks_printed += 1

            # Finished sending image chunks.
            if self.interactive or self.verbose:
                print '|'
                sys.stdout.flush()

            self._logger.info("Image written in %.1f seconds" % (time.time() - startTime, ))

            try:
                end_req = self.node_msg.SW_UPGR2_END_REQ()
                end_rsp = self.conn.sendMsgGetRsp(end_req,
                                                  self.node_msg.SW_UPGR2_END_RSP,
                                                  node_idx = self.node_idx,
                                                  timeout=self.timeout)
                if not end_rsp:
                    raise IOError
                
                if end_rsp.result != 0:
                    self._logger.error("ERROR: SW_UPGR2_END_RSP failed with code %d" % end_rsp.result)
                    raise p_err.ULPProvisioningError( \
                        p_err.ErrorCodes.ERROR_RSP)

            except IOError:
                # it is possible the ack did not get out before the node started
                # cutting over ... wait a bit and try to interrogate. Pass if it
                # works, otherwise should get another IOError ...
                self._logger.info("Cutover response not received, trying interrogate instead")
                time.sleep(2)
                self.conn.interrogate_nodes(nodes=set([self.node_idx]))
                self._logger.info("interrogate OK, cutover succeeded")
                
        except IOError:
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.COMM_FAILURE)
        
if __name__ == '__main__':
    connection = None

    short_opts = "hqv"
    long_opts  = ["help", "just-do-it", "it-is-a-boot-loader", "quiet", "verbose", "image-version="]

    (commArgs, extraOptions, args) = orwCmdLineParams.parseParams(sys.argv[1:],short_opts,long_opts)

    interactive     = True
    quietMode       = False
    is_boot_loader  = False
    verbose         = False
    major           = None
    minor           = None
    point           = None
    
    for (opt, val) in extraOptions.items():
        if opt in ("-h", "--help"):
            usage()
            sys.exit(0)
        elif opt in ("--just-do-it"):
            interactive = False
        elif opt in ("--it-is-a-boot-loader"):
            is_boot_loader = True
        elif opt in ("-v", "--verbose"):
            verbose = True
        elif opt in ("-q", "--quiet"):
            # Note: quiet mode overrides verbosity.
            quietMode = True
        elif opt in ("--image-version", ):
            (major, minor, point) = val[-1].split('.')
            major = int(major)
            minor = int(minor)
            point = int(point)
        else:
            usage("Unhandled option '%s'." % opt)
            sys.exit(2)

    # read the .bin file
    if len(args) == 0:
        usage("Missing binary file argument.")
        sys.exit(3)
    try:
        image = open(args[0], 'rb').read()
    except IndexError:
        usage("Error opening binary file '%s'." % args[0])
        sys.exit(4)

    res = -1
    try:
        import ucl_nhp
        
        connection = ucl_nhp.Connection(commArgs)
        connection.interrogate_nodes(nodes=commArgs["nodeIndex"])
        node_msg = connection.node(n=commArgs["nodeIndex"][-1]).node_msg
        upgrade = nodeFwUpgrade(connection, commArgs["nodeIndex"][-1], \
                                quietMode = quietMode, interactive = interactive, \
                                verbose = verbose)
        upgrade.do_upgrade(image, args[0], is_boot_loader = is_boot_loader, \
                               img_major = major, img_minor = minor, img_point = point)
        res = 0
    except p_err.ULPProvisioningError as e:
        print str(e)
        res = e.errorCode
    except IOError:
        print 'I/O error from message layer'
        res = p_err.ErrorCodes.COMM_FAILURE
    except:
        traceback.print_exc()
    finally:
        if connection != None:
            connection.close()
    sys.exit(res)

