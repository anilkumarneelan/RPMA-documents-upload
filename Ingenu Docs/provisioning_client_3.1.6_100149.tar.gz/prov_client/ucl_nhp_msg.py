"""NHP message definition base class."""

# If you want to know how this all works, keep reading:
#
# Most messages are defined as a class which inherits from Message.  Message
# is a ctypes class.  The message names are important, they have to match the
# name used in the enum from host_msg.h/host_customer_msg.h which is copied in
# this file.  By matching the names we can do lookups into the table, etc.
#
# All Message/Structure objects have the ability to set/get bytes/strings as well
# as do normal ctypes things.

from ucl_types import Structure
from ucl_types import Union
import ctypes


# message ID space routing bits
ROUTING_FLAG_DIR_NODE_TO_HOST = 0x0000 # node-to-host or host-to-PC direction
ROUTING_FLAG_ONRAMP           = 0x8000 # ORW-internal (non-published) messaging
ROUTING_FLAG_DIR_HOST_TO_NODE = 0x4000 # host-to-node or PC-to-host direction
ROUTING_FLAG_HOST_COMMON      = 0x2000 # host messages common to all hosts
ROUTING_FLAG_HOST_SPECIFIC    = 0x1000 # host messages specific to particular hosts


class Header(Structure):
    """Common message header."""

    _fields_ = [
        ('msgLen', ctypes.c_ushort),
        ('msgType', ctypes.c_ushort),
    ]


class Footer(ctypes.c_uint):
    """Common message footer."""
    pass


class Message(Structure):
    """Message class for host interface messages."""

    def __init__(self, *args, **kwargs):
        Structure.__init__(self, *args, **kwargs)

        self.pack_header()
        self.pack_footer()

        self.name = self.__class__.__name__

    def getId(self):
        return self._msgType

    def pack_header(self):
        raise NotImplementedError( \
            "pack_header must run from message library module so types. is defined")

    def pack_footer(self):
        self.footer = 0xA5A5F0F0


    def set_bytes(self, bytes):
        """Wrapper for Structure.set_bytes() but does some error checking."""
        Structure.set_bytes(self, bytes)

        assert self._msgType == self.header.msgType

        # these can't be checked in the variable len message case... too bad
        #assert self._msgLen == self.header.msgLen
        #assert self.footer == 0xA5A5F0F0


    def to_struct(self):
        msg = self()

        types = {
            ctypes.c_uint:   'uint32_t',
            ctypes.c_ushort: 'uint16_t',
            ctypes.c_ubyte:  'uint8_t',
            ctypes.c_int:    'int32_t',
            ctypes.c_short:  'int16_t',
            ctypes.c_byte:   'int8_t',
            Header: 'host_msg_header_t',
            Footer: 'uint32_t',
        }

        t = ''

        t += 'typedef struct\n{\n'

        for field in msg._fields_:
            name, _type = field

            if name == 'footer':
                t += '\n'

            try:
                t += '    %-16s %s;\n' % (types[_type], name)
            except KeyError, e:
                t += '    // %s not translatable\n' % e

            if name == 'header':
                t += '\n'

        t += '} %s_t;\n\n\n' % msg.name

        return t
