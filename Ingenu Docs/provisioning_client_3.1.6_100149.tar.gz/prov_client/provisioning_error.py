#!/usr/bin/env python
#
# Copyright (c) 2012. OnRamp Wireless, Inc.
# All rights reserved.
#
# OnRamp Wireless, Inc makes no representations about the suitability of
# this source code for any purpose. This source code is provided "AS IS"
# and without any express or implied warranties, including, without
# limitation, implied warranties of merchantability and fitness for any
# particular purpose.

""" Error codes and exception definitions for provisioning scripts """

import util
import sys

CommType = util.Enum(
    """
    LOCAL_ERROR,
    NODE,
    HOST,
    PROV_SERVER,
    GW,
    APP_SPECIFIC,
    """)

ErrorCodes = util.Enum(
    """
    NO_ERROR,
    USER_ABORT,
    INVALID_LOGGER,
    INVALID_ARGUMENTS,

    COMM_FAILURE,
    ERROR_RSP,
    VERIFICATION_FAILED,

    UNSUPPORTED_SW_VERSION,
    UNSUPPORTED_HW_TYPE,
    UNKNOWN_CAL_VERSION,
    UNKNOWN_CONF_VERSION,
    
    UPGRADE_BAD_IMAGE,
    CONF_FILE_INVALID,
    BAD_SECURITY_FILE,

    UNKNOWN_PROVISIONING_ERROR,

    COMM_OPEN_FAILURE,
    """)

ErrorStrings = {
    ErrorCodes.NO_ERROR : 'Successful operation',
    ErrorCodes.USER_ABORT : 'User aborted script',
    ErrorCodes.INVALID_LOGGER : 'Logger specified not a logging.Logger() instance',
    ErrorCodes.INVALID_ARGUMENTS: 'Command line parsing failed',

    ErrorCodes.COMM_FAILURE : 'Problem communicating',
    ErrorCodes.ERROR_RSP : 'Request generated error response',
    ErrorCodes.VERIFICATION_FAILED : 'Readback of an updated item did not match expected',

    ErrorCodes.UNSUPPORTED_SW_VERSION : 'Unsupported SW version',
    ErrorCodes.UNSUPPORTED_HW_TYPE : 'HW version not known or not supported',
    ErrorCodes.UNKNOWN_CAL_VERSION : 'Not calibrated or unknown cal version',
    ErrorCodes.UNKNOWN_CONF_VERSION : 'Not configured or unknown conf version',
    
    ErrorCodes.UPGRADE_BAD_IMAGE : 'Supplied firmware image does not match HW type',
    ErrorCodes.CONF_FILE_INVALID : 'Parsing or validation of config file failed',
    ErrorCodes.BAD_SECURITY_FILE : 'Invalid certificate or key file',

    ErrorCodes.UNKNOWN_PROVISIONING_ERROR : 'Provisioning failed - no relevant error',

    ErrorCodes.COMM_OPEN_FAILURE : 'Failure to initialize device comm (no such device, permissions, connection refused, etc.)',
    }

class ULPProvisioningError(Exception):
    def __init__(self, errorCode, extraInfo = None, target = CommType.NODE):
        self.errorCode = errorCode
        self.extraInfo = extraInfo
        self.target = target
        
    def __str__(self):
        s = 'Provisioning error %d target %s: %s' % \
            (self.errorCode, CommType.name(self.target), ErrorStrings[self.errorCode])
        if self.extraInfo:
            s = s + ' (%s)' % self.extraInfo
        return s

###############################################################################
if __name__ == '__main__':
    print 'The provisioning server protocol module is not a stand alone program.'
    sys.exit(-1)
