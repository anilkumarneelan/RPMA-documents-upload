#!/usr/bin/env python
#
# Utility routines for Gateway and Node keys.
#
# Copyright (c) 2012. OnRamp Wireless, Inc.
# All rights reserved.
#
# OnRamp Wireless, Inc makes no representations about the suitability of
# this source code for any purpose. This source code is provided "AS IS"
# and without any express or implied warranties, including, without
# limitation, implied warranties of merchantability and fitness for any
# particular purpose.

import time
import sys

import provisioning_error as p_err

# Max number of times to try to provision keys and delay between attempts.
_KEY_PROVISION_RETRY_MAX = 3
_KEY_PROVISION_DELAY_SEC = 35

class NodeInterface():
    """Node interface class. Provides interfaces for node messaging
    related to provisioning a node."""

    def __init__(self, connection, logger, node_idx = 0, verbosity = 0):
        self.verbosity = verbosity
        self.connection = connection
        self.node_idx = node_idx
        self.node_msg = self.connection.node(n=self.node_idx).node_msg
        self.logger = logger
        
    def __del__(self):
        if self.verbosity > 3:
            self.logger.info("HostInterface destructor.")

    def get_node_version(self):
        """Requests node firmware version. Returns a tuple."""
        msg = self.connection.sendMsgGetRsp(self.node_msg.GET_VERSION_REQ(),
                                            self.node_msg.GET_VERSION_RSP,
                                            node_idx = self.node_idx )
        
        if msg is None:
            self.logger.error("GET_VERSION_RSP timeout")
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.COMM_FAILURE)
            
        return (msg.major, msg.minor, msg.point, msg.buildStamp)

    def get_flash_cal_data(self, force = False):
        """Reads the flash calibration values from the node."""
        msg = self.connection.sendMsgGetRsp(self.node_msg.READ_FLASH_CAL(),
                                            self.node_msg.READ_FLASH_CAL_RSP,
                                            node_idx = self.node_idx )
        
        if msg is None:
            self.logger.error("READ_FLASH_CAL_RSP timeout")
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.COMM_FAILURE)
       
        cal_version = msg.calData.v2.version
        if hasattr(msg.calData, "v%d" % cal_version):
            return eval("msg.calData.v%d" % cal_version)
        
        self.logger.error("Unknown flash calibration version {0}.".format(cal_version))
        if self.verbosity > 2:
            self.logger.info(msg.calData)

        if force:
            return msg.calData.v2
        
        raise p_err.ULPProvisioningError( \
            p_err.ErrorCodes.UNKNOWN_CAL_VERSION)
        
    def get_node_id(self, force = False):
        """Queries and returns the node ID as an integer."""
        cal_data = self.get_flash_cal_data(force = force)
        if cal_data.node_id == 0xFFFFFFFF or cal_data.node_id == 0:
            if not force:
                raise ValueError, "Invalid node ID " + hex(cal_data.node_id)
            if self.verbosity > 0:
                self.logger.info("Invalid node ID " + hex(cal_data.node_id))
                self.logger.info("Forcing provisioning anyway.")
        return cal_data.node_id

    def get_node_type(self):
        """Queries and returns the node type."""
        (major, minor, point, stamp) = self.get_node_version()
        if major >= 5:
            msg = self.connection.sendMsgGetRsp( \
                self.node_msg.GET_NODE_TYPE_REQ(),
                self.node_msg.GET_NODE_TYPE_RSP,
                node_idx = self.node_idx )
        
            if msg is None:
                self.logger.error("GET_NODE_TYPE_RSP timeout")
                raise p_err.ULPProvisioningError( \
                    p_err.ErrorCodes.COMM_FAILURE)
            
            return self.node_msg.nodeTypeReverseEnum[msg.nodeType]
        else:
            return 'ENODE'
    
    def clear_exception_buffer(self):
        """Clears the exception buffer in the node."""
        msg = self.connection.sendMsgGetRsp( \
            self.node_msg.GET_EXCEPTION_BUFFER_REQ(chunk = 0, clearBuffer = 1),
            self.node_msg.GET_EXCEPTION_BUFFER_RSP,
            node_idx = self.node_idx )
        
        if msg is None:
            self.logger.error("GET_EXCEPTION_BUFFER_RSP timeout")
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.COMM_FAILURE)

    def set_node_idle(self):
        """Sets the node state to idle. Reads the state back to verify."""
        req = self.node_msg.SYSTEM_SET_STATE(phy_enable = 0)
        ack = self.connection.sendMsg(req, node_idx = self.node_idx)
        if not ack:
            self.logger.error("SYSTEM_SET_STATE ack fail")
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.COMM_FAILURE)

        # Give the node a chance to change state.
        time.sleep(0.1)

        msg = self.connection.sendMsgGetRsp(self.node_msg.GET_STATE(),
                                            self.node_msg.GET_STATE_RSP,
                                            node_idx = self.node_idx )
        if msg is None:
            self.logger.error("GET_STATE_RSP timeout")
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.COMM_FAILURE)

        node_state = msg.state
        for (k, v) in self.node_msg.systemGetStateEnum.iteritems():
            if v == node_state:
                state_name = k[len('SYS_STATE_'):]
                break
        if state_name == None:
            self.logger.error("ERROR: Unknown node state %d" % node_state)
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.ERROR_RSP)
        elif node_state != self.node_msg.systemGetStateEnum['SYS_STATE_IDLE']:
            self.logger.error("ERROR: Node is not IDLE. Node is in %s state." % state_name)
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.VERIFICATION_FAILED)

        self.logger.debug("Node is IDLE")

    def provision_keys(self, root_key, gw_key, cdld_key):
        """Provisions the GW, CDLD, and Node Root keys (byte array format) into the node."""

        req = self.node_msg.PROVISION_KEYS_REQ()

        for i in xrange(len(req.rootKey)):
            req.rootKey[i] = ord(root_key[i])
        for i in xrange(len(req.gatewayKey)):
            req.gatewayKey[i] = ord(gw_key[i])
        for i in xrange(len(req.gatewayCdldKey)):
            req.gatewayCdldKey[i] = ord(cdld_key[i])
        
        # we retry this request because enodes can hang for a watchdog reset
        # on JTAG locking
        for dummy in range(_KEY_PROVISION_RETRY_MAX):
            msg = self.connection.sendMsgGetRsp(req, \
                                                self.node_msg.PROVISION_KEYS_RSP, \
                                                node_idx = self.node_idx )

            if msg:
                # successful
                return

            if self.verbosity > 1:
                self.logger.info("Key provisioning error, sleeping for %d seconds." % \
                            _KEY_PROVISION_DELAY_SEC)

            time.sleep(_KEY_PROVISION_DELAY_SEC)

        # retries exhausted
        self.logger.error("ERROR: PROVISION_KEYS_RSP timeout, retries exhausted")
        raise p_err.ULPProvisioningError( \
            p_err.ErrorCodes.COMM_FAILURE)
    
    def is_node_provisioned(self):
        """Queries a node to determine if keys have been provisioned."""
        
        msg = self.connection.sendMsgGetRsp(self.node_msg.GET_KEYS_PROVISIONED_REQ(),
                                            self.node_msg.GET_KEYS_PROVISIONED_RSP,
                                            node_idx = self.node_idx )

        if msg is None:
            self.logger.error("GET_KEYS_PROVISIONED_RSP timeout")
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.COMM_FAILURE)

        return msg.result


###############################################################################
if __name__ == '__main__':
    print 'The key utilities module is not a stand alone program.'
    sys.exit(-1)
