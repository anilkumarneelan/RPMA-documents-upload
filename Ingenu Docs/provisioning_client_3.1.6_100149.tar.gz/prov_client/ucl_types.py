"""UCL basic types."""

# ctypes provides some very useful classes, but they have some tricky syntax
# for proper usage. We inherit from and extend them with several friendlier
# methods.

import ctypes
import struct
import types


# (Not-so) clever trick for duplicating code between our Structure and Union
# derived classes: Declare functions outside either scope, then map them into
# each scope.
def _s_u_pretty(self, radix=10, multiline=False, depth=0):
    #print 'looking at type %s' % type(self)
    s = ''

    if multiline:
        s += '  '*depth + '{\n'
    else:
        s += '{ '

    #s += str(ctypes.sizeof(self))

    for fields in self._fields_:
        if len(fields) == 3:
            fname,ftype,bit = fields
        else:
            fname,ftype = fields
            bits = 0

        #print 'looking at self.%s (%s)' % (fname, type(ftype))
        obj = eval("self.%s" % fname)

        if multiline:
            s += '  '*(depth+1)

        s += "'%s': " % fname

        try:
            #s += str(ctypes.sizeof(obj))
            pass
        except TypeError:
            pass

        if (isinstance(obj, Structure) or
           isinstance(obj, Union)):
            if multiline:
                s += '  '*(depth+1) + '\n'

            s += obj.pretty(radix=radix, multiline=multiline, depth=depth+1)
                
            if multiline:
                s += ','
            else:
                s += ', '

        elif isinstance(obj, ctypes.Array):
            #print 'diving into field %s size %d' % (fname, ctypes.sizeof(obj))
            s += "["
            s += ', '.join([obj[i].pretty(radix=radix, multiline=multiline, depth=depth+1) if isinstance(obj[i], Structure) else str(obj[i]) for i in range(len(obj))])
            s += '], '

        elif isinstance(obj, ctypes._SimpleCData):# or isinstance(obj, ctypes._SimpleType):
            if radix == 16:
                s += "0x%x, " % (obj.value)
            else:
                s += "%s, " % (obj.value)

        elif isinstance(obj, int) or isinstance(obj, long):
            if radix == 16:
                s += "0x%x, " % (obj)
            else:
                s += "%s, " % (obj)
        elif isinstance(obj, str):
            s += '%r, ' % (obj)
        elif isinstance(obj, float):
            s += '%.08g, ' % (obj)
        else:
            print "diving into type %s" % type(obj)
            s += obj.pretty(radix=radix, multiline=multiline, depth=depth+1)

        if multiline:
            s += '\n'

    if multiline:
        s += '  '*depth + '}'
    else:
        s += ' }'
    return s


def _s_u_get_bytes(self):
    """ctypes structure -> list of bytes"""
    s = ctypes.string_at(ctypes.addressof(self), ctypes.sizeof(self))
    return map(ord, s)


def _s_u_get_string(self):
    """ctypes structure -> string of bytes"""
    s = ctypes.string_at(ctypes.addressof(self), ctypes.sizeof(self))
    return ''.join(s)


def _s_u_set_bytes(self, bytes):
    """list of bytes -> ctypes structure"""

    # construct a ctypes array with the bytes
    ubyte_arr = (ctypes.c_ubyte*len(bytes))()
    for i in range(len(bytes)):
        ubyte_arr[i] = bytes[i]

    self.set_bytearr(ubyte_arr)


def _s_u_set_bytearr(self, ubyte_arr):
    """ctypes ubyte array -> ctypes structure"""
    
    # figure out how many bytes we can safely move
    fit = min(len(ubyte_arr), self.sizeof())
    
    # copy the memory from the array to the struct - don't try this at home
    ctypes.memmove(ctypes.addressof(self), ubyte_arr, fit)


def _s_u_set_string(self, s):
    """string of bytes -> ctypes structure"""
    self.set_bytes(struct.unpack('%dB' % len(s), s))


def _s_u_sizeof(self):
    """Returns the size of the underlying buffer in bytes."""
    return ctypes.sizeof(self)

def _s_u_get_dict(self):
    """Converts message into hiearchical dictionary of values."""
    return eval(self.pretty())

def _s_u_dump(self):
    return [(f[1], f[0], eval("self.%s" % f[0])) for f in self._fields_]

def _s_u_getitem(self, name):
    return getattr(self, name)

def _s_u_setitem(self, name, value):
    """Typo-checks foo['bar'] = 'baz' style access, although foo.bar = 'baz'
    still gets by."""
    if not hasattr(self, name):
        raise KeyError(name)
    setattr(self, name, value)

class Structure(ctypes.Structure):
    """Clever(?) addons to the ctypes structure class to facilitate application usage."""
    get_bytes = _s_u_get_bytes
    get_string = _s_u_get_string
    set_bytes = _s_u_set_bytes
    set_bytearr = _s_u_set_bytearr
    set_string = _s_u_set_string
    sizeof = _s_u_sizeof
    pretty = _s_u_pretty
    get_dict = _s_u_get_dict
    dump  = _s_u_dump
    __repr__ = _s_u_pretty
    __str__ = _s_u_pretty
    __getitem__ = _s_u_getitem
    __setitem__ = _s_u_setitem


class BigEndianStructure(ctypes.BigEndianStructure):
    """Clever(?) addons to the ctypes structure class to facilitate application usage."""
    get_bytes = _s_u_get_bytes
    get_string = _s_u_get_string
    set_bytes = _s_u_set_bytes
    set_bytearr = _s_u_set_bytearr
    set_string = _s_u_set_string
    sizeof = _s_u_sizeof
    pretty = _s_u_pretty
    get_dict = _s_u_get_dict
    dump  = _s_u_dump
    __repr__ = _s_u_pretty
    __str__ = _s_u_pretty
    __getitem__ = _s_u_getitem
    __setitem__ = _s_u_setitem


class Union(ctypes.Union):
    """Clever(?) add-ons to the ctypes union class to facilitate application usage."""
    get_bytes = _s_u_get_bytes
    get_string = _s_u_get_string
    set_bytes = _s_u_set_bytes
    set_bytearr = _s_u_set_bytearr
    set_string = _s_u_set_string
    sizeof = _s_u_sizeof
    pretty = _s_u_pretty
    get_dict = _s_u_get_dict
    dump  = _s_u_dump
    __repr__ = _s_u_pretty
    __str__ = _s_u_pretty
    __getitem__ = _s_u_getitem
    __setitem__ = _s_u_setitem

# Now that these have been pulled into the Structure and Union classes, we
# don't need them polluting our namespace.
del _s_u_get_bytes
del _s_u_get_string
del _s_u_set_bytes
del _s_u_set_bytearr
del _s_u_set_string
del _s_u_sizeof
del _s_u_pretty
del _s_u_get_dict
del _s_u_dump
del _s_u_getitem
del _s_u_setitem


# Built a better enum?
class Enum(object):
    """Inherit from this class and define your enumerated values as named
    class attributes. Then create a single instance of your subclass to
    present as your public interface. Not to be confused with util.Enum also
    in ucl."""

    def __init__(self):
        forward = {}
        reverse = {}
        for k in dir(self):
            if not k.startswith('_') \
                    and type(getattr(self, k)) is not types.MethodType:
                forward[k] = getattr(self, k)
                reverse[getattr(self, k)] = k
        # Magic to work around __setattr__ being disabled:
        self.__dict__['reverse'] = reverse
        self.__dict__['_forward_'] = forward

    def __setattr__(self, key, value):
        raise RuntimeError, "Can't redefine enum values"

    # Make it look roughly like an immutable dict
    def __getitem__(self, key):
        return getattr(self, key)

    def __iter__(self):
        return iter(self._forward_)
    
    def items(self):
        return self._forward_.items()
    
    def iteritems(self):
        return self._forward_.iteritems()

    def iterkeys(self):
        return self._forward_.iterkeys()

    def itervalues(self):
        return self._forward_.itervalues()
    
    def keys(self):
        return self._forward_.keys()
    
    def values(self):
        return self._forward_.values()

#class _exampleEnum(Enum):
#    foo = 1
#    bar = 2
#    baz = 6
#exampleEnum = _exampleEnum()
#
## Now, possible usage:
#exampleEnum.foo is 1
#exampleEnum['foo'] is 1
#exampleEnum.reverse[1] is 'foo'
#[x for x in exampleEnum] is ['foo', 'bar', 'baz']
#exampleEnum.foo = 2 # raises RuntimeError
