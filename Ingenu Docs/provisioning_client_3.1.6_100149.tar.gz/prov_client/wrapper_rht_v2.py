# Transport Wrapper
# Generic: class TransportWrapper with following methods:
#        egressWrapper that takes message string input and function to call
#            with converted message string
#        ingressWrapper that takes string input and function to call with
#            converted message string.  Note that readFxn does not need to
#            be called with every call to ingressWrapper.  readFxn is
#            allowed to be called only when ingressWrapper has been called
#            a sufficient number of times with a sufficient amount of str
#            data in order to form a complete message.
# ORW Reliable Wrapper specific:
#        egressWrapper prepends a header to the message, which includes a
#            header checksum, then appends another checksum and sends it
#            out.  It sets up a timer that waits for ack of the message.
#            If the timer expires, then possible retransmit occurs.  If
#            acked, then message handling is complete.
#        ingressWrapper looks for valid header (with checksum).  Upon rxing
#            a valid header, it calculates the length of the payload and
#            grabs that much more, plus the appended checksum.  If the data
#            is valid, then it sends an ack and send the payload to the
#            next layer.


import struct
import threading
import random
import util
import datetime

import transport

# diag level - 0 for none, 1 for unexpected events, 2 for
# corrupted/garbled messages & retries, 3 for trace level
# data
DEBUG_LEVEL = 1

# Constants for protocol communication
PROTOCOL_VERSION = 2
HEADER_LENGTH = 6
MAX_MSG_LEN = 64*1024 - HEADER_LENGTH

OPERATION_INIT = 0
OPERATION_ORIGINATE = 1
OPERATION_ACK = 2

# maximum sequence number.  When this number is passed, it rolls back to 1
MAX_TX_SEQ_NUM = 0xF

# maximum number of tx attempts for any message.
MAX_NUM_TX_RETRY = 50

# specifies endianness for packing/unpacking messages
structEndianFormat = '<'

# the following are for testing the protocol and are chances (out of 1.0) that
# the particular phenomenon will occur for any given byte to be transmitted.
#GARBLED_BYTE_CHANCE = 0.001
#LOST_BYTE_CHANCE = 0.001
#EXTRA_BYTE_CHANCE = 0.001
GARBLED_BYTE_CHANCE = 0.0
LOST_BYTE_CHANCE = 0.0
EXTRA_BYTE_CHANCE = 0.0

# timeout length for waiting for reception of ACK after sending msg
ACK_TIMEOUT_SEC = 0.2

# inter-character timeout once some data received
RX_ACTIVITY_TIMEOUT_SEC = 0.08

random.seed()

# Main wrapper Class.
class TransportWrapper():
    def __init__(self, writeFxn, readFxn, logger, exceptionHandler):
        self._lock = threading.Lock()   # in case multiple threads are calling interfaces
        self._writeFxn = writeFxn       # function to call to send data over the connection to the Node
        self._readFxn = readFxn         # function to call when new originate message is received
        self._txSeqNum = None           # current receive sequence number
        self._rxSeqNum = None           # last receive sequence number
        self._rxThisSeqNum = None       # rx sequence number received from input port
        self._txState = "Startup"       # TX state of the Reliable Delivery Protocol
        self._rxSynced = True           # RX state of the Reliable Delivery Protocol
        self._lastTxData = ''           # last un-acked msg that was sent to host
        self._rxPayload = ''            # sliding window for received payload
        self._pendingTxMsg = None       # store tx msg while waiting for init to ack
        self._txRetryCount = 0          # count of number of attempts at tx a msg
        self._txAckTimer = None         # ack timer object
        self._rxActivityTimer = None    # inter-RX timer
        self._ctrlMsgPayload = struct.pack(structEndianFormat + 'HHL', \
                                           8, 0xFFFF, transport.endMarker)
        self._logger = logger
        self._exceptionHandler = exceptionHandler
        self.maxdelta = datetime.timedelta(seconds = ACK_TIMEOUT_SEC*0.8)

        self.debugPrint("TransportWrapper started up")

    def reInit(self):
        if self._txAckTimer:
            self._txAckTimer.cancel()
            
        self._txSeqNum = None           # current receive sequence number
        self._rxSeqNum = None           # last receive sequence number
        self._rxThisSeqNum = None       # rx sequence number received from input port
        self._txState = "Startup"       # TX state of the Reliable Delivery Protocol
        self._rxSynced = True           # RX state of the Reliable Delivery Protocol
        self._lastTxData = ''           # last un-acked msg that was sent to host
        self._rxPayload = ''            # sliding window for received payload
        self._pendingTxMsg = None       # store tx msg while waiting for init to ack
        self._txRetryCount = 0          # count of number of attempts at tx a msg
        self._txAckTimer = None         # ack timer object
        self._rxActivityTimer = None    # inter-RX timer
        self.debugPrint("TransportWrapper re-init")

    def shutdown(self):
        if self._txAckTimer:
            self._txAckTimer.cancel()

    def debugPrint(self, string, level = 3):
        if DEBUG_LEVEL >= level:
            if level == 1:
                self._logger.error('!!!! %s' % string)
            elif level == 2:
                self._logger.warn('**** %s' % string)
            elif level >= 3:
                self._logger.info('     %s' % string)

    def _calcCrc(self, byteString):
        return util.crc16_ccitt(byteString) & 0xFFFF

    def _calcCrcString(self, byteString):
        crcVal = self._calcCrc(byteString)
        return struct.pack( structEndianFormat+"H", crcVal )

    def _timeOutOnAck(self):
        if self._txState == "Startup":
            return
        
        with self._lock:
            self.debugPrint("Timeout waiting for ACK: retry %d" % self._txRetryCount,
                            level = 2)
            if self._txRetryCount >= MAX_NUM_TX_RETRY:
                self.debugPrint("Retry count exceeded, dropping",
                                level = 2)
                if self._txState == "Waiting for init ACK":
                    self._txState = "Startup"
                    if self._pendingTxMsg:
                        # might as well keep trying until upper layer times out
                        self._sendMsg(OPERATION_INIT)
                else:
                    self._txState = "Idle"
            else:
                self._txRetryCount += 1
                self.debugPrint("Retransmission #%d"%self._txRetryCount)
                debugStr = ""
                for c in self._lastTxData:
                    debugStr = debugStr + ("%02x "%ord(c))
                self.debugPrint("Transmit: %s"%debugStr)
                mangledData = self._ChangeRandomData(self._lastTxData, 'TX')
                self._writeFxn(mangledData)
                self._startAckTimer(len(mangledData))

    def _startAckTimer(self, msgLen):
        # bit of a kludge - but assume ack timeout sized for node messages (max ~.5 K),
        # and stretch for larger messages ...
        ackTime = ACK_TIMEOUT_SEC * int((msgLen + 511)/512)
        
        self.maxdelta = datetime.timedelta(seconds = ackTime*0.8)

        self._txAckTimer = threading.Timer(ackTime, self._timeOutOnAck)
        self._txAckTimer.start()
        self._ackStartTime = datetime.datetime.now()
        
    def _formatMsg(self, seqNum, msgType, payload):
        opAndSeqNum = (msgType << 4) | (seqNum & 0xF)

        # header w/o CRC
        hdr = struct.pack(structEndianFormat + 'HBB',
                          len(payload) + HEADER_LENGTH,
                          PROTOCOL_VERSION,
                          opAndSeqNum)
        msgString = hdr + payload
        crcString = self._calcCrcString(msgString)
        return crcString + msgString
        
    def _sendMsg(self, msgType, payload='', seqNum = None ):
        # Build the message
        if msgType==OPERATION_INIT:
            self._txSeqNum = 0
            seqNum = self._txSeqNum
            payload = self._ctrlMsgPayload
            self._txState = "Waiting for init ACK"
            self.debugPrint("Sending INIT msg")
        elif msgType==OPERATION_ORIGINATE:
            seqNum = self._txSeqNum
            self._txState = "Waiting for TX ACK"
            self.debugPrint("Sending ORIGINATE msg")
        elif msgType==OPERATION_ACK:
            self.debugPrint("Sending ACK msg")
            payload = self._ctrlMsgPayload

        msgString = self._formatMsg(seqNum, msgType, payload)

        mangledData = self._ChangeRandomData(msgString, 'TX')

        self._writeFxn(mangledData)
        
        if msgType != OPERATION_ACK:
            self._lastTxData = msgString
            self._txRetryCount = 0
            # start the ACK timeout timer
            self._startAckTimer(len(mangledData))

        debugStr = ""
        for c in msgString:
            debugStr = debugStr + ("%02x "%ord(c))
        self.debugPrint("Transmit: %s"%debugStr)

    def _ChangeRandomData(self, data, direction):
        mangledData = ""
        for c in data:
            randNum = random.random()
            if randNum<=GARBLED_BYTE_CHANCE:
                mangledData = mangledData + chr(int(random.random()*256))
                self.debugPrint("%s: Corrupted byte" % direction, level = 2)
            else:
                randNum -= GARBLED_BYTE_CHANCE
                if randNum<=LOST_BYTE_CHANCE:
                    self.debugPrint("%s: Lost byte" % direction, level = 2)
                else:
                    mangledData = mangledData + c
                    randNum -= LOST_BYTE_CHANCE
                    if randNum<=EXTRA_BYTE_CHANCE:
                        mangledData = mangledData + chr(int(random.random()*256))
                        self.debugPrint("%s: Added byte" % direction, level = 2)
        debugStr = ""
        for c in mangledData:
            debugStr = debugStr + ("%02x "%ord(c))
        self.debugPrint("%s (%d): mangled: %s"%(direction, len(mangledData), debugStr))
        return mangledData

    # egressWrapper is responsible for wrapping a message that is destined for the host.
    # The string passed in is one complete message.
    def egressWrapper(self, msgStr, endpoint = 0):
        if len(msgStr) > MAX_MSG_LEN:
            self.debugPrint( \
                "Message len %u too large (max %u)" % (len(msgStr), MAX_MSG_LEN),
                level = 1)
            return
        
        with self._lock:
            # if upper layer has timed out and queued a new msg while
            # still have a pending one, slam wrapper and start new
            if self._pendingTxMsg or self._txState == "Waiting for TX ACK":
                self.debugPrint("!New msg sent before finished with previous! re-init ...")
                self.reInit()
                
            # check if INIT message needs to be sent
            if self._txState == "Startup" or self._txSeqNum is None:
                self._pendingTxMsg = msgStr     # store the msg to be sent after init is ACKed
                self._sendMsg(OPERATION_INIT)
            elif self._txState == "Waiting for init ACK":
                self._pendingTxMsg = msgStr     # store the msg to be sent after init is ACKed
                self.debugPrint("!New msg while waiting for INIT ACK", level = 1)
            elif self._txState == "Idle":
                self._sendMsg(OPERATION_ORIGINATE, msgStr)
            else:
                self.debugPrint("Error: unknown/unexpected wrapper state %s" % self._txState, level = 1)
            
    # handle a received INIT msg
    def _rxInitMsg(self):
        self.debugPrint("Received INIT msg")
        self._rxSeqNum = 0

    # handle a received ACK
    def _rxAck(self, seqNum):
        self.debugPrint("Received ACK msg")
        if seqNum == self._txSeqNum:
            self._txAckTimer.cancel()
            
            ackEndTime = datetime.datetime.now()
            if ackEndTime - self._ackStartTime > self.maxdelta:
                self.debugPrint('WARNING: long ack time: ' + str(ackEndTime - self._ackStartTime),
                                level = 2)
                
            self._txSeqNum = self._txSeqNum + 1
            if self._txSeqNum > MAX_TX_SEQ_NUM:
                self._txSeqNum = 1
            if self._txState=="Waiting for init ACK" or \
                   self._txState=="Waiting for TX ACK":
                self._txState = "Idle"
            else:
                self.debugPrint('Warning: received ACK in state "%s".' % self._txState, level = 2)

            if self._pendingTxMsg:
                self._txRetryCount = 0
                self._sendMsg(OPERATION_ORIGINATE, self._pendingTxMsg)
                self._pendingTxMsg = None
        else:
            self.debugPrint("    (ACK msg seqNum incorrect: received %s expected %s)" % \
                            (str(seqNum), str(self._txSeqNum)), level = 2)

    def _sendAck(self, seqNum):
        self._sendMsg(OPERATION_ACK, seqNum = seqNum)

    def _resync(self):
        # look through the buffer from the beginning and throw away
        # everything up to and including the first valid footer we find
        for i in xrange(4, len(self._rxPayload)):
            if struct.unpack(structEndianFormat + 'I',
                             self._rxPayload[i-4:i])[0] == transport.endMarker:

                # found a valid footer, discard up through the end of the
                # current footer
                self._rxPayload = self._rxPayload[i:]

                self._rxSynced = True
                return

        # still haven't found a valid footer, so save a 3 byte lookback
        self._rxPayload = self._rxPayload[i-3:]
        
    def _processRx(self):
        if not self._rxSynced:
            self._resync()

        if self._rxSynced:
            if len(self._rxPayload) >= HEADER_LENGTH:
                headerData = self._rxPayload[:HEADER_LENGTH]
                (crc, length, version, opAndseqNum) = \
                    struct.unpack(structEndianFormat + "HHBB", headerData)
                operation = opAndseqNum >> 4
                seqNum = opAndseqNum & 0xF

                # sanity check length - if too large, out of sync ...
                if length > MAX_MSG_LEN or length < 4:
                    self.debugPrint("length invalid: %d" % length, level = 2)
                    self._rxSynced = False
                    return True

                # check if we have payload
                if len(self._rxPayload) >= length:
                    # sanity check message ...
                    
                    # first footer - if wrong, out of sync, try resync
                    footer = struct.unpack(structEndianFormat + "L", \
                                           self._rxPayload[length-4:length])
                    if footer[0] != transport.endMarker:
                        self.debugPrint("footer mismatch: 0x%x" % footer, level = 2)
                        self._rxSynced = False
                        return True

                    # still synced - process rx msg. First sanity check header
                    fail = False
                    if version != PROTOCOL_VERSION:
                        self.debugPrint("Protocol version mismatch! (%d)" % version, level = 2)
                        fail = True
                    calcCRC = self._calcCrc(self._rxPayload[2:length])
                    if calcCRC != crc:
                        self.debugPrint("CRC mismatch: 0x%x v.s. 0x%x" % (calcCRC, crc), level = 2)
                        fail = True
                    if operation != OPERATION_INIT and \
                           operation != OPERATION_ACK and \
                           operation != OPERATION_ORIGINATE:
                        self.debugPrint("unknown operation type: %u" % operation, level = 2)
                        fail = True
                        
                    if fail:
                        self.debugPrint("msg failed: dropping", level = 2)
                        self._rxPayload = self._rxPayload[length:]
                        return True
                    
                    # message looks OK ... process
                    if operation == OPERATION_INIT:
                        self.debugPrint("init")
                        self._rxInitMsg()
                        self._sendAck(seqNum)
                    elif operation == OPERATION_ACK:
                        self.debugPrint("ack")
                        self._rxAck(seqNum)
                    elif operation == OPERATION_ORIGINATE:
                        debugStr = ""
                        for c in self._rxPayload[:length]:
                            debugStr = debugStr + ("%02x " % ord(c))
                        self.debugPrint("Receive: %s" % debugStr)
                        self._sendAck(seqNum)
                        if seqNum != self._rxSeqNum:
                            self._rxSeqNum = seqNum
                            self.debugPrint("Received payload data (length %d): " % length)
                            self._readFxn(self._rxPayload[HEADER_LENGTH:length])
                    else:
                        self.debugPrint("Duplicate: sequence number repeat", level = 2)

                    self._rxPayload = self._rxPayload[length:]

                    # call again in case more than one message ready
                    return True

        # Not enough data to process yet, wait for more
        return False
                
    # ingressWrapper is responsible for unwrapping a message that is received from the host.
    # Each call of this function passes the next bytes in the message.  This function may be
    # called multiple times before a complete message is formed (each call to ingressWrapper
    # is not necessarily a complete message).  It is the responsibility of ingressWrapper to
    # keep track of how much of the message is received.
    #
    # Upon reception of a complete message, ingressWrapper must call readFxn with the
    # unwrapped message.  In the event that no complete message has been received,
    # ingressWrapper does not need to call readFxn.  In the event that one call to
    # ingressWrapper contains two or more complete messages, ingressWrapper must either call
    # readFxn with the concatenated string or must call readFxn multiple times with each part
    # of the data.
    def ingressWrapper(self, str):
        if self._rxActivityTimer: self._rxActivityTimer.cancel()
        
        if len(str) > 0:
            with self._lock:
                mangledData = self._ChangeRandomData(str, 'RX')
                self._rxPayload = self._rxPayload + mangledData
                while self._processRx():
                    pass

        if len(self._rxPayload) > 0:
            # msg in progress, start activity timer
            self._rxActivityTimer = threading.Timer(RX_ACTIVITY_TIMEOUT_SEC, self._timeOutOnRx)
            self._rxActivityTimer.start()

    def _timeOutOnRx(self):
        self.debugPrint('WARNING: RX activity timeout', level = 2)
        self._rxPayload = ''

        # assume next data received will be aligned to frame boundary again
        self._rxSynced = True
