#!/usr/bin/env python

"""Retrieve TX power related cal values for customer manuf. test."""

import signal
import sys

import ucl_nhp
import orwCmdLineParams

def twosComplement(number, numOfBits = 32):
    if number>>numOfBits-1:
        return number - (1<<numOfBits)
    else:
        return number

def main(connection, node_idx):
    node_msg = connection.node(n=node_idx).node_msg
    rsp = connection.sendMsgGetRsp( \
        node_msg.READ_TXPWR_CAL_DATA_REQ(), \
        node_msg.READ_TXPWR_CAL_DATA_RSP, \
        node_idx = node_idx)
    
    if rsp == None:
        raise IOError, "Invalid response."

    print 'FREQ:\t\t\tLOW:\tMID:\tHIGH:'
    print 'maxTxVGA:\t\t%d\t%d\t%d' % \
          (rsp.maxTxVGALow, rsp.maxTxVGAMid, rsp.maxTxVGAHigh)
    print 'max_tx_pwr(dBm):\t%.1f\t%.1f\t%.1f' %\
          (float(twosComplement(rsp.max_tx_pwr_low_freq))/16, \
           float(twosComplement(rsp.max_tx_pwr_mid_freq))/16, \
           float(twosComplement(rsp.max_tx_pwr_high_freq))/16)
    print 'tx_vga35_pwr(dBm):\t%.1f\t%.1f\t%.1f' %\
          (float(twosComplement(rsp.tx_vga35_pwr_low_freq))/16, \
           float(twosComplement(rsp.tx_vga35_pwr_mid_freq))/16, \
           float(twosComplement(rsp.tx_vga35_pwr_high_freq))/16)
    print ''
    print 'temp(deg. C):\tpwr diff(dB):'
    for i in range(10):
        print '%d\t\t%.1f' % (rsp.temperature_pt[i], float(rsp.temp_power_diff_q4[i])/16)

def usage(s = ''):
    """Prints the help text."""

    if s:
        print "Error: %s\n" % s

    print "Usage:  %s [OPTION]" % sys.argv[0]
    print """

Retrieve calibration params related to TX power control, may
be useful for customer manufacturing test.

OPTIONS:

"""
    for usageStr in orwCmdLineParams.usageLong():
        print "    %s" % usageStr

    print "    -h, --help: Prints this help message."

    print """
EXAMPLE:

    %s -d /dev/ttyS0 -b 38400
    """ % sys.argv[0]

if __name__ == '__main__':
    short_opts = "h"
    long_opts  = ["help",]
    (commArgs, extraOptions, args) = \
               orwCmdLineParams.parseParams(sys.argv[1:],short_opts,long_opts)

    for (opt, val) in extraOptions.items():
        if opt in ("-h", "--help"):
            usage()
            sys.exit(0)
        else:
            assert 0, "Unhandled option '%s'." % opt
            
    def signal_handler(signal, frame):
        print 'Ctrl-C: canceled by user'
        if connection != None:
            connection.close()
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)
    
    try:
        connection = ucl_nhp.Connection(commArgs)
    except Exception, err:
        print 'Error opening connection: %s' % err
        usage()
        sys.exit(-1)
        
    try:
        connection.interrogate_nodes(nodes=commArgs["nodeIndex"])
        main(connection, commArgs["nodeIndex"][0])
    except Exception, e:
        print 'Error getting data: %s' % e
        raise
    finally:
        connection.close()
        sys.exit(0)
