# Transport Wrapper
# Generic: class TransportWrapper with following methods:
#        egressWrapper that takes message string input and function to call
#            with converted message string
#        ingressWrapper that takes string input and function to call with
#            converted message string.  Note that readFxn does not need to
#            be called with every call to ingressWrapper.  readFxn is
#            allowed to be called only when ingressWrapper has been called
#            a sufficient number of times with a sufficient amount of str
#            data in order to form a complete message.
# ORW Reliable Wrapper specific:
#        egressWrapper prepends a header to the message, which includes a
#            header checksum, then appends another checksum and sends it
#            out.  It sets up a timer that waits for ack of the message.
#            If the timer expires, then possible retransmit occurs.  If
#            acked, then message handling is complete.
#        ingressWrapper looks for valid header (with checksum).  Upon rxing
#            a valid header, it calculates the length of the payload and
#            grabs that much more, plus the appended checksum.  If the data
#            is valid, then it sends an ack and send the payload to the
#            next layer.


import struct
import zlib
import threading
import random
import time
import sys

# Set this to True to send debug output to standard output
DEBUG_PRINT_ON = False

PAD_TO_8_BYTES = False
TX_EXTRA_8_BYTES = True

# Constants for protocol communication
PROTOCOL_VERSION = 1
HEADER_LENGTH = 12
FOOTER_LENGTH = 4
BYTE_RESERVED = 0

STREAM_TO_HOST = 1

OPERATION_INIT = 0
OPERATION_ORIGINAL = 1
OPERATION_ACK = 2

ENDPOINT_ORW = 0

# maximum sequence number.  When this number is passed, it rolls back to 1
MAX_TX_SEQ_NUM = 0xFF

# maximum number of tx attempts for any message.
MAX_NUM_TX_RETRY = 50

# specifies endianness for packing/unpacking messages
structEndianFormat = '<'

# the following are for testing the protocol and are chances (out of 1.0) that
# the particular phenomenon will occur for any given byte to be transmitted.
GARBLED_BYTE_CHANCE = 0
LOST_BYTE_CHANCE = 0
EXTRA_BYTE_CHANCE = 0

# timeout length for waiting for reception of ACK after sending msg
ACK_TIMEOUT_SEC = 0.4


# Timer class that is instantiated in order to create a thread for waiting for ACK
class TransportWrapperAckTimer(threading.Thread):
    def __init__(self, callback):
        threading.Thread.__init__(self)
        self.daemon = True
        self.timer = threading.Timer(ACK_TIMEOUT_SEC, callback)
        self.timer.start()
    def stop(self):
        self.timer.cancel()
        

# Main wrapper Class.
class TransportWrapper(threading.Thread):
    def __init__(self, writeFxn, readFxn, logger, exceptionHandler):
        self.startTime = time.time()
        #self.debugPrint("TransportWrapper started up")
        threading.Thread.__init__(self)
        self.daemon = True
        self.__lock = threading.Lock()
        self._writeFxn2 = writeFxn      # function to call to send data over the connection to the Node
        self._writeFxn = self.__ChangeRandomData # writeFxn that writeFxn can call (for debug/testing)
        self._readFxn = readFxn         # function to call when new original message is received
        self._txSeqNum = None           # current receive sequence number
        self._rxSeqNum = None           # last receive sequence number
        self._rxThisSeqNum = None       # rx sequence number received from input port
        self._txState = "Startup"       # TX state of the Reliable Delivery Protocol
        self._rxState = "No header"     # RX state of the Reliable Delivery Protocol
        self._lastTxData = ''           # last un-acked msg that was sent to host
        self._rxPayload = ''            # sliding window for received payload
        self._rxMsgChecksum = None      # checksum on received message
        self._txMsgQueue = []           # queue that should be used only to store current msg
                                        #      to tx while waiting for init to ack
        self._txRetryCount = 0          # count of number of attempts at tx a msg
        self._txAckTimer = None         # ack timer object
        self._rxMsgLength = None        # size of entire message to receive
        self._rxEndpoint = 0            # endpoint of the received message
        self._logger = logger
        
    def _breakLock(self):
        if self.__lock != None:
            try:
                self.__lock.release()
                self._logger.warning("Avoided deadlock on mutex")
            except threading.ThreadError:
                pass
        else:
            self._logger.warning("lock was None")

    def shutdown(self):
        if self._txAckTimer:
            self._txAckTimer.stop()

        # Unstick any threads blocked waiting for an ACK.
        self._breakLock()

    def reInit(self):
        if self._txAckTimer:
            self._txAckTimer.stop()

        self._txSeqNum = None           # current receive sequence number
        self._rxSeqNum = None           # last receive sequence number
        self._rxThisSeqNum = None       # rx sequence number received from input port
        self._txState = "Startup"       # TX state of the Reliable Delivery Protocol
        self._rxState = "No header"     # RX state of the Reliable Delivery Protocol
        self._lastTxData = ''           # last un-acked msg that was sent to host
        self._rxPayload = ''            # sliding window for received payload
        self._rxMsgChecksum = None      # checksum on received message
        self._txMsgQueue = []           # queue that should be used only to store current msg
                                        #      to tx while waiting for init to ack
        self._txRetryCount = 0          # count of number of attempts at tx a msg
        self._txAckTimer = None         # ack timer object
        self._rxMsgLength = None        # size of entire message to receive

        # Unstick any threads blocked waiting for an ACK.
        # Since the above state has been reset, anyone already waiting on the
        # lock should behave as though they're starting the connection from
        # scratch.
        self._breakLock()

    def debugPrint(self, str):
        if DEBUG_PRINT_ON==True:
            self._logger.info("**** %5.1f: %s" % (time.time() - self.startTime, str))

    def _calcCrc(self, byteString):
        return zlib.crc32(byteString) & 0xFFFFFFFF

    def _calcCrcString(self, byteString):
        crcVal = self._calcCrc(byteString)
        #return "%c%c%c%c" % ( (crcVal%0x100), (crcVal/0x100)%0x100, (crcVal/0x10000)%0x100, (crcVal/0x1000000)%0x100)
        return struct.pack( structEndianFormat+"L", crcVal )

    def _calcHeader(self, protocolVersion, streamDirection, sequenceNumber, operation, endpoint, payload):
        if len(payload)==0:
            msgLen = HEADER_LENGTH
        else:
            msgLen = HEADER_LENGTH + len(payload) + FOOTER_LENGTH
        headerData = struct.pack( structEndianFormat+"HBBBBBB",
                                              msgLen,
                                              protocolVersion,
                                              streamDirection,
                                              sequenceNumber,
                                              operation,
                                              endpoint,
                                              BYTE_RESERVED )
        headerData = headerData + self._calcCrcString(headerData)
        return headerData

    def _timeOutOnAck(self):
        self.debugPrint("Time out waiting for ACK: %u" % self._txRetryCount)
        if self._txRetryCount>=MAX_NUM_TX_RETRY:
            self._logger.warning("Maximum number of retries attempted without success")
            
            self.reInit()

        else:
            self._txRetryCount = self._txRetryCount+1
            self._startAckTimer()
            self.debugPrint("Retransmission #%d"%self._txRetryCount)

            tempTxData = self._lastTxData
            if PAD_TO_8_BYTES == True:
                while (len(tempTxData) % 8) != 0:
                    #print "pad"
                    tempTxData += chr(0)
            
            debugStr = ""
            for c in tempTxData:
                debugStr = debugStr + ("%02x "%ord(c))
            #self.debugPrint("Transmit:          %s" % debugStr)
            self.debugPrint("Retransmit seq num %u" % self._txSeqNum)
            #print "Transmit:          %s"%debugStr
            self._writeFxn2(tempTxData)

            if TX_EXTRA_8_BYTES == True:
                padding = ""
                for i in xrange(8):
                    padding += chr(0)
                self._writeFxn2(padding)
                
    def _startAckTimer(self):
        self._txAckTimer = TransportWrapperAckTimer(self._timeOutOnAck)

    def _sendMsg(self, msgType, endpoint, payload=''):
        # Build the message
        if msgType==OPERATION_INIT:
            self._txSeqNum = 0
            seqNum = self._txSeqNum
            self.debugPrint("Sending INIT msg")
        elif msgType==OPERATION_ORIGINAL:
            seqNum = self._txSeqNum
            self.debugPrint("Sending ORIGINAL msg with seqNum %d" % seqNum)
        elif msgType==OPERATION_ACK:
            seqNum = self._rxThisSeqNum
            self.debugPrint("Sending ACK msg with seqNum %d" % seqNum)

        headerData = self._calcHeader(PROTOCOL_VERSION, STREAM_TO_HOST, seqNum, msgType, endpoint, payload)
        if payload!='':
            msgData = headerData + payload
            totalData = msgData + self._calcCrcString(msgData)
        else:
            totalData = headerData

        if msgType!=OPERATION_ACK:
            self._lastTxData = totalData
            # start the ACK timeout timer
            self._startAckTimer()

        #print "%u" % (len(totalData), )
        if PAD_TO_8_BYTES == True:
            while (len(totalData) % 8) != 0:
                #print "pad"
                totalData += chr(0)

        debugStr = ""
        for c in totalData:
            debugStr = debugStr + ("%02x "%ord(c))
        #self.debugPrint("Transmit:          %s"%debugStr)
        #self.debugPrint("Transmit seq num %u" % self._txSeqNum)
        #print "Transmit:          %s"%debugStr
        self._writeFxn2(totalData)

        if TX_EXTRA_8_BYTES == True:
            padding = ""
            for i in xrange(8):
                padding += chr(0)
            self._writeFxn2(padding)
            
    def __ChangeRandomData(self, data):
        dataToTx = ""
        for c in data:
            randNum = random.random()
            if randNum<=GARBLED_BYTE_CHANCE:
                dataToTx = dataToTx + chr(int(random.random()*256))
                self.debugPrint("Garbled a byte in the TX stream!")
            else:
                randNum -= GARBLED_BYTE_CHANCE
                if randNum<=LOST_BYTE_CHANCE:
                    self.debugPrint("Lost a byte in the TX stream!")
                else:
                    dataToTx = dataToTx + c
                    randNum -= LOST_BYTE_CHANCE
                    if randNum<=EXTRA_BYTE_CHANCE:
                        dataToTx = dataToTx + chr(int(random.random()*256))
                        self.debugPrint("Inserted an extra byte in the TX stream!")
        debugStr = ""
        for c in dataToTx:
            debugStr = debugStr + ("%02x "%ord(c))
        #self.debugPrint("Actually transmit: %s"%debugStr)
        self._writeFxn2(dataToTx)                        

    # egressWrapper is responsible for wrapping a message that is destined for the host.
    # The string passed in is one complete message.
    def egressWrapper(self, str, endpoint = ENDPOINT_ORW):
        #print "->[" + " ".join(["%02X" % ord(char) for char in str]) + "]"

        # protect with semaphore or at least check here?
        self.__lock.acquire()

        # check if INIT message needs to be sent
        if self._txState == "Startup":
            debugStr = ""
            for c in str:
                debugStr = debugStr + ("%02x " % ord(c))
            #self.debugPrint("Append TX Msg To Queue: %s" % debugStr);
            self._txMsgQueue.append((endpoint, str))     # store the msg to be sent after init is ACKed
            self._txState = "Waiting for init ACK"
            self._txRetryCount = 0
            self._sendMsg(OPERATION_INIT, ENDPOINT_ORW)
        elif self._txState == "Waiting for init ACK":
            self._txMsgQueue.append((append, str))
            self._logger.warn("Warning: tried to send message while waiting for INIT ACK")
        elif self._txState == "Idle":
            # Build the message
            self._txState = "Waiting for init ACK"
            self._txRetryCount = 0
            self._sendMsg(OPERATION_ORIGINAL, endpoint, str)
        elif self._txState == "Waiting for TX ACK":
            self._txMsgQueue.append((endpoint, str))
            self._logger.warn("Warning: tried to send message while waiting for ORIGINAL ACK")
        else:
            self._logger.error("Error: unknown wrapper state")

    # handle a received INIT msg
    def _rxInitMsg(self):
        self.debugPrint("Received INIT msg")
        self._rxSeqNum = 0

    # handle a received ACK
    def _rxAck(self, seqNum):
        self.debugPrint("Received ACK msg for seqNum %d" % self._rxThisSeqNum)
        releaseSemaphore = False
        if self._rxThisSeqNum==self._txSeqNum:
            self._txAckTimer.stop()
            self._txSeqNum = self._txSeqNum + 1
            if self._txSeqNum > MAX_TX_SEQ_NUM:
                self._txSeqNum = 1
            if self._txState=="Waiting for init ACK":
                self._txState = "Idle"
                releaseSemaphore = True
            elif self._txState=="Waiting for TX ACK":
                self._txState = "Idle"
                releaseSemaphore = True
            else:
                self._logger.warn('received ACK in state "%s".' % self._txState)

            if len(self._txMsgQueue)>0:
                # Build the message
                (endpoint, msg) = self._txMsgQueue[0]
                self._txMsgQueue = self._txMsgQueue[1:]
                self._txRetryCount = 0
                self._sendMsg(OPERATION_ORIGINAL, endpoint, msg)
                self._txState = "Waiting for init ACK"
            else:
                if releaseSemaphore:
                    # release semaphore
                    self.__lock.release()
        else:
            self.debugPrint("    (ACK msg seqNum incorrect: received %s expected %s)" % \
                                (str(self._rxThisSeqNum), str(self._txSeqNum)))


    def _sendAck(self, endpoint):
        self._sendMsg(OPERATION_ACK, endpoint)

    def _processRxChar(self, c = "nothing"):
        #self.debugPrint("processRxChar: %02X (%u)" % (ord(c), len(self._rxPayload)))
        if self._rxState == "No header":
            if c != "nothing":
                self._rxPayload = self._rxPayload + c
            if len(self._rxPayload) >= HEADER_LENGTH:
                headerData = self._rxPayload[:8]
                headerCrc = self._rxPayload[8:12]
                if headerCrc == self._calcCrcString(headerData):
                    #self.debugPrint("Received valid header")
                    # successful header
                    (sizeMsg, version, stream, seqNum, operation, endpoint, reserved) = \
                        struct.unpack(structEndianFormat + "HBBBBBB", headerData)
                    self._rxMsgLength = sizeMsg
                    self._rxThisSeqNum = seqNum
                    self._rxEndpoint = endpoint
                    # always accept init messages:
                    if operation == OPERATION_INIT:
                        #self.debugPrint("init")
                        self._rxInitMsg()
                        self._rxPayload = self._rxPayload[HEADER_LENGTH:]
                        self.debugPrint("Sending ACK for INIT message");
                        self._sendAck(self._rxEndpoint)
                    elif operation == OPERATION_ACK:
                        #self.debugPrint("ack")
                        self._rxAck(seqNum)
                        self._rxPayload = self._rxPayload[HEADER_LENGTH:]
                    elif operation == OPERATION_ORIGINAL:
                        #self.debugPrint("orig: %u bytes"  % (self._rxMsgLength, ))
                        self._rxState = "Getting payload"
                    else:
                        self.debugPrint("wtf: %u" % (operation, ))
                else:
                    self.debugPrint("Received invalid CRC on header")
                    self._rxPayload = self._rxPayload[1:]
                    return 1

        elif self._rxState == "Getting payload":
            if c != "nothing":
                self._rxPayload = self._rxPayload + c
            if len(self._rxPayload) >= self._rxMsgLength:
                self._rxMsgChecksum = self._rxPayload[self._rxMsgLength - 4:self._rxMsgLength]
                self._rxState = "No header"
                calcCrc = self._calcCrcString(self._rxPayload[:self._rxMsgLength - 4])
                msgCrc = self._rxMsgChecksum
                #self.debugPrint("calc crc = %02x %02x %02x %02x" % (ord(calcCrc[0]), ord(calcCrc[1]), ord(calcCrc[2]), ord(calcCrc[3])))
                #self.debugPrint("msg crc  = %02x %02x %02x %02x" % (ord(msgCrc[0]), ord(msgCrc[1]), ord(msgCrc[2]), ord(msgCrc[3])))
                if self._rxMsgChecksum == calcCrc:
                    #self.debugPrint("Received valid payload")
                    debugStr = ""
                    for c in self._rxPayload[0:self._rxMsgLength]:
                        debugStr = debugStr + ("%02x " % ord(c))
                    #self.debugPrint("Receive: %s" % debugStr)
                    self.debugPrint("Received ORIG message with seq num %u" % self._rxThisSeqNum);
                    self._sendAck(self._rxEndpoint)
                    if self._rxThisSeqNum != self._rxSeqNum:
                        self._rxSeqNum = self._rxThisSeqNum
                        debugMsg = "Received payload data (length %d): " % (self._rxMsgLength - HEADER_LENGTH - 4, )
                        for c in self._rxPayload[HEADER_LENGTH:self._rxMsgLength - 4]:
                            debugMsg = debugMsg + "%02x " % ord(c)
                        #self.debugPrint("    " + debugMsg)
                        self._readFxn(self._rxPayload[HEADER_LENGTH:self._rxMsgLength - 4], self._rxEndpoint)
                        #print "<-[" + " ".join(["%02X" % ord(char) for char in self._rxPayload[HEADER_LENGTH:self._rxMsgLength - 4]]) + "]"
                    else:
                        self.debugPrint("    (Data received had same sequence number as previous)")
                    self._rxPayload = self._rxPayload[self._rxMsgLength:]
                else:
                    self.debugPrint("Received invalid CRC on payload")
                    self._rxPayload = self._rxPayload[1:]
                    return 1

        return 0

    # ingressWrapper is responsible for unwrapping a message that is received from the host.
    # Each call of this function passes the next bytes in the message.  This function may be
    # called multiple times before a complete message is formed (each call to ingressWrapper
    # is not necessarily a complete message).  It is the responsibility of ingressWrapper to
    # keep track of how much of the message is received.
    #
    # Upon reception of a complete message, ingressWrapper must call readFxn with the
    # unwrapped message.  In the event that no complete message has been received,
    # ingressWrapper does not need to call readFxn.  In the event that one call to
    # ingressWrapper contains two or more complete messages, ingressWrapper must either call
    # readFxn with the concatenated string or must call readFxn multiple times with each part
    # of the data.
    def ingressWrapper(self, str):
        debugStr = ""
        for c in str:
            debugStr = debugStr + ("%02x "%ord(c))
        #print "rx: %s" % debugStr
        for c in str:
            if self._processRxChar(c) == 1:
                self._processRxChar()


