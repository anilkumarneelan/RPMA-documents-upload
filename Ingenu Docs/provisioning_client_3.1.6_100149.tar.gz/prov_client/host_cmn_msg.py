"""Common host message definitions."""

import sys
import os
import ctypes
import struct

sys.path.append(os.path.join('..', 'endpoint_cmn_python'))
import ucl_nhp_msg
import util

import parsePackedDbg

class Message(ucl_nhp_msg.Message):
    """Message class for host interface messages."""

    def pack_header(self):
        self.header.msgType = eval('types.%s' % self.__class__.__name__)
        self.header.msgLen = self.sizeof()

        self._msgType = self.header.msgType
        self._msgLen = self.header.msgLen


Header = ucl_nhp_msg.Header
Footer = ucl_nhp_msg.Footer

class HOST_RESET_NODE(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('key', ctypes.c_uint),
        ('footer', Footer),
    ]


class HOST_RESET_NODE_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('resetAttempted', ctypes.c_uint),
        ('footer', Footer),
    ]

class HOST_VERSION(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]


class HOST_VERSION_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('majorNum', ctypes.c_uint),
        ('minorNum', ctypes.c_uint),
        ('pointNum', ctypes.c_uint),
        ('descriptor', ctypes.c_ubyte*8),
        ('footer', Footer),
    ]


class HOST_SW_UPGR_V1_BEGIN_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('numChunks', ctypes.c_ushort),
        ('imageType', ctypes.c_ushort),
        ('checksum', ctypes.c_uint),
        ('footer', Footer),
    ]


class HOST_SW_UPGR_V1_BEGIN_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('result', ctypes.c_uint),
        ('footer', Footer),
    ]

class HOST_SW_UPGR_V2_BEGIN_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('numBytes', ctypes.c_uint),
        ('checksum', ctypes.c_uint),
        ('footer', Footer),
    ]

class HOST_SW_UPGR_V2_BEGIN_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('result', ctypes.c_uint),
        ('footer', Footer),
    ]


class HOST_SW_UPGR_CHUNK_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('num', ctypes.c_uint),
        ('checksum', ctypes.c_uint),
        ('chunk', ctypes.c_ubyte*256),
        ('footer', Footer),
    ]


class HOST_SW_UPGR_CHUNK_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('result', ctypes.c_uint),
        ('footer', Footer),
    ]


class HOST_SW_UPGR_END_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]


class HOST_SW_UPGR_END_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('result', ctypes.c_uint),
        ('footer', Footer),
    ]


class HOST_ERROR_IND(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('errCode', ctypes.c_uint),
        ('arg1', ctypes.c_uint),
        ('arg2', ctypes.c_uint),
        ('arg3', ctypes.c_uint),
        ('footer', Footer),
    ]

class HOST_DBG_ENABLE(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('enableDbgMsgs', ctypes.c_uint),
        ('footer', Footer),
    ]

class HOST_DBG_STRING_IND(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('num_bytes', ctypes.c_ubyte),
        ('string', ctypes.c_char*128),
        ('pad', ctypes.c_ubyte*3),
        ('footer', Footer),
    ]

    def __str__(self):
        s = self.string[:self.num_bytes]
        return s

class HOST_DBG_PACKED_IND(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]
    
    def __init__(self, *args, **kwargs):
        Message.__init__(self, *args, **kwargs)
        self.debugString = None

    def set_bytes(self, bytes):
        if parsePackedDbg:
            hdr = Header()
            hdr.set_bytes(bytes)
            typ = hdr.msgType
            length = hdr.msgLen
            self.debugString = parsePackedDbg.parseMsg( \
                length, \
                "".join((map(chr,bytes[4:]))), \
                isNodeMsg = False)

    def __str__(self):
        return 'HOST_DBG: ' + self.debugString

class HOST_DBG_FIXED_PARAMS_IND(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('buildstamp_hash', ctypes.c_uint),
        ('linenum', ctypes.c_uint),
        ('filename', ctypes.c_char*64),
        ('params', ctypes.c_uint*3),
        ('footer', Footer),
    ]

    def __str__(self):
        if parsePackedDbg:
            return 'HOST_DBG: ' + parsePackedDbg.parseFixedParamsMsg( \
                str(self.filename), \
                self.linenum, \
                self.buildstamp_hash, \
                self.params)
        else:
            return 'HOST_DBG: %s line %d params %d %d %d' % ( \
                str(self.filename), \
                self.linenum, \
                self.params[0], \
                self.params[1], \
                self.params[2])

class HOST_OPERATING_MODE(Message):
    STANDALONE = 0
    MONITOR = 1
    PASSTHROUGH = 2
    PROTECTED = 3
    
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('operatingMode', ctypes.c_ubyte),
        ('pad', ctypes.c_ubyte*3),
        ('footer', Footer),
    ]

class HOST_APP_ID_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]

class HOST_APP_ID_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('appId', ctypes.c_uint),
        ('footer', Footer),
    ]

class HOST_OVERRIDE_MRQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('overrideMRQ', ctypes.c_uint),
        ('footer', Footer),
    ]

class HOST_HAS_SPI_ARBITRATED_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]

class HOST_HAS_SPI_ARBITRATED_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('arbitrationStatus', ctypes.c_uint),
        ('footer', Footer),
    ]

class HOST_SET_DUT_POWER_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('state', ctypes.c_uint32), # 0 = off, 1 = on
        ('footer', Footer),
    ]

class HOST_SET_DUT_POWER_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]
    
class HOST_USTREAM_CONFIG_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]

class HOST_USTREAM_CONFIG_RSP(Message):
    NUM_STREAMS = 16
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('isResumable', ctypes.c_uint8 * NUM_STREAMS),
        ('isBestEffort', ctypes.c_uint8 * NUM_STREAMS),
        ('footer', Footer),
    ]
    
class HOST_USTREAM_GET_SYNC_STATE_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]

class HOST_USTREAM_GET_SYNC_STATE_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('isInSync', ctypes.c_uint8),
        ('pad', ctypes.c_uint8 * 3),
        ('footer', Footer),
    ]

class HOST_USTREAM_GET_TX_PAUSE_MODE_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]

class HOST_USTREAM_GET_TX_PAUSE_MODE_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('isTxPaused', ctypes.c_uint8),
        ('pad', ctypes.c_uint8 * 3),
        ('footer', Footer),
    ]

class HOST_USTREAM_GET_RX_PAUSE_MODE_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]

class HOST_USTREAM_GET_RX_PAUSE_MODE_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('isRxPaused', ctypes.c_uint8),
        ('pad', ctypes.c_uint8 * 3),
        ('footer', Footer),
    ]

class HOST_USTREAM_GET_DEBUG_REQ(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]

class HOST_USTREAM_GET_DEBUG_RSP(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('footer', Footer),
    ]

    def __init__(self, *args, **kwargs):
        Message.__init__(self, *args, **kwargs)
        self.debugString = ""

    def set_bytes(self, bytes):
        hdr = Header()
        hdr.set_bytes(bytes)
        type = hdr.msgType
        length = hdr.msgLen
        bytes = bytes[4:-4]
        offset = 0
        numTxStreams = bytes[offset]
        offset += 1
        for i in range(0, numTxStreams):
            self.debugString += "tx stream %d\n" % (bytes[offset])
            self.debugString += "msg seq num %d\n" % (bytes[offset+1])
            self.debugString += "num sdus sent %d\n" % ((bytes[offset+2] << 8) | (bytes[offset+3]))
            self.debugString += "num sdus %d\n" % ((bytes[offset+4] << 8) | (bytes[offset+5]))
            self.debugString += "nsync %d\n" % (bytes[offset+6])
            self.debugString += "\n"
            offset += 7

        numRxStreams = bytes[offset]
        offset += 1
        for i in range(0, numRxStreams):
            self.debugString += "rx stream %d\n" % (bytes[offset])
            self.debugString += "msg seq num %d\n" % (bytes[offset+1])
            self.debugString += "num sdus received %d\n" % ((bytes[offset+2] << 8) | (bytes[offset+3]))
            self.debugString += "num sdus %d\n" % ((bytes[offset+4] << 8) | (bytes[offset+5]))
            self.debugString += "\n"
            offset += 6

        txHead = bytes[offset]
        txCount = bytes[offset+1]
        offset += 2
        self.debugString += "tx window head %d count %d\n" % (txHead, txCount)
        for i in range(0, txCount):
            self.debugString += "tx window slot stream %d frag %d last %d tag 0x%x seq %d state %d\n" % (bytes[offset], bytes[offset+1], bytes[offset+2], bytes[offset+3], bytes[offset+4], bytes[offset+5])
            offset += 6

        rxHead = bytes[offset]
        offset += 1
        for i in range(0, 8):
            if (bytes[offset]):
                self.debugString += "rx window slot %d stream %d frag %d last %d seq %d\n" % ((rxHead+i)%16, bytes[offset+1], bytes[offset+2], bytes[offset+3], bytes[offset+4])
                offset += 5
            else:
                self.debugString += "rx window slot %d empty\n" % ((rxHead+i)%16)
                offset += 1

    def __str__(self):
        return 'USTREAM DBG:\n' + self.debugString

    def __repr__(self):
        __str__()

class HOST_USTREAM_TX_ENQUEUE_IND(Message):
    _pack_ = 1
    _fields_ = [
        ('header', Header),
        ('streamId', ctypes.c_uint8),
        ('length', ctypes.c_uint32),
        ('payload', ctypes.c_uint8 * 8),
        ('pad', ctypes.c_uint8 * 3),
        ('footer', Footer),
    ]

def get_msg_for_bytes(bytes):
    """Inspects a list of bytes, returns a message object of the correct
    type if possible (None otherwise)."""

    hdr = Header()
    hdr.set_bytes(bytes)
    typ = hdr.msgType
    length = hdr.msgLen

    for k,v in types.items():
        if v == typ:
            _class = eval(k)
            msg = _class()
            msg.set_bytes(bytes)
            return msg


def get_msg_for_three_tuple(len, type, body):
    """This function takes the output from ser_ctrl_back.getMsg() and reconstructs the message call to get_msg_for_bytes()"""
    string = struct.pack('HH', len, type) + body
    bytes = map(ord, string)
    return get_msg_for_bytes(bytes)
                

def get_msg_name_for_id(id):
    for k,v in types.items():
        if v == id:
            return k


types = util.Enum(
    # from host_msg.h
    """
    /** PC to Host: attempt node reset */
    HOST_CMN_MSG_TYPE_RESET_NODE         = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_TO_ENDPOINT | 0x12,
    /** Host to PC: node reset status */
    HOST_CMN_MSG_TYPE_RESET_NODE_RSP     = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_FROM_ENDPOINT | 0x12,


    /** PC to Host: get host version */
    HOST_CMN_MSG_TYPE_VERSION            = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_TO_ENDPOINT | 0x20,
    /** Host to PC: host version */
    HOST_CMN_MSG_TYPE_VERSION_RSP        = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_FROM_ENDPOINT | 0x20,

    HOST_CMN_MSG_TYPE_OVERRIDE_MRQ  = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_TO_ENDPOINT | 0x21,

    /** PC to Host: begin SW upgrade. */
    HOST_CMN_MSG_TYPE_SW_UPGR_V1_BEGIN_REQ  = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_TO_ENDPOINT | 0x29,
    /** Host to PC: begin SW upgrade response. */
    HOST_CMN_MSG_TYPE_SW_UPGR_V1_BEGIN_RSP  = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_FROM_ENDPOINT | 0x29,
    /** PC to Host: chunk for a SW upgrade. */
    HOST_CMN_MSG_TYPE_SW_UPGR_CHUNK_REQ  = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_TO_ENDPOINT | 0x2A,
    /** Host to PC: chunk for a SW upgrade response. */
    HOST_CMN_MSG_TYPE_SW_UPGR_CHUNK_RSP  = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_FROM_ENDPOINT | 0x2A,
    /** PC to Host: end SW upgrade. */
    HOST_CMN_MSG_TYPE_SW_UPGR_END_REQ    = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_TO_ENDPOINT | 0x2B,
    /** Host to PC: end SW upgrade response. */
    HOST_CMN_MSG_TYPE_SW_UPGR_END_RSP    = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_FROM_ENDPOINT | 0x2B,

    /** PC to Host: Has Spi Arbitrated? */
    HOST_CMN_MSG_TYPE_HAS_SPI_ARBITRATED_REQ = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_TO_ENDPOINT | 0x2C,
    /** Host to PC: Has Spi Arbitrated? response */
    HOST_CMN_MSG_TYPE_HAS_SPI_ARBITRATED_RSP = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_FROM_ENDPOINT | 0x2C,
    HOST_CMN_MSG_TYPE_SET_DUT_POWER_REQ = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_TO_ENDPOINT | 0x2D,
    HOST_CMN_MSG_TYPE_SET_DUT_POWER_RSP = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_FROM_ENDPOINT | 0x2D,

    HOST_CMN_MSG_TYPE_USTREAM_CONFIG_REQ = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_TO_ENDPOINT | 0x2E,
    HOST_CMN_MSG_TYPE_USTREAM_CONFIG_RSP = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_FROM_ENDPOINT | 0x2E,

    HOST_CMN_MSG_TYPE_USTREAM_GET_SYNC_STATE_REQ = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_TO_ENDPOINT | 0x2F,
    HOST_CMN_MSG_TYPE_USTREAM_GET_SYNC_STATE_RSP = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_FROM_ENDPOINT | 0x2F,

    HOST_CMN_MSG_TYPE_USTREAM_GET_DEBUG_REQ = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_TO_ENDPOINT | 0x30,
    HOST_CMN_MSG_TYPE_USTREAM_GET_DEBUG_RSP = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_FROM_ENDPOINT | 0x30,

    HOST_CMN_MSG_TYPE_USTREAM_GET_TX_PAUSE_MODE_REQ = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_TO_ENDPOINT | 0x31,
    HOST_CMN_MSG_TYPE_USTREAM_GET_TX_PAUSE_MODE_RSP = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_FROM_ENDPOINT | 0x31,

    HOST_CMN_MSG_TYPE_USTREAM_GET_RX_PAUSE_MODE_REQ = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_TO_ENDPOINT | 0x32,
    HOST_CMN_MSG_TYPE_USTREAM_GET_RX_PAUSE_MODE_RSP = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_FROM_ENDPOINT | 0x32,

    HOST_CMN_MSG_TYPE_USTREAM_TX_ENQUEUE_IND = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_FROM_ENDPOINT | 0x33,

    /** Host to PC: error in message handling (often unsupported message received) */
    HOST_CMN_MSG_TYPE_ERROR_IND    = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_FROM_ENDPOINT | 0xF0, 

    /** PC to host: enable or disable debug log messages from host */
    HOST_CMN_MSG_TYPE_DBG_ENABLE         = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_TO_ENDPOINT | 0x100, 
    /** Host to PC: string style debug msg */
    HOST_CMN_MSG_TYPE_DBG_STRING_IND     = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_FROM_ENDPOINT | 0x101,
    /** Host to PC: binary packed style debug msg */
    HOST_CMN_MSG_TYPE_DBG_PACKED_IND     = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_FROM_ENDPOINT | 0x102,

    /** PC to host: configure top level host operating mode */
    HOST_CMN_MSG_TYPE_OPERATING_MODE     = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_TO_ENDPOINT | 0x103,

    /** PC to host: request application magic number/app id */
    HOST_CMN_MSG_TYPE_APP_ID_REQ         = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_TO_ENDPOINT | 0x104,
    /** Host to PC: app id response */
    HOST_CMN_MSG_TYPE_APP_ID_RSP         = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_FROM_ENDPOINT | 0x104,

    /** Host to PC: fixed params style debug msg */
    HOST_CMN_MSG_TYPE_DBG_FIXED_PARAMS_IND = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_FROM_ENDPOINT | 0x105,

    /** PC to host: begin SW upgrade request, v2 */
    HOST_CMN_MSG_TYPE_SW_UPGR_V2_BEGIN_REQ  = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_TO_ENDPOINT | 0x106,
    /** Host to PC: begin SW upgrade response. */
    HOST_CMN_MSG_TYPE_SW_UPGR_V2_BEGIN_RSP  = ORW_MSG_HOST_COMMON | ORW_MSG_DIR_FROM_ENDPOINT | 0x106,

    """,
    prefix='HOST_CMN_MSG_TYPE_',
    prepend='HOST_',

    replace=[
        ('ORW_MSG_DIR_TO_ENDPOINT', '0x%04x' % ucl_nhp_msg.ROUTING_FLAG_DIR_HOST_TO_NODE),
        ('ORW_MSG_DIR_FROM_ENDPOINT', '0x%04x' % ucl_nhp_msg.ROUTING_FLAG_DIR_NODE_TO_HOST),
        ('ORW_MSG_ONRAMP', '0x%04x' % ucl_nhp_msg.ROUTING_FLAG_ONRAMP),
        ('ORW_MSG_HOST_COMMON', '0x%04x' % ucl_nhp_msg.ROUTING_FLAG_HOST_COMMON),
        ('ORW_MSG_HOST_SPECIFIC', '0x%04x' % ucl_nhp_msg.ROUTING_FLAG_HOST_SPECIFIC),
    ]
)

messages = []
for name in dir():
    obj = eval(name)
    if hasattr(obj, '__bases__') and issubclass(obj, Message) and not obj is Message:
        # audit of message size and constructability
        size = obj().sizeof()
        assert size % 4 == 0, "Message %s size is %d, not multiple of 4." % (obj, size)
        messages.append(obj)

del name
