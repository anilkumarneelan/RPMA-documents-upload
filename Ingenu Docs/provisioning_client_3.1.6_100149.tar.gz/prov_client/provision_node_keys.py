#!/usr/bin/env python
#
# Copyright (c) 2010. OnRamp Wireless, Inc.
# All rights reserved.
#
# OnRamp Wireless, Inc makes no representations about the suitability of
# this source code for any purpose. This source code is provided "AS IS"
# and without any express or implied warranties, including, without
# limitation, implied warranties of merchantability and fitness for any
# particular purpose.

"""Node Provisioning Tool."""


import time
import sys
import logging
import traceback
import warnings

# ignore PowmInsecureWarning ...
warnings.filterwarnings("ignore", ".*Not using mpz_powm_sec.*")

import ucl_nhp
import orwCmdLineParams
import provisioning_error as p_err
import npt_comm
import gen_keys
import node_utils
import key_utils
import provisioning_version

#
# Globals
#

short_opts = "s:B:L:p:a:ESVFDvh"
long_opts  = ["server=", "batch=", "log=", "config-id=",
              "skip_provisioning",
              "skip_exception", "verbose", "version", "revision", "rev", 
              "force", "debug", "dev", "help",
              "disable-ssl", "ssl-set-server-cert=",
              "ssl-set-client-cert=", "ssl-set-client-cert-passwd="]


###############################################################################
def usage(s = ''):
    """Prints the help/usage text."""
    if s:
        print "Error: %s\n" % s

    print "Usage:  %s [OPTION]" % sys.argv[0]
    print """
NPT (Node Provisioning Tool) program. Communicates with the Local Key Server
over a secure socket connection to retrieve the gateway, code download, and
node root keys for a node connected to an eHost (via serial) or supherHost
(via ethernet). Provisions the keys into the node.

OPTIONS:
"""
    for usageStr in orwCmdLineParams.usageLong():
        print "    %s" % usageStr

    print """
    -s <ip_addr>[:<port>], --server=<ip_addr>[:<port>]
        The IP address or hostname of the provisioning server.
        The TCP port number to connect with provisioning server. Default is 8085.
    -B <batch_num>, --batch=<batch_num>
        The batch number for the current provisioning run. The batch number is
        an arbitrary integer number that can be assigned to each provisioning
        run of one or more nodes for tracking purposes. The batch number should
        be a monotonically increasing unsigned integer. The batch number is
        saved in the provisioning server key database.
    -p <prov_config_id>, --config-id=<prov_config_id>
        Unique ID for the provisioning configuration - 64 bit integer defining
        the target network, application, and configuration.
    -E, --skip_exception
        Skips the clearing of the exception buffer in the node's flash. The
        exception buffer is used to store error messages when a serious error
        occurs for later retrieval. The exception buffer is cleared by default.
    -S, --skip_provisioning
        Skips node key provisioning (programming). Goes through the motions
        but does not actually program the keys.
    --dev
        Generate keys for development security mode. Root key and CDLD keys are
        all zeros. Gateway key is all zeros except for the odd parity bits
        which are set. Developers will need to manually add these keys into the
        keyring file on the KMS.
    --disable-ssl
        Turn off SSL for the provisioning server connection (requires equivalent
        configuration of the server)
    --ssl-set-server-cert=<pem_file>
        Specify server certificate openssl PEM file (default key.pem)
    --ssl-set-client-cert=<pem_file>
        Specify client certificate openssl PEM file (default key.pem)
    --ssl-set-client-cert-passwd=<password>
        Private key access password for the client certificate
    -v, --verbose
        Increase verbosity level.
    -V, --version, --revision
        Display version string, then exit.
    -F, --force
        Forces provisioning even if the flash revision field is invalid.
    -D, --debug
        Prints debug messages to stdout when logging to a file.
    -L <log_file>, --log=<log_file>
        Append debug messages to the log file.
    -h, --help
        Prints this help message.

EXAMPLE:
    %s -d COM1 -s server_ip_addr -p 101 -a raw_node_2_0
    """ % sys.argv[0]


###############################################################################
class DevKeyInterface():
    
    def __init__(self, nodeIntf, nodeId, logger):
        self.nodeIntf = nodeIntf
        self.nodeId = nodeId
        self.logger = logger
        
    def provisionDevKeys(self):
        """Provision security keys for the development mode"""
        
        # generate node keys
        #rootKey = "%08x%08x%08x%08x" % (self.nodeId, self.nodeId,self.nodeId,self.nodeId)
        rootKey = "%08x%08x%08x%08x" % (0, 0, 0, 0)
        gwKey = "%08x%08x%08x%08x%08x%08x" % (0, 0, 0, 0, 0, 0)
        gwCdldKey = "%08x%08x%08x%08x" % (0, 0, 0, 0)
        
        gw_key = \
            [int(gwKey[i:i + 2], 16) for i, x in enumerate(gwKey) if i % 2 == 0 ]        
        
        # Add in odd parity bits as needed.
        for idx, byte in enumerate(gw_key):

            byte = byte & 0x7f
            bytesum = 0
            for i in range(7):
                bytesum += (byte >> i) & 0x1

            # GW key should have odd parity.
            if bytesum & 1:
                # Parity is already odd.
                gw_key[idx] = byte
            else:
                # Parity is even. Set MSB to make it odd.               
                gw_key[idx] = 0x80 | byte
                
        gw_key = ''.join([ "%x" % gw_key[i]  for i, x in enumerate(gw_key)])
        print "Dev mode keys for node: 0x%08x" % self.nodeId
        print "gateway key: 0x%s" % gw_key
        print "gateway_cdld key: 0x%s" % gwCdldKey
        print "node key: 0x%s" % rootKey

        self.nodeIntf.provision_keys( \
            key_utils.convert_hex_string_to_byte_string(rootKey),
            key_utils.convert_hex_string_to_byte_string(gw_key),
            key_utils.convert_hex_string_to_byte_string(gwCdldKey) )

###############################################################################
def provisionNode(nodeIntf, gw_key, cdld_key, kms_pub_key, node_id,
                  config_id, rng = None):
    root_key = gen_keys.gen_device_key(None, None, node_id, rng)

    # Provision the node, but first make sure the node is idle.
    nodeIntf.set_node_idle()
    nodeIntf.provision_keys(root_key, gw_key, cdld_key)
    timestamp = int(time.time())
    
    encryptedNodeKey = npt_comm.EncryptKeyInfo(
        root_key, timestamp, config_id, node_id, kms_pub_key)
    
    return (timestamp, encryptedNodeKey)

###############################################################################
def runProvisioning(ucl_conn, provisioning_server, provisioning_port, batch_num, config_id, 
                    verbosity = 0, logger = None, node_idx = 0,
                    skip_provisioning = False, skip_exception = False, 
                    dev_keys = False, force = False, useSSL=True,
                    server_keyfile='key.pem', client_keyfile='key.pem',
                    client_key_password='onramp'):
    """ Actually do key provisioning """

    if not logger:
        logger = logging.getLogger()

    if not isinstance(logger, logging.Logger):
        raise p_err.ULPProvisioningError( \
            p_err.ErrorCodes.INVALID_LOGGER, target=p_err.CommType.LOCAL_ERROR)
        
    # Connect to the node.
    nodeIntf = node_utils.NodeInterface(ucl_conn, logger, node_idx, verbosity)

    # Query the node for its ID.
    node_id = nodeIntf.get_node_id(force)
    if verbosity > 0:
        logger.info("Node ID is 0x%08x" % node_id)

    # get node type
    node_type = nodeIntf.get_node_type()
    if verbosity > 0:
        logger.info("Node type is %s" % node_type)
        
    if dev_keys:
        devKeyIf = DevKeyInterface( nodeIntf, node_id, logger)
        devKeyIf.provisionDevKeys()
    else:
        srvr = npt_comm.ProvisioningServerInterface(
            logger, provisioning_server, provisioning_port, verbosity >= 2,
            useSSL=useSSL, server_keyfile=server_keyfile,
            client_keyfile=client_keyfile, client_key_password=client_key_password)

        cfg = srvr.getConfig(node_id, node_type, config_id)
        
        if verbosity > 0:
            logger.info("Retrieved config for node 0x%08x" % node_id)
    
        if skip_provisioning:
            if verbosity > 0:
                logger.info("Skipping provisioning of node 0x%08x." % node_id)
        else:
            (timestamp, encryptedNodeKey) = provisionNode(
                nodeIntf, cfg.gw_wide_key, cfg.gw_cdld_key,
                cfg.kms_pub_key, node_id, config_id)

            if verbosity > 0:
                logger.info("provisioned node 0x%08x." % node_id)

            # tell provisioning server about results
            srvr.setDutParams(timestamp, config_id, batch_num, node_id,
                             nodeKey = encryptedNodeKey)
            if verbosity > 0:
                logger.info("params sent to server for node 0x%08x." % node_id)

    if skip_exception:
        if verbosity > 1:
            logger.info("Skipping exception buffer clearing.")
    else:
        if verbosity > 1:
            logger.info("Clearing node exception buffer.")
        nodeIntf.clear_exception_buffer()

    # check whether node claims to have keys
    if not skip_provisioning:
        (major, dummy, dummy, dummy) = nodeIntf.get_node_version()
        if major <= 4:
            # Firmware doesn't support checking if node is provisioned, done
            return
        keyed = nodeIntf.is_node_provisioned()
        if keyed:
            logger.info("Key provisioning of node 0x%08x successful and verified." % node_id)
        else:
            logger.error("Key provisioning of node 0x%08x reported as FAILED." % node_id)
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.VERIFICATION_FAILED)
            
def setupLogger(verbosity, logfile):
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    # set up console handler
    ch = logging.StreamHandler()
    ch.setFormatter(logging.Formatter('%(levelname)s: %(message)s'))
    if verbosity == 1:
        ch.setLevel(logging.WARNING)
    elif verbosity >= 2:
        ch.setLevel(logging.DEBUG)
    else:
        ch.setLevel(logging.CRITICAL)
    logger.addHandler(ch)

    # set up file handler if file specified
    if logfile:
        file_handler = logging.FileHandler(logfile, mode='w')  
        file_handler.setLevel(logging.DEBUG)  
        formatter = logging.Formatter( \
            "%(asctime)s %(levelname)-8s %(filename)-20s %(lineno)-5d: %(message)s")  
        file_handler.setFormatter(formatter)  
        logger.addHandler(file_handler)  
        
    return logger

def cmdLineMain():
    provisioning_server = 'localhost'   # provisioning server IP address or hostname.
    provisioning_port = 8085            # provisioning server port number.
    skip_provisioning = False           # Skip node provisioning.
    skip_exception_clear = False        # Skip exception buffer clearing.
    verbosity = 1                       # Increase verbosity.
    batch_num = 0                       # Provisioning batch number.
    force_flag = False                  # Forces key provisioning when flash rev is invalid.
    log_file = None                     # File for logging all messages.
    dev_keys = False                    # Provision with all 0 keys
    config_id = 0                      # Network + domain ID
    useSSL = True
    server_cert = 'key.pem'
    client_cert = 'key.pem'
    client_cert_passwd = 'onramp'
    
    (commArgs, extraOptions, dummy) = \
        orwCmdLineParams.parseParams(sys.argv[1:],short_opts,long_opts)
    for (opt, val) in extraOptions.items():
        if opt in ("-s", "--server"):
            ipVals = val[-1].split(":")
            provisioning_server = ipVals[0]
            if len(ipVals)==2:
                provisioning_port = int(ipVals[1], 0)
        elif opt in ("-B", "--batch"):
            batch_num = int(val[-1], 0)
        elif opt in ("-p", "--config-id"):
            config_id = int(val[-1], 0)
        elif opt in ("-L", "--log"):
            log_file  = val[-1]
        elif opt in ("-S", "--skip_provisioning"):
            skip_provisioning = True
        elif opt in ("-E", "--skip_exception"):
            skip_exception_clear = True
        elif opt in ("-v", "--verbose"):
            verbosity += len(val)
        elif opt == "--dev":
            dev_keys = True
        elif opt in ("-F", "--force"):
            force_flag = True
        elif opt in ("-V", "--version", "--rev", "--revision"):
            print "Version: %d.%d.%d" % (provisioning_version.VERSION_MAJOR,
                                         provisioning_version.VERSION_MINOR,
                                         provisioning_version.VERSION_BUILD)
            sys.exit(0)
        elif opt in ("-h", "-?", "--help"):
            usage()
            sys.exit(0)
        elif opt == "--disable-ssl":
            useSSL = False
        elif opt == "--ssl-set-server-cert":
            server_cert = val[0]
        elif opt == "--ssl-set-client-cert":
            client_cert = val[0]
        elif opt == "--ssl-set-client-cert-passwd":
            client_cert_passwd = val[0]
        else:
            usage("Invalid option '%s'." % opt)
            sys.exit(-1)

    if dev_keys:
        print "The --dev mode will produce the fixed keys and should\n" + \
            "not be used for production devices. Do you want to proceed? Y/[N]"
        answer = sys.stdin.readline()
        if not answer.lower().strip() == "y":
            sys.exit(0)

    conn = None
    res = -1
    debug = (verbosity >= 2)
    
    try:
        logger = setupLogger(verbosity, log_file)
        conn = ucl_nhp.Connection(commArgs)
        conn.interrogate_nodes(commArgs['nodeIndex'])

        runProvisioning(conn, provisioning_server, provisioning_port, 
                        batch_num, config_id, 
                        verbosity, logger, commArgs['nodeIndex'][-1],
                        skip_provisioning, skip_exception_clear, 
                        dev_keys, force_flag,
                        useSSL = useSSL,
                        server_keyfile = server_cert,
                        client_keyfile = client_cert,
                        client_key_password = client_cert_passwd)

    except p_err.ULPProvisioningError as e:
        if debug:
            traceback.print_exc()
        logger.critical(str(e))
        res = (e.target << 5) | (e.errorCode & 0x1F)
    except IOError:
        if debug:
            traceback.print_exc()
        logger.critical('I/O error')
        res = p_err.ErrorCodes.COMM_FAILURE
    except:
        if debug:
            traceback.print_exc()
        logger.critical('Unknown error: %s' % traceback.format_exc())
        res = p_err.ErrorCodes.UNKNOWN_PROVISIONING_ERROR
    finally:
        if conn:
            conn.close()
    if res != 0:
        sys.exit(res)
    sys.exit(0)
        
###############################################################################
# Main program body.
###############################################################################
if __name__ == "__main__":
    cmdLineMain()

