'''
FILE NAME: transport.py

DESCRIPTION: provides message transport across serial, TCP, ...

(c) Copyright 2010
'''

#########################################################################
###                      Standard/3rd party modules                     #
#########################################################################
import serial
import socket
import struct
import Queue
import util
import threading
import warnings
import select
import time
import datetime
import sys
import os
import errno
import logging
import traceback

#########################################################################
###                      Internal modules                               #
#########################################################################

#########################################################################
###                Externally accessible variable definitions           #
#########################################################################

#########################################################################
###                Module scope variable definitions                    #
#########################################################################
endMarker = 0xA5A5F0F0
DEBUG_LOG = False

_structEndianFormat = '<' # ARM

# Note: avoid using killThreads() to set _termThreads. It's better to use the Connection
# object's kill() method.
_termThreads = False

# For historical reasons this is mixed with higher layer message IDs - kludgy
# but way too late to change.
_ackMsgId = 0x30

# Share one default logger instance for all connection objects
globalLogger = logging.getLogger('transport')
globalLogger.setLevel(logging.INFO)
ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
ch.setFormatter(logging.Formatter('%(asctime)s:%(name)s:%(levelname)s:%(message)s'))
globalLogger.addHandler(ch)

#########################################################################
###                Public function definitions                          #
#########################################################################
class Connection(threading.Thread):
    def __init__(self, conn_type, comm_object, useMax48ByteChunks=False,
                 transportWrapper="", logger=None, errorCallback=None, exceptionHandler = None):
        self.outlog = None
        self.inlog = None
        self.setLogger(logger)
        self.setErrorCallback(errorCallback)
        self.setExceptionHandler(exceptionHandler)
        threading.Thread.__init__(self)
        if conn_type not in ['UART', 'TCP_SINGLE_NODE', 'TCP_MULTI_NODE']:
            self._logger.error('unknown connection type: ' + conn_type)
            raise ValueError
        self.__type = conn_type
        self.__comm_object = comm_object
        self.__rxBuffer = ''
        self.__rspLen = -1
        self.__rspType = -1
        self.__exit = False
        self.__useMax48ByteChunks = useMax48ByteChunks
        self.__extraDataInReceiveBuffer = ""
        self.__transportWrapper = None

        if conn_type == 'TCP_MULTI_NODE':
            # assume superhost with 16 nodes
            num_nodes = 16
        else:
            num_nodes = 1

        # need to become per-node for multi-node connections
        self.__lock = [threading.Lock() for i in xrange(num_nodes)]
        self.__msgQueue = [Queue.Queue(-1) for i in xrange(num_nodes)]
        self.__ackEvent = [threading.Event() for i in xrange(num_nodes)]
        self.__newMsgEvent = threading.Event()
        self.closeLock = threading.Lock()
        self.socketLock = threading.Lock()

        # note recursive lock
        self.readLock = threading.RLock()

        if DEBUG_LOG:
            self.outlog = open('outlog.bin', 'wb')
            self.inlog = open('inlog.bin', 'wb')

        self.__setupWrapper(transportWrapper)
        
        self.start()

    def __shutdownWrapper(self):
        if self.__transportWrapper != None:
            if hasattr(self.__transportWrapper, 'shutdown'):
                # shutdown transport wrappers that implement shutdown
                self.__transportWrapper.shutdown()
            self.__transportWrapper = None

    def __setupWrapper(self, transportWrapper):
        # ask existing wrapper to shutdown since we're about to replace it
        self.__shutdownWrapper()

        if transportWrapper != "":
            try:
                # use "," as the delimiter for optional subwrapper short name
                wrapArgs = transportWrapper.split(",")

                # all optional transport wrappers go in directory transport_wrappers or 
                # CWD and havefile name of format wrapper_*.py
                try:
                    wrapMod = __import__("transport_wrappers.wrapper_" + wrapArgs[0],
                                         globals(), locals(), [[]])

                except ImportError:
                    wrapMod = __import__("wrapper_" + wrapArgs[0],
                                         globals(), locals(), [[]])

                if len(wrapArgs) == 1:
                    self.__transportWrapper = \
                        wrapMod.TransportWrapper(self.__write,
                                                 self.__addToRxQueue,
                                                 self._logger,
                                                 self._exceptionHandler)
                else:
                    self.__transportWrapper = \
                        wrapMod.TransportWrapper(self.__write,
                                                 self.__addToRxQueue,
                                                 self._logger,
                                                 self._exceptionHandler,
                                                 subwrapper=wrapArgs[1])

                if "egressWrapper" not in dir(self.__transportWrapper):
                    errStr = wrapArgs[0] + ' does not have proper "egressWrapper" method'
                    raise ValueError(errStr)
                elif "ingressWrapper" not in dir(self.__transportWrapper):
                    errStr = wrapArgs[0] + ' does not have proper "ingressWrapper" method'
                    raise ValueError(errStr)
            except:
                errStr = '"%s" not valid transport wrapper' % transportWrapper
                traceback.print_exc()
                raise ValueError(errStr)
        else:
            self.__transportWrapper = None

    def __str__(self):
        if self.__type.startswith('TCP'):
            ip, port = self.__comm_object.getpeername()
            return "<%s(%s:%s)>" % (self.__class__.__name__, ip, port)
        else:
            return "<%s(%s)>" % (self.__class__.__name__, self.__comm_object)


    def __addToRxQueue(self, msg, endpoint = 0):
        self.__extraDataInReceiveBuffer = self.__extraDataInReceiveBuffer + msg

    def __read(self, maxLength, timeout):
        # if any data put in queue by wrapper from previous read, then first drain that
        if len(self.__extraDataInReceiveBuffer) > 0:
            ret = self.__extraDataInReceiveBuffer[:maxLength]
            self.__extraDataInReceiveBuffer = self.__extraDataInReceiveBuffer[maxLength:]
            return ret
        else:
            ret = ''
            if self.__type == 'UART':
                self.__comm_object.timeout = timeout
                ret = self.__comm_object.read(1)
                extra = self.__comm_object.inWaiting()
                if extra > 0:
                    if extra > maxLength - 1:
                        extra = maxLength - 1
                    ret += self.__comm_object.read(extra)
            elif self.__type == 'TCP_SINGLE_NODE' or self.__type == 'TCP_MULTI_NODE':
                (r, w, x) = select.select([self.__comm_object,], [], [], timeout)
                if len(r) > 0:
                    try:
                        ret = self.__comm_object.recv(maxLength)
                    except socket.timeout:
                        pass
            if self.inlog:
                self.inlog.write(ret)
                self.inlog.flush()
            if self.__transportWrapper != None:
                self.__transportWrapper.ingressWrapper(ret)
                ret = ''

            return ret

    def __write(self, byte_string):
        if not self.__comm_object:
            return
        try:
            self.socketLock.acquire()
            if self.__type == 'UART':
                #!dh send in 48 byte (MAX) chunks with small delay/flush in between chunks
                # work around for FTDI USB Serial framing error
                # david howard
                if self.__useMax48ByteChunks==True:
                    for i in range(0, len(byte_string), 48):
                        #time.sleep(0.02)
                        self.__comm_object.write(byte_string[i:i+48])
                        if self.outlog:
                            self.outlog.write(byte_string[i:i+48])
                        self.__comm_object.flush()
                else:
                    self.__comm_object.write(byte_string)
                    if self.outlog:
                        self.outlog.write(byte_string)
            elif self.__type == 'TCP_SINGLE_NODE' or self.__type == 'TCP_MULTI_NODE':
                assert self.__comm_object.sendall(byte_string) == None
                if self.outlog:
                    self.outlog.write(byte_string)
                

        finally:
            if self.outlog:
                self.outlog.flush()
            self.socketLock.release()

    def __del__(self):
            if self.outlog:
                self.outlog.close()
            try:
                threading.Thread.__del__(self)
            except AttributeError:
                # as the threads and interpreter are shutting down some modules
                # (threading, in this case) may no longer be accessible and result
                # in AttributeErrors when attempted.
                pass

    def __getMsgLocal(self, timeout):
        # we handle messages that are split across calls. See if we
        # have a message header yet ...
        if self.__type == 'TCP_MULTI_NODE':
            hdrLen = 8
        else:
            hdrLen = 4
        if (self.__rspLen == -1 and self.__rspType == -1):
            # no message header - try to get it.
            self.__rxBuffer = self.__rxBuffer + self.__read(1024, timeout)
            if len(self.__rxBuffer) < hdrLen:
                # timeout - we'll try again later
                return
            if self.__type == 'TCP_MULTI_NODE':
                (self.__nodeId, self.__rspLen, self.__rspType) = \
                        struct.unpack(_structEndianFormat + 'LHH', self.__rxBuffer[:hdrLen])
            else:
                self.__nodeId = 0
                (self.__rspLen, self.__rspType) = \
                        struct.unpack(_structEndianFormat + 'HH', self.__rxBuffer[:hdrLen])
            self.__rxBuffer = self.__rxBuffer[hdrLen:]
        msgSize = self.__rspLen - hdrLen
        if len(self.__rxBuffer) < msgSize:
            self.__rxBuffer = self.__rxBuffer + self.__read(1024, timeout)
        if len(self.__rxBuffer) < msgSize:
            # timeout - we'll try again later
            return

        # resync logic
        # do footer detection *only* if the user has specified an error
        # callback, otherwise legacy behavior is to assume all data is good
        if (self._errorCallback and
            struct.unpack(_structEndianFormat + 'I',
                          self.__rxBuffer[msgSize-4:msgSize])[0] != endMarker):
            # footer is bad
            # look through the buffer from the beginning and throw away
            # everything up to and including the first valid footer we find
            for i in xrange(4, len(self.__rxBuffer)):
                if struct.unpack(_structEndianFormat + 'I',
                                 self.__rxBuffer[i-4:i])[0] == endMarker:

                    # found a valid footer, discard up through the end of the
                    # current footer
                    self.__rxBuffer = self.__rxBuffer[i:]

                    # prepare for new message
                    self.__rspLen = -1
                    self.__rspType = -1
                    self.__nodeId = -1

                    # return, retry for the next message on the next call
                    self._errorCallback(isInSync=True, bytesDiscarded=i)
                    return

            # still haven't found a valid footer, so save a 3 byte lookback
            self.__rxBuffer = self.__rxBuffer[i-3:]

            # return to wait for more data
            self._errorCallback(isInSync=False, bytesDiscarded=i-3)
            return

        # all right, we have a message.
        # ACKs are handled at this level v.s. other messages
        if self.__rspType == _ackMsgId:
            self.__ackEvent[self.__nodeId].set()
        else:
            if hdrLen == 8:
                # we've stripped node id, adjust length
                self.__rspLen -= 4
            self.postMsg((self.__rspLen, self.__rspType, self.__rxBuffer[:msgSize]), self.__nodeId)

        self.__rxBuffer = self.__rxBuffer[msgSize:]

        # start new message
        self.__rspLen = -1
        self.__rspType = -1
        self.__nodeId = -1

    def postMsg(self, msgTuple, nodeIdx):
            self.__msgQueue[self.__nodeId].put(msgTuple)
            self.__newMsgEvent.set()
        

    def __getAck(self, cmd, timeout, node_idx):
        # remove this next line because race condition can cause the clear to clear out the flag
        # after it has been legitimately set.  This can happen if the write in sendPackedMsg occurs
        # and __getAck is not called by the time the ACK is received.  This can happen especially
        # in the case that chunking is used.
        #self.__ackEvent[node_idx].clear()
        self.__ackEvent[node_idx].wait(timeout)
        if not self.__ackEvent[node_idx].isSet():
            self._logger.warning('ack failed (msg id %d (%d s), %s, node %d @ %s)' % \
                  (cmd, timeout, self, node_idx, time.ctime()))
            return False
        self.__ackEvent[node_idx].clear()
        return True

    def run(self):
        try:
            while not _termThreads and not self.__exit:
                self.readLock.acquire()
                # check for thread termination etc every 0.1 second.
                self.__getMsgLocal(0.1)
                self.readLock.release()
                # allow other threads to process and acquire lock
                # if needed.
                time.sleep(0)
        except BaseException as e:
            if not self.__exit:
                traceStr = traceback.format_exc()
                self._logger.warning(traceStr)
                if self._exceptionHandler:
                    self._exceptionHandler(e, traceStr)
                self.close()
        self._logger.debug('transport RX thread exiting')

    def kill(self):
        self.__exit = True

    def close(self):
        self.kill()
        if self.__comm_object != None:
            self.closeLock.acquire()
            if hasattr(self.__comm_object, 'isOpen') and self.__comm_object.isOpen():
                self.__comm_object.close()
            elif hasattr(self.__comm_object, 'shutdown'):
                # per socket documentation, need to shutdown then close
                self.__comm_object.shutdown(socket.SHUT_RDWR)
                self.__comm_object.close()
            self.__comm_object = None
            self.closeLock.release()

        self.__shutdownWrapper()

    def setLogger(self, logger):
        if isinstance(logger, logging.Logger):
            self._logger = logger
        elif logger is None:
            # No preconfigured logger passed in; default to info -> console
            self._logger = globalLogger
        else:
            raise ValueError("Must provide a logging.Logger instance")

    def setErrorCallback(self, errorCallback):
        self._errorCallback = errorCallback

    def setExceptionHandler(self, exceptionHandler):
        self._exceptionHandler = exceptionHandler

    def reInitWrapper(self, newWrapper = None):
        self.readLock.acquire()

        if newWrapper:
            self.__setupWrapper(newWrapper)
        if self.__transportWrapper:
            self.__transportWrapper.reInit()
        self.flushData()

        self.readLock.release()
        
    def sendPackedMsg(self, msg_id, byte_string, timeout = 20.0, node_idx = 0, endpoint = 0):
        """Sends a pre-packed message to the node and returns the ack."""
        # add node ID if multi-node
        if self.__type == 'TCP_MULTI_NODE':
            # reformat header appropriately ...
            (msgLen, ) = struct.unpack(_structEndianFormat + 'H', byte_string[:2])
            msgLen += 4
            byte_string = \
                        struct.pack(_structEndianFormat + 'LH', node_idx, msgLen) + \
                        byte_string[2:]

        self.__lock[node_idx].acquire()
        # Moved the clear from beginning of _getAck to here since we need to guarantee that
        # the flag is being cleared before ACK is received.  This can happen only by clearing
        # the flag before sending the original msg.  It is done at this line to minimize the
        # amount of time between clearing the ack flag and sending the message.
        self.__ackEvent[node_idx].clear()
        if self.__transportWrapper != None:
            self.__transportWrapper.egressWrapper(byte_string, endpoint = endpoint)
        else:
            self.__write(byte_string)
        response = self.__getAck(msg_id, timeout, node_idx)
        self.__lock[node_idx].release()
        return response

    def sendMsg(self, msg, timeout = 20.0, node_idx = 0, retries=0):
        """Sends message objects.

        Messages will be retried if retries is non-zero (-1 for infinitely)"""

        warnings.warn("Deprecated - use ucl_nhp.sendMsg() instead", DeprecationWarning)

        acked = False

        while not acked:
            acked = self.sendPackedMsg(msg._msgType, msg.get_string(), timeout=timeout, \
                                       node_idx=node_idx)

            if not retries:
                break
            else:
                retries -= 1

        return acked

    def sendMsgGetRsp(self, req, rsp, timeout=0.1, node_idx=0):
        """Combines sendMsg with getMsgById."""

        warnings.warn("Deprecated - use ucl_nhp.sendMsgGetRsp() instead", DeprecationWarning)

        # bit of a hack - allow the user to increase timeout above
        # defaults, but allow minimal ID timeout ... should really be
        # two params.
        if timeout > 20:
            self.sendMsg(req, timeout=timeout, node_idx=node_idx)
        else:
            self.sendMsg(req, node_idx=node_idx)
        return self.getMsgById(rsp, timeout=timeout, node_idx=node_idx)

    def getMsgById(self, rsp, timeout=0.1, node_idx=0):
        """Reads any messages coming from the connection and returns the first
        message with a type that matches rsp.

        Non-matching messages are dropped."""

        warnings.warn("Deprecated - use ucl_nhp.getMsgById() instead", DeprecationWarning)

        try:
            import host_msg
        except ImportError:
            self._logger.error('Attempt to use getMsgById() without host_msg.py')
            return None
            
        try: # extract message ID from the class
            _type = rsp()._msgType
        except AttributeError: # some people may erroneously pass a message object
            _type = rsp._msgType
        except TypeError: # some people may still want to pass numeric message ID's
            _type = rsp

        # TODO: Add timeout for the while loop.
        rsp_type = None
        while rsp_type != _type:
            (rsp_len, rsp_type, rsp_body) = self.getMsg(timeout=timeout, node_idx=node_idx)

        msg = host_msg.get_msg_for_three_tuple(rsp_len, rsp_type, rsp_body)

        return msg

    def getPackedMsg(self, timeout = 20.0, node_idx = 0):
        """
        DESCRIPTION:
        Get message from target

        RETURN VALUE:
        Message tuple.

        SIDE EFFECTS:
        None.
        """
        
        try:
            return self.__msgQueue[node_idx].get(True, timeout)
        except Queue.Empty:
            return (-1, -1, -1)
        
    def getMsg(self, timeout = 20.0, node_idx = 0):
        """
        DESCRIPTION:
        Obsolete - name change to getPackedMsg()
        """
        warnings.warn("Deprecated - use getPackedMsg() instead", DeprecationWarning)

        return self.getPackedMsg(timeout = timeout, node_idx = node_idx)


    def getPackedMsgAnyNode(self, timeout = 20.0):
        """
        DESCRIPTION:
        Get message from any connected target

        RETURN VALUE:
        Message tuple.

        SIDE EFFECTS:
        None.
        """
        self.__newMsgEvent.clear()

        timeouttime = time.time() + timeout
        # keep trying as other threads could be competing
        while time.time() < timeouttime:
            for node in xrange(16):
                try:
                    (rspLen, rspType, msg) = self.__msgQueue[node].get(True, 0)
                    return (node, rspLen, rspType, msg)
                except Queue.Empty:
                    pass
            remtime = timeouttime - time.time()
            if (remtime > 0):
                self.__newMsgEvent.wait(remtime)
        return (-1, -1, -1, -1)

    def getMsgAnyNode(self, timeout = 20.0):
        """
        DESCRIPTION:
        Obsolete - name change to getPackedMsg()
        """
        warnings.warn("Deprecated - use getPackedMsgAnyNode() instead", DeprecationWarning)
        return self.getPackedMsgAnyNode(timeout = timeout)
        
    def resetTermThreadsFlag(self):
        global _termThreads
        _termThreads = False

    def getSerialPortRef(self):
        """
        Provide serial port object to higher layer - set config, use
        extra signals for control/status lines, etc
        """
        if self.__type == 'UART':
            return self.__comm_object
        return None

    def flushData(self):
        """Flush data and force synch'ed state"""
        self.readLock.acquire()
        self.__rxBuffer = ''
        self.__rspLen = -1
        self.__rspType = -1
        self.__extraDataInReceiveBuffer = ""
        if hasattr(self.__comm_object, 'flushInput'):
            self.__comm_object.flushInput()
            self.__comm_object.flushOutput()
        self.readLock.release()
        
def initSerial(ser_device, useMax48ByteChunks = False, baudRate = 115200,
               rtrctsFlowControl=False, transportWrapper="", logger=None,
               errorCallback=None, rtsToggle = False):
    """Create UART type connection object"""

    # 5 sec response timeout
    port = serial.Serial(ser_device, baudRate, timeout=5, xonxoff=0, rtscts=rtrctsFlowControl)
    port.flushInput()
    port.flushOutput()
    if rtsToggle:
        port.rtsToggle = True

    connection = Connection('UART', port, useMax48ByteChunks, transportWrapper,
                            logger=logger, errorCallback=errorCallback)

    return connection

def initTCPSingleNode(ip_addr, port = 7, logger=None, errorCallback=None):
    """Create TCP without node ID in protocol type connection object"""

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    #sock.setsockopt(SOL_TCP, TCP_NODELAY, 1)
    sock.connect((ip_addr, port))
    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    connection = Connection('TCP_SINGLE_NODE', sock, logger=logger,
                            errorCallback=errorCallback)

    return connection

def initTCPMultiNode(ip_addr, port = 7, logger=None, errorCallback=None):
    """Create TCP with node ID in protocol type connection object (superhost)"""

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((ip_addr, port))
    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)

    connection = Connection('TCP_MULTI_NODE', sock, logger=logger,
                            errorCallback=errorCallback)

    return connection

def initConnection(commArgs, logger=None, errorCallback=None):
    # set up a serial comm port
    if ("ip" not in commArgs) and ("serial" in commArgs):
        if "chunking" not in commArgs:
            commArgs["chunking"] = [False]
        if "flowControl" not in commArgs:
            commArgs["flowControl"] = [False]
        transportWrapper = ""
        if "wrapper" in commArgs:
            transportWrapper = commArgs["wrapper"][-1]
        rtsToggle = False
        if "rtsToggle" in commArgs:
            rtsToggle = True
        if "baud" in commArgs:
            connection = initSerial(commArgs["serial"][-1],
                                    useMax48ByteChunks=commArgs["chunking"][-1],
                                    baudRate=commArgs["baud"][-1],
                                    rtrctsFlowControl=commArgs["flowControl"][-1],
                                    transportWrapper=transportWrapper,
                                    logger=logger,
                                    rtsToggle = rtsToggle,
                                    errorCallback=errorCallback)
        else:
            connection = initSerial(commArgs["serial"][-1],
                                    useMax48ByteChunks=commArgs["chunking"][-1],
                                    rtrctsFlowControl=commArgs["flowControl"][-1],
                                    transportWrapper=transportWrapper,
                                    logger=logger,
                                    rtsToggle = rtsToggle,
                                    errorCallback=errorCallback)

    # set up TCP IP socket
    elif ("ip" in commArgs) and ("serial" not in commArgs):
        if ("portNumber" in commArgs):
            connection = initTCPSingleNode(commArgs["ip"][-1],
                                           port=commArgs["portNumber"][-1],
                                           logger=logger,
                                           errorCallback=errorCallback)
        else:
            connection = initTCPMultiNode(commArgs["ip"][-1],
                                          logger=logger,
                                          errorCallback=errorCallback)

    else:
        raise ValueError("Either serial comm or IP address must be specified.")

    return connection

# Useful for gracefully killing threads under Windows
def killThreads(verbosity = 0):
    global _termThreads
    warnings.warn("Deprecated - use Connection object method 'kill()' instead.", DeprecationWarning)
    if verbosity:
        # Deprecated function, awkward interface with verbosity parameter,
        # and no link to the specific Connection object in question; leave as
        # print rather than changing to a logger
        print 'Killing transport threads'
    _termThreads = True

