#!/usr/bin/env python
#
# Copyright (c) 2010. OnRamp Wireless, Inc.
# All rights reserved.
#
# OnRamp Wireless, Inc makes no representations about the suitability of
# this source code for any purpose. This source code is provided "AS IS"
# and without any express or implied warranties, including, without
# limitation, implied warranties of merchantability and fitness for any
# particular purpose.

"""ULP eNode Configuration Flash Programming Utility. Reads in the specified
   node configuration text file, such as 'node_config.txt', using the
   'config_block_v*.py' scripts and programs the node's flash configuration sector
   with the specified configuration values."""

import sys
sys.path.append('provisioning')
import traceback
import logging

import orwCmdLineParams
import provisioning_error as p_err

def usage(s=''):
    """Prints the help/usage text."""
    if s:
        print "Error: %s\n" % s

    print "Usage:  %s [OPTION]" % sys.argv[0]
    print """
Node configuration flash sector programming utility. Imports the user settable
node configuration parameters and programs the configuration sector in flash.

OPTIONS:
"""
    for usageStr in orwCmdLineParams.usageLong():
        print "    %s" % usageStr

    print """    -C <node_config_file>, --config=<node_config_file>
        The text file containing the node configuration parameters that can
        be modified by the user.
    -V, --verify
        Read back and verify the node configuration parameter values.
    -v, --verbose
        Increase verbosity level.
    -D, --debug
        Prints debug messages to stdout.
    -L <log_file>, --log=<log_file>
        Log debug messages to the log file in append mode.
    -h, --help
        Prints this help message.

EXAMPLE:
    %s -d COM1 -C node_config.txt
    """ % sys.argv[0]

class nodeConfigurator():
    def __init__(self, connection, node_idx = 0, logger = None):
        self.conn = connection
        self.node_idx = node_idx
        self.node_msg = connection.node(n=node_idx).node_msg

        if isinstance(logger, logging.Logger):
            self._logger = logger
        elif logger is None:
            # No preconfigured logger passed in; default to info -> console
            self._logger = logging.getLogger()
            ch = logging.StreamHandler()
            self._logger.setLevel(logging.INFO)
            ch.setLevel(logging.INFO)
            ch.setFormatter(logging.Formatter())
            self._logger.addHandler(ch)
        else:
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.INVALID_LOGGER, \
                target=p_err.CommType.LOCAL_ERROR)

    def read_node_ap_list_flash(self):
        """Reads and returns the node's AP list in flash."""
        
        msg = self.conn.sendMsgGetRsp(self.node_msg.READ_FLASH_AP_LIST_REQ(),
                                      self.node_msg.READ_FLASH_AP_LIST_RSP,
                                      node_idx = self.node_idx )
        if msg is None:
            self._logger.error("READ_FLASH_AP_LIST_RSP timeout")
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.COMM_FAILURE)
        
        return msg.apList

    def read_node_config_flash(self):
        """Reads and returns the node's configuration flash sector."""
        msg = self.conn.sendMsgGetRsp(self.node_msg.READ_FLASH_CONF(),
                                      self.node_msg.READ_FLASH_CONF_RSP,
                                      node_idx = self.node_idx )
        if msg is None:
            self._logger.error("READ_FLASH_CONF_RSP timeout")
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.COMM_FAILURE)
      
        cfg_version = msg.configData.v3.version
        if hasattr(msg.configData, "v%d" % cfg_version):
            # Return the flash configuration union, not one of the union elements.
            return msg.configData
      
        self._logger.info("Unknown flash configuration version %d" % cfg_version)
        raise p_err.ULPProvisioningError(p_err.ErrorCodes.UNKNOWN_CONF_VERSION)

    def read_node_config_file(self, cfg_file_name):
        # Read in the node configuration parameters.
        try:
            cfg_dict = self.config_block.parse_file(cfg_file_name)
        except Exception, e:
            errText = "Error parsing configuration file '%s'.\n" % cfg_file_name
            errText += str(e)
            self._logger.error(errText)
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.CONF_FILE_INVALID, extraInfo = errText)

        # Validate the node configuration parameters.
        try:
            cfg_dict = self.config_block.validate(cfg_dict)
        except Exception, e:
            errText = "Invalid configuration value: "
            errText += str(e)
            self._logger.error(errText)
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.CONF_FILE_INVALID, extraInfo = errText)

        self._logger.info("Configuration data validated.")

        return cfg_dict

    def program_node_config_flash(self, cfg_dict):
        """Programs the node's configuration flash sector using the parameter values
           specified in the configuration file."""

        # Put the validated configuration parameters into a structure.
        cfg_data = self.config_block.get_cfg_data_struct(cfg_dict, self.node_msg)
        ap_list  = self.config_block.get_ap_list_struct(cfg_dict, self.node_msg)

        ack = self.conn.sendMsg(self.node_msg.WRITE_FLASH_CONF(configData = cfg_data),
                                node_idx = self.node_idx )
        if not ack:
            self._logger.error("Failed to get ACK for WRITE_FLASH_AP_LIST_REQ request.")
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.COMM_FAILURE)
        
        if cfg_dict['flash_config_version'] > 3:
            ack = self.conn.sendMsg(self.node_msg.WRITE_FLASH_AP_LIST_REQ(apList = ap_list),
                                    node_idx = self.node_idx )
            if not ack:
                self._logger.error("Failed to get ACK for WRITE_FLASH_AP_LIST_REQ request.")
                raise p_err.ULPProvisioningError( \
                    p_err.ErrorCodes.COMM_FAILURE)

        self._logger.info("Finished writing configuration to flash.")

        return (cfg_data, ap_list)        


    def discoverConfigVersion(self):
        rsp = self.conn.sendMsgGetRsp(self.node_msg.GET_VERSION_REQ(),
                                      self.node_msg.GET_VERSION_RSP,
                                      node_idx = self.node_idx )
        
        if rsp is None:
            self._logger.error("Failed to get GET_VERSION_RSP message.")
            raise p_err.ULPProvisioningError( \
                p_err.ErrorCodes.COMM_FAILURE)
           
        self._logger.info("got node version %d.%d.%d" % (rsp.major, rsp.minor, rsp.point))
        
        majorVersion = rsp.major

        if majorVersion == 4 or majorVersion == 5:
            import config_block_v3 as config_block
        elif majorVersion == 6 or majorVersion == 7:
            import config_block_v4 as config_block
        else:
            import config_block_v4 as config_block
            self._logger.error("can't understand SW major version %d, defaulting to v4 config" % majorVersion) 
        self.config_block = config_block
        
    def doConfig(self, cfg_file, verify_config = False):

        self.discoverConfigVersion()

        # Read in the node configuration parameters.
        cfg_dict = self.read_node_config_file(cfg_file)

        # Program the flash sector with the configuration parameters.
        (cfg_wr, ap_list_wr) = self.program_node_config_flash(cfg_dict)
            
        if verify_config:
            cfg_version = self.config_block.FLASH_CONF_VERSION
            cfg_readback = self.read_node_config_flash()
            if cfg_version == 3:
                ap_list_readback = None
                cfg_wr = cfg_wr.v3
                cfg_readback = cfg_readback.v3
            elif cfg_version == 4:
                ap_list_readback = self.read_node_ap_list_flash()
                cfg_wr = cfg_wr.v4
                cfg_readback = cfg_readback.v4
            else:
                raise p_err.ULPProvisioningError(p_err.ErrorCodes.UNKNOWN_CONF_VERSION)

            if cfg_wr.get_dict() != cfg_readback.get_dict():
                self._logger.error("Flash config read back MISMATCH.")
                self._logger.info("cfg write: %s", cfg_wr)
                self._logger.info("cfg read:  %s", cfg_readback)
                raise p_err.ULPProvisioningError( \
                    p_err.ErrorCodes.VERIFICATION_FAILED, "Flash config read back MISMATCH")
            else:
                self._logger.info("Flash config read back matches.")

            if cfg_version == 3:
                # Do not try to compare AP list for version 3 config.
                return

            if ap_list_wr.get_dict() != ap_list_readback.get_dict():
                self._logger.error("Flash AP list readback MISMATCH.")
                self._logger.info("ap list write: %s", ap_list_wr.get_dict())
                self._logger.info("ap list read:  %s", ap_list_readback.get_dict())
                raise p_err.ULPProvisioningError( \
                    p_err.ErrorCodes.VERIFICATION_FAILED, "ap list read back MISMATCH")


###############################################################################
if __name__ == '__main__':
    short_opts = "C:L:DVvh"
    long_opts  = ["config=", "verify", "verbose", "debug", "log=", "help"]

    (commArgs, extraOptions, args) = \
        orwCmdLineParams.parseParams(sys.argv[1:],short_opts,long_opts)

    config_file   = None
    verify_config = False
    log_file      = None        # File for logging all messages.
    debug_flag    = False       # Prints all messages to stdout.

    for (opt,val) in extraOptions.items():
        if opt in ("-C", "--config"):
            config_file = val[-1]
        elif opt in ("-V", "--verify"):
            verify_config = True
        elif opt in ("-L", "--log"):
            log_file = val[-1]
        elif opt in ("-D", "--debug", "-v", "--verbose"):
            debug_flag = True
        elif opt in ("-h", "--help"):
            usage()
            sys.exit(0)
        else:
            usage("Invalid option '%s'" % opt)
            sys.exit(3)

    if not config_file:
        usage("Missing configuration file.")
        sys.exit(5)

    node_index = commArgs["nodeIndex"][-1]

    import log_utils

    if not log_file:
        # No log file specified, so print any debug messages to stdout.
        debug_flag = True
    logger = log_utils.setup_log(log_file, debug_flag)

    import ucl_nhp

    try:
        try:
            connection = ucl_nhp.Connection(commArgs)
        except:
            raise p_err.ULPProvisioningError(p_err.ErrorCodes.COMM_OPEN_FAILURE, \
                                                 target=p_err.CommType.LOCAL_ERROR)
        connection.interrogate_nodes(nodes=commArgs["nodeIndex"])

        res = -1
        configurator = nodeConfigurator(connection, node_idx = node_index, logger = logger)
        configurator.doConfig(config_file, verify_config)
        res = 0
    except p_err.ULPProvisioningError as e:
        print str(e)
        if debug_flag:
            traceback.print_exc()
        res = e.errorCode
    except IOError:
        print 'I/O error from message layer'
        if debug_flag:
            traceback.print_exc()
        res = p_err.ErrorCodes.COMM_FAILURE
    except:
        traceback.print_exc()
    finally:
        connection.close()

    sys.exit(res)
