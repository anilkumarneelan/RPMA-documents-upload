# Transport Wrapper
# Generic: class TransportWrapper with following methods:
#        egressWrapper that takes message string input and function to call
#            with converted message string
#        ingressWrapper that takes string input and function to call with
#            converted message string.  Note that readFxn does not need to
#            be called with every call to ingressWrapper.  readFxn is
#            allowed to be called only when ingressWrapper has been called
#            a sufficient number of times with a sufficient amount of str
#            data in order to form a complete message.
# ORW specific:
#        egressWrapper optionally writes to standard output simply to test
#            that it is being called appropriately.
#        ingressWrapper optionally writes to standard output simply to test
#            that it is being called appropriately.  ingressWrapper
#            unconditionally calls readFxn in order to pass up all data.


class TransportWrapper():
    def __init__(self, writeFxn, readFxn, logger, exceptionHandler):
        self._writeFxn = writeFxn
        self._readFxn = readFxn
        self._logger = logger
        self._exceptionHandler = exceptionHandler

    def reInit(self):
        pass
    
    # egressWrapper is responsible for wrapping a message that is destined for the host.
    # The string passed in is one complete message.
    def egressWrapper(self, str):

        # some debug output to make sure wrapper is being called
        #print "write: %d" % len(str)

        # send the final altered message out for tx
        self._writeFxn(str)

    # ingressWrapper is responsible for unwrapping a message that is received from the host.
    # Each call of this function passes the next bytes in the message.  This function may be
    # called multiple times before a complete message is formed (each call to ingressWrapper
    # is not necessarily a complete message).  It is the responsibility of ingressWrapper to
    # keep track of how much of the message is received.
    #
    # Upon reception of a complete message, ingressWrapper must call readFxn with the
    # unwrapped message.  In the event that no complete message has been received,
    # ingressWrapper does not need to call readFxn.  In the event that one call to
    # ingressWrapper contains two or more complete messages, ingressWrapper must either call
    # readFxn with the concatenated string or must call readFxn multiple times with each part
    # of the data.
    def ingressWrapper(self, str):

        # some debug output to make sure wrapper is being called
        #print "read: %d" % len(str)

        # notify transport that a message was completed and translated through the wrapper
        if str!='':
            self._readFxn(str)

