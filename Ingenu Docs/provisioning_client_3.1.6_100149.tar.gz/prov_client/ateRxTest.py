#!/usr/bin/env python

"""Command line interface to ATE RX test mode"""

import sys
import signal
import traceback

import ucl_nhp
import orwCmdLineParams

def usage(s = ''):
    """Prints the help text."""

    if s:
        print "Error: %s\n" % s

    print "Usage:  %s [OPTION]" % sys.argv[0]
    print """

Configures a node for ATE RX test mode, and optionally waits for RX
ADC samples.

Note that a node reset is the expected path to return to normal operation.

OPTIONS:
"""
    for usageStr in orwCmdLineParams.usageLong():
        print "    %s" % usageStr

    print "    -F centerFreqInKhz"
    print "       Set center frequency (in integer kHz units)."
    print "    -L lna"
    print "       Set RX LNA control - use 0 to 3"
    print "    -V vga"
    print "       Set RX VGA control - use 0 to 31"
    print "    -A antenna"
    print "       Set antenna port to TX on (0 or 1) - only effective on micronodes"
    print "    -S samples"
    print "       Retrieve (minimum) samples ADC samples (0 for none, max 21845)"
    print "    -J skip"
    print "       Number of ADC samples to discard before returning samples above"
    print "    -O samplefile"
    print "       Provide a filename to write ADC samples (stdout is default)"
    print "    -h, --help"
    print "       Prints this help message."
    print """
EXAMPLE:

    %s -d /dev/ttyS0 -F 2405000 -L 3 -V 31 -A 0

    or for sample grab mode:
    %s -d /dev/ttyS0 -F 2405000 -L 3 -V 31 -A 0 -S 10000 -J 2000 -O adc.csv
    """ % (sys.argv[0], sys.argv[0])

def receiveSamples(connection, node_idx, samplefile, samples):
    node_msg = connection.node(n=node_idx).node_msg
    rxsamples = 0

    BITWIDTH = 9 
    MAX_ABS = 2**(BITWIDTH-1)
    COMP = 2**BITWIDTH

    if samplefile:
        samplefile.write('real,imaginary\n')
    else:
        print 'real,imaginary'
    while rxsamples < samples:
        sampleMsg = connection.getMsgById(node_msg.RX_SAMPLE_IND, node_idx = node_idx)
        if not sampleMsg:
            print 'timed out waiting for samples'
            return False
        for sample in sampleMsg.packedSample:
            rxsamples += 1

            # real and imaginary 9 bit components
            re = (sample & 0x3FE00) >> 9
            im = (sample & 0x1FF)

            # 2's complement conversion
            if re > MAX_ABS:
                re = re - COMP
            if im > MAX_ABS:
                im = im - COMP

            if samplefile:
                samplefile.write('%d,%d\n' % (re, im))
            else:
                print '%d,%d' % (re, im)
    return True

if __name__ == '__main__':
    short_opts = "hF:L:V:A:S:J:O:"
    long_opts  = ["help",]
    (commArgs, extraOptions, args) = \
               orwCmdLineParams.parseParams(sys.argv[1:],short_opts,long_opts)

    def signal_handler(signal, frame):
        print 'Ctrl-C: canceled by user'
        if connection != None:
            connection.close()
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)

    lna = 3
    vga = 31
    centerFreq = 2440000
    antenna = 0
    samples = 0
    skipSamples = 0
    samplefile = None
    
    for (opt, val) in extraOptions.items():
        if opt in ("-h", "--help"):
            usage()
            sys.exit(0)
        elif opt in ("-F"):
            centerFreq = int(val[0])
        elif opt in ("-L"):
            lna = int(val[0])
        elif opt in ("-V"):
            vga = int(val[0])
        elif opt in ("-A"):
            antenna = int(val[0])
        elif opt in ("-S"):
            samples = int(val[0])
        elif opt in ("-J"):
            skipSamples = int(val[0])
        elif opt in ("-O"):
            samplefile = open(val[0], "w")
        else:
            assert 0, "Unhandled option '%s'." % opt
        
    if len(args) > 0:
        usage("Extra arguments.")
        sys.exit(1)

    if centerFreq < 2402000 or centerFreq > 2500000:
        print 'center freq. %d is out of range (2402000 - 2500000)' % centerFreq
        sys.exit(1)

    if antenna != 0 and antenna != 1:
        print 'invalid antenna choice (must be 0 or 1)'
        sys.exit(1)

    if lna < 0 or lna > 3:
        print 'invalid lna value %d (valid range 0 - 3)' % lna
        sys.exit(1)

    if vga < 0 or vga > 31:
        print 'invalid vga value %d (valid range 0 - 31)' % vga
        sys.exit(1)

    if samples < 0 or skipSamples < 0 or samples + skipSamples > 21845:
        print 'samples + skipSamples must be <= 21845'
        sys.exit(1)
            
    try:
        connection = ucl_nhp.Connection(commArgs)
    except Exception, err:
        print 'Error opening connection: %s' % err
        usage()
        sys.exit(-1)

    try:
        connection.interrogate_nodes(nodes=commArgs["nodeIndex"])
        node_idx = commArgs["nodeIndex"][0]
        node_msg = connection.node(n=node_idx).node_msg
        msg = node_msg.CONF_MANUF_RX_TEST(centerFreqKHzOffset = centerFreq - 2400000,
                                          lna = lna,
                                          vga = vga,
                                          adcSamples = samples,
                                          adcSamplesSkip = skipSamples,
                                          antennaSetting = antenna)
        ack = connection.sendMsg(msg, node_idx = node_idx)
        if not ack:
            raise IOError, 'Failed to get ACK for CONF_MANUF_RX_TEST message.'
        if samples > 0:
            finishedSamples = receiveSamples(connection, node_idx, samplefile, samples)
        else:
            finishedSamples = True
    except Exception, e:
        print 'Error: %s' % e
        traceback.print_exc()
    finally:
        connection.close()
        sys.exit(0)

